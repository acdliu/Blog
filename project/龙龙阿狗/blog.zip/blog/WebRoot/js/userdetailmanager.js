$(document).ready(function(){
    var s = document.getElementById("sex").value;
    var f = document.getElementById("functionSex");
    var y = document.getElementById("birth_y").value;
    var yy = document.getElementById("birthday_y");
    var m = document.getElementById("birth_m").value;
    var mm = document.getElementById("birthday_m");
    var d = document.getElementById("birth_d").value;
    var dd = document.getElementById("birthday_d");
    var i;
    for(i=0;i<f.length;i++){
    	if(s==f[i].value){
    		f[i].selected="selected";
    	}
    }
    for(i=0;i<yy.length;i++){
    	if(y==yy[i].value){
    		yy[i].selected="selected";
    	}
    }
    for(i=0;i<mm.length;i++){
    	if(m==mm[i].value){
    		mm[i].selected="selected";
    	}
    }
    for(i=0;i<dd.length;i++){
    	if(d==dd[i].value){
    		dd[i].selected="selected";
    	}
    }
});