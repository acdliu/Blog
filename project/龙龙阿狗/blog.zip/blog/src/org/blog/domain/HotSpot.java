package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllHotSpots", query = "select myHotSpot from HotSpot myHotSpot"),
		@NamedQuery(name = "findHotSpotByArticleId", query = "select myHotSpot from HotSpot myHotSpot where myHotSpot.articleId = ?1"),
		@NamedQuery(name = "findHotSpotByCreateTime", query = "select myHotSpot from HotSpot myHotSpot where myHotSpot.createTime = ?1"),
		@NamedQuery(name = "findHotSpotByHotSpotId", query = "select myHotSpot from HotSpot myHotSpot where myHotSpot.hotSpotId = ?1"),
		@NamedQuery(name = "findHotSpotByIsArticle", query = "select myHotSpot from HotSpot myHotSpot where myHotSpot.isArticle = ?1"),
		@NamedQuery(name = "findHotSpotByPrimaryKey", query = "select myHotSpot from HotSpot myHotSpot where myHotSpot.hotSpotId = ?1") })
@Table(catalog = "blog", name = "hot_spot")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "HotSpot")
public class HotSpot implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "hot_spot_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer hotSpotId;
	/**
	 */

	@Column(name = "article_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer articleId;
	/**
	 */

	@Column(name = "is_article", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isArticle;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "redactor_id", referencedColumnName = "administrator_id", nullable = false) })
	@XmlTransient
	Administrator administrator;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "channel_id", referencedColumnName = "channel_id", nullable = false) })
	@XmlTransient
	Channel channel;

	/**
	 */
	public void setHotSpotId(Integer hotSpotId) {
		this.hotSpotId = hotSpotId;
	}

	/**
	 */
	public Integer getHotSpotId() {
		return this.hotSpotId;
	}

	/**
	 */
	public void setArticleId(Integer articleId) {
		this.articleId = articleId;
	}

	/**
	 */
	public Integer getArticleId() {
		return this.articleId;
	}

	/**
	 */
	public void setIsArticle(Boolean isArticle) {
		this.isArticle = isArticle;
	}

	/**
	 */
	public Boolean getIsArticle() {
		return this.isArticle;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}

	/**
	 */
	public Administrator getAdministrator() {
		return administrator;
	}

	/**
	 */
	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	/**
	 */
	public Channel getChannel() {
		return channel;
	}

	/**
	 */
	public HotSpot() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(HotSpot that) {
		setHotSpotId(that.getHotSpotId());
		setArticleId(that.getArticleId());
		setIsArticle(that.getIsArticle());
		setCreateTime(that.getCreateTime());
		setAdministrator(that.getAdministrator());
		setChannel(that.getChannel());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("hotSpotId=[").append(hotSpotId).append("] ");
		buffer.append("articleId=[").append(articleId).append("] ");
		buffer.append("isArticle=[").append(isArticle).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((hotSpotId == null) ? 0 : hotSpotId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof HotSpot))
			return false;
		HotSpot equalCheck = (HotSpot) obj;
		if ((hotSpotId == null && equalCheck.hotSpotId != null) || (hotSpotId != null && equalCheck.hotSpotId == null))
			return false;
		if (hotSpotId != null && !hotSpotId.equals(equalCheck.hotSpotId))
			return false;
		return true;
	}
}
