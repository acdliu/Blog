package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllMoods", query = "select myMood from Mood myMood"),
		@NamedQuery(name = "findMoodByContent", query = "select myMood from Mood myMood where myMood.content = ?1"),
		@NamedQuery(name = "findMoodByContentContaining", query = "select myMood from Mood myMood where myMood.content like ?1"),
		@NamedQuery(name = "findMoodByCreateTime", query = "select myMood from Mood myMood where myMood.createTime = ?1"),
		@NamedQuery(name = "findMoodByMoodId", query = "select myMood from Mood myMood where myMood.moodId = ?1"),
		@NamedQuery(name = "findMoodByPrimaryKey", query = "select myMood from Mood myMood where myMood.moodId = ?1") })
@Table(catalog = "blog", name = "mood")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Mood")
public class Mood implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "mood_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer moodId;
	/**
	 */

	@Column(name = "content")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String content;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "owner_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User user;

	/**
	 */
	public void setMoodId(Integer moodId) {
		this.moodId = moodId;
	}

	/**
	 */
	public Integer getMoodId() {
		return this.moodId;
	}

	/**
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 */
	public String getContent() {
		return this.content;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 */
	public User getUser() {
		return user;
	}

	/**
	 */
	public Mood() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Mood that) {
		setMoodId(that.getMoodId());
		setContent(that.getContent());
		setCreateTime(that.getCreateTime());
		setUser(that.getUser());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("moodId=[").append(moodId).append("] ");
		buffer.append("content=[").append(content).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((moodId == null) ? 0 : moodId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Mood))
			return false;
		Mood equalCheck = (Mood) obj;
		if ((moodId == null && equalCheck.moodId != null) || (moodId != null && equalCheck.moodId == null))
			return false;
		if (moodId != null && !moodId.equals(equalCheck.moodId))
			return false;
		return true;
	}
}
