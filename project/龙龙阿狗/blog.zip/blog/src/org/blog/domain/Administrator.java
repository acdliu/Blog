package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAdministratorByAdministratorId", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.administratorId = ?1"),
		@NamedQuery(name = "findAdministratorByAdministratorIdContaining", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.administratorId like ?1"),
		@NamedQuery(name = "findAdministratorByName", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.name = ?1"),
		@NamedQuery(name = "findAdministratorByNameContaining", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.name like ?1"),
		@NamedQuery(name = "findAdministratorByPassword", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.password = ?1"),
		@NamedQuery(name = "findAdministratorByPasswordContaining", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.password like ?1"),
		@NamedQuery(name = "findAdministratorByPrimaryKey", query = "select myAdministrator from Administrator myAdministrator where myAdministrator.administratorId = ?1"),
		@NamedQuery(name = "findAllAdministrators", query = "select myAdministrator from Administrator myAdministrator") })
@Table(catalog = "blog", name = "administrator")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Administrator")
@XmlRootElement(namespace = "blog/org/blog/domain")
public class Administrator implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "administrator_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String administratorId;
	/**
	 */

	@Column(name = "password", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String password;
	/**
	 */

	@Column(name = "name", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;

	/**
	 */
	@OneToMany(mappedBy = "administrator", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.HotSpot> hotSpots;
	/**
	 */
	@OneToMany(mappedBy = "administrator", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Message> messages;

	/**
	 */
	public void setAdministratorId(String administratorId) {
		this.administratorId = administratorId;
	}

	/**
	 */
	public String getAdministratorId() {
		return this.administratorId;
	}

	/**
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setHotSpots(Set<HotSpot> hotSpots) {
		this.hotSpots = hotSpots;
	}

	/**
	 */
	public Set<HotSpot> getHotSpots() {
		if (hotSpots == null) {
			hotSpots = new java.util.LinkedHashSet<org.blog.domain.HotSpot>();
		}
		return hotSpots;
	}

	/**
	 */
	public void setMessages(Set<Message> messages) {
		this.messages = messages;
	}

	/**
	 */
	public Set<Message> getMessages() {
		if (messages == null) {
			messages = new java.util.LinkedHashSet<org.blog.domain.Message>();
		}
		return messages;
	}

	/**
	 */
	public Administrator() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Administrator that) {
		setAdministratorId(that.getAdministratorId());
		setPassword(that.getPassword());
		setName(that.getName());
		setHotSpots(new java.util.LinkedHashSet<org.blog.domain.HotSpot>(that.getHotSpots()));
		setMessages(new java.util.LinkedHashSet<org.blog.domain.Message>(that.getMessages()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("administratorId=[").append(administratorId).append("] ");
		buffer.append("password=[").append(password).append("] ");
		buffer.append("name=[").append(name).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((administratorId == null) ? 0 : administratorId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Administrator))
			return false;
		Administrator equalCheck = (Administrator) obj;
		if ((administratorId == null && equalCheck.administratorId != null) || (administratorId != null && equalCheck.administratorId == null))
			return false;
		if (administratorId != null && !administratorId.equals(equalCheck.administratorId))
			return false;
		return true;
	}
}
