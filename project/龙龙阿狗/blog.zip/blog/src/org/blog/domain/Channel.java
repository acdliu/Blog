package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllChannels", query = "select myChannel from Channel myChannel"),
		@NamedQuery(name = "findChannelByChannelId", query = "select myChannel from Channel myChannel where myChannel.channelId = ?1"),
		@NamedQuery(name = "findChannelByCreateTime", query = "select myChannel from Channel myChannel where myChannel.createTime = ?1"),
		@NamedQuery(name = "findChannelByName", query = "select myChannel from Channel myChannel where myChannel.name = ?1"),
		@NamedQuery(name = "findChannelByNameContaining", query = "select myChannel from Channel myChannel where myChannel.name like ?1"),
		@NamedQuery(name = "findChannelByPrimaryKey", query = "select myChannel from Channel myChannel where myChannel.channelId = ?1") })
@Table(catalog = "blog", name = "channel")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Channel")
@XmlRootElement(namespace = "blog/org/blog/domain")
public class Channel implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "channel_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer channelId;
	/**
	 */

	@Column(name = "name")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@OneToMany(mappedBy = "channel", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.HotSpot> hotSpots;

	/**
	 */
	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}

	/**
	 */
	public Integer getChannelId() {
		return this.channelId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setHotSpots(Set<HotSpot> hotSpots) {
		this.hotSpots = hotSpots;
	}

	/**
	 */
	public Set<HotSpot> getHotSpots() {
		if (hotSpots == null) {
			hotSpots = new java.util.LinkedHashSet<org.blog.domain.HotSpot>();
		}
		return hotSpots;
	}

	/**
	 */
	public Channel() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Channel that) {
		setChannelId(that.getChannelId());
		setName(that.getName());
		setCreateTime(that.getCreateTime());
		setHotSpots(new java.util.LinkedHashSet<org.blog.domain.HotSpot>(that.getHotSpots()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("channelId=[").append(channelId).append("] ");
		buffer.append("name=[").append(name).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((channelId == null) ? 0 : channelId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Channel))
			return false;
		Channel equalCheck = (Channel) obj;
		if ((channelId == null && equalCheck.channelId != null) || (channelId != null && equalCheck.channelId == null))
			return false;
		if (channelId != null && !channelId.equals(equalCheck.channelId))
			return false;
		return true;
	}
}
