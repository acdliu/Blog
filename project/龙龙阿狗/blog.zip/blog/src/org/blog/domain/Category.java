package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllCategorys", query = "select myCategory from Category myCategory"),
		@NamedQuery(name = "findCategoryByCategoryId", query = "select myCategory from Category myCategory where myCategory.categoryId = ?1"),
		@NamedQuery(name = "findCategoryByName", query = "select myCategory from Category myCategory where myCategory.name = ?1"),
		@NamedQuery(name = "findCategoryByNameContaining", query = "select myCategory from Category myCategory where myCategory.name like ?1"),
		@NamedQuery(name = "findCategoryByPrimaryKey", query = "select myCategory from Category myCategory where myCategory.categoryId = ?1") })
@Table(catalog = "blog", name = "category")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Category")
@XmlRootElement(namespace = "blog/org/blog/domain")
public class Category implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "category_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer categoryId;
	/**
	 */

	@Column(name = "name", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;

	/**
	 */
	@OneToMany(mappedBy = "category", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Article> articles;

	/**
	 */
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 */
	public Integer getCategoryId() {
		return this.categoryId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setArticles(Set<Article> articles) {
		this.articles = articles;
	}

	/**
	 */
	public Set<Article> getArticles() {
		if (articles == null) {
			articles = new java.util.LinkedHashSet<org.blog.domain.Article>();
		}
		return articles;
	}

	/**
	 */
	public Category() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Category that) {
		setCategoryId(that.getCategoryId());
		setName(that.getName());
		setArticles(new java.util.LinkedHashSet<org.blog.domain.Article>(that.getArticles()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("categoryId=[").append(categoryId).append("] ");
		buffer.append("name=[").append(name).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((categoryId == null) ? 0 : categoryId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Category))
			return false;
		Category equalCheck = (Category) obj;
		if ((categoryId == null && equalCheck.categoryId != null) || (categoryId != null && equalCheck.categoryId == null))
			return false;
		if (categoryId != null && !categoryId.equals(equalCheck.categoryId))
			return false;
		return true;
	}
}
