package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllPicVideoGroups", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup"),
		@NamedQuery(name = "findPicVideoGroupByCreateTime", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.createTime = ?1"),
		@NamedQuery(name = "findPicVideoGroupByHits", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.hits = ?1"),
		@NamedQuery(name = "findPicVideoGroupByIsPicGroup", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.isPicGroup = ?1"),
		@NamedQuery(name = "findPicVideoGroupByIsPublic", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.isPublic = ?1"),
		@NamedQuery(name = "findPicVideoGroupByPicVideoGroupId", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.picVideoGroupId = ?1"),
		@NamedQuery(name = "findPicVideoGroupByPrimaryKey", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.picVideoGroupId = ?1"),
		@NamedQuery(name = "findPicVideoGroupByTitle", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.title = ?1"),
		@NamedQuery(name = "findPicVideoGroupByTitleContaining", query = "select myPicVideoGroup from PicVideoGroup myPicVideoGroup where myPicVideoGroup.title like ?1") })
@Table(catalog = "blog", name = "pic_video_group")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "PicVideoGroup")
@XmlRootElement(namespace = "blog/org/blog/domain")
public class PicVideoGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "pic_video_group_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer picVideoGroupId;
	/**
	 */

	@Column(name = "title")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String title;
	/**
	 */

	@Column(name = "is_public", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isPublic;
	/**
	 */

	@Column(name = "is_pic_group", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isPicGroup;
	/**
	 */

	@Column(name = "hits")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer hits;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "owner_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User user;
	/**
	 */
	@OneToMany(mappedBy = "picVideoGroup", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.PicVideo> picVideos;

	/**
	 */
	public void setPicVideoGroupId(Integer picVideoGroupId) {
		this.picVideoGroupId = picVideoGroupId;
	}

	/**
	 */
	public Integer getPicVideoGroupId() {
		return this.picVideoGroupId;
	}

	/**
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 */
	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}

	/**
	 */
	public Boolean getIsPublic() {
		return this.isPublic;
	}

	/**
	 */
	public void setIsPicGroup(Boolean isPicGroup) {
		this.isPicGroup = isPicGroup;
	}

	/**
	 */
	public Boolean getIsPicGroup() {
		return this.isPicGroup;
	}

	/**
	 */
	public void setHits(Integer hits) {
		this.hits = hits;
	}

	/**
	 */
	public Integer getHits() {
		return this.hits;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 */
	public User getUser() {
		return user;
	}

	/**
	 */
	public void setPicVideos(Set<PicVideo> picVideos) {
		this.picVideos = picVideos;
	}

	/**
	 */
	public Set<PicVideo> getPicVideos() {
		if (picVideos == null) {
			picVideos = new java.util.LinkedHashSet<org.blog.domain.PicVideo>();
		}
		return picVideos;
	}

	/**
	 */
	public PicVideoGroup() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(PicVideoGroup that) {
		setPicVideoGroupId(that.getPicVideoGroupId());
		setTitle(that.getTitle());
		setIsPublic(that.getIsPublic());
		setIsPicGroup(that.getIsPicGroup());
		setHits(that.getHits());
		setCreateTime(that.getCreateTime());
		setUser(that.getUser());
		setPicVideos(new java.util.LinkedHashSet<org.blog.domain.PicVideo>(that.getPicVideos()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("picVideoGroupId=[").append(picVideoGroupId).append("] ");
		buffer.append("title=[").append(title).append("] ");
		buffer.append("isPublic=[").append(isPublic).append("] ");
		buffer.append("isPicGroup=[").append(isPicGroup).append("] ");
		buffer.append("hits=[").append(hits).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((picVideoGroupId == null) ? 0 : picVideoGroupId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof PicVideoGroup))
			return false;
		PicVideoGroup equalCheck = (PicVideoGroup) obj;
		if ((picVideoGroupId == null && equalCheck.picVideoGroupId != null) || (picVideoGroupId != null && equalCheck.picVideoGroupId == null))
			return false;
		if (picVideoGroupId != null && !picVideoGroupId.equals(equalCheck.picVideoGroupId))
			return false;
		return true;
	}
}
