package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllRelations", query = "select myRelation from Relation myRelation"),
		@NamedQuery(name = "findRelationByCreateTime", query = "select myRelation from Relation myRelation where myRelation.createTime = ?1"),
		@NamedQuery(name = "findRelationByIsBlacker", query = "select myRelation from Relation myRelation where myRelation.isBlacker = ?1"),
		@NamedQuery(name = "findRelationByPrimaryKey", query = "select myRelation from Relation myRelation where myRelation.relationId = ?1"),
		@NamedQuery(name = "findRelationByRelationId", query = "select myRelation from Relation myRelation where myRelation.relationId = ?1") })
@Table(catalog = "blog", name = "relation")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Relation")
public class Relation implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "relation_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer relationId;
	/**
	 */

	@Column(name = "is_blacker", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isBlacker= false;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "idol_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User userByIdolId;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "fan_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User userByFanId;

	/**
	 */
	public void setRelationId(Integer relationId) {
		this.relationId = relationId;
	}

	/**
	 */
	public Integer getRelationId() {
		return this.relationId;
	}

	/**
	 */
	public void setIsBlacker(Boolean isBlacker) {
		this.isBlacker = isBlacker;
	}

	/**
	 */
	public Boolean getIsBlacker() {
		return this.isBlacker;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setUserByIdolId(User userByIdolId) {
		this.userByIdolId = userByIdolId;
	}

	/**
	 */
	public User getUserByIdolId() {
		return userByIdolId;
	}

	/**
	 */
	public void setUserByFanId(User userByFanId) {
		this.userByFanId = userByFanId;
	}

	/**
	 */
	public User getUserByFanId() {
		return userByFanId;
	}

	/**
	 */
	public Relation() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Relation that) {
		setRelationId(that.getRelationId());
		setIsBlacker(that.getIsBlacker());
		setCreateTime(that.getCreateTime());
		setUserByIdolId(that.getUserByIdolId());
		setUserByFanId(that.getUserByFanId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("relationId=[").append(relationId).append("] ");
		buffer.append("isBlacker=[").append(isBlacker).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((relationId == null) ? 0 : relationId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Relation))
			return false;
		Relation equalCheck = (Relation) obj;
		if ((relationId == null && equalCheck.relationId != null) || (relationId != null && equalCheck.relationId == null))
			return false;
		if (relationId != null && !relationId.equals(equalCheck.relationId))
			return false;
		return true;
	}
}
