package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllArticles", query = "select myArticle from Article myArticle"),
		@NamedQuery(name = "findArticleByArticleId", query = "select myArticle from Article myArticle where myArticle.articleId = ?1"),
		@NamedQuery(name = "findArticleByContent", query = "select myArticle from Article myArticle where myArticle.content = ?1"),
		@NamedQuery(name = "findArticleByCreateTime", query = "select myArticle from Article myArticle where myArticle.createTime = ?1"),
		@NamedQuery(name = "findArticleByHits", query = "select myArticle from Article myArticle where myArticle.hits = ?1"),
		@NamedQuery(name = "findArticleByIsPublic", query = "select myArticle from Article myArticle where myArticle.isPublic = ?1"),
		@NamedQuery(name = "findArticleByPrimaryKey", query = "select myArticle from Article myArticle where myArticle.articleId = ?1"),
		@NamedQuery(name = "findArticleByTitle", query = "select myArticle from Article myArticle where myArticle.title = ?1"),
		@NamedQuery(name = "findArticleByTitleContaining", query = "select myArticle from Article myArticle where myArticle.title like ?1") })
@Table(catalog = "blog", name = "article")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Article")
public class Article implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "article_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer articleId;
	/**
	 */

	@Column(name = "title")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String title;
	/**
	 */

	@Column(name = "content", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)
	@Lob
	@XmlElement
	String content;
	/**
	 */

	@Column(name = "hits")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer hits;
	/**
	 */

	@Column(name = "is_public")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isPublic;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "redactor_id", referencedColumnName = "user_id") })
	@XmlTransient
	User user;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "category_id", referencedColumnName = "category_id", nullable = false) })
	@XmlTransient
	Category category;

	/**
	 */
	public void setArticleId(Integer articleId) {
		this.articleId = articleId;
	}

	/**
	 */
	public Integer getArticleId() {
		return this.articleId;
	}

	/**
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 */
	public String getContent() {
		return this.content;
	}

	/**
	 */
	public void setHits(Integer hits) {
		this.hits = hits;
	}

	/**
	 */
	public Integer getHits() {
		return this.hits;
	}

	/**
	 */
	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}

	/**
	 */
	public Boolean getIsPublic() {
		return this.isPublic;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 */
	public User getUser() {
		return user;
	}

	/**
	 */
	public void setCategory(Category category) {
		this.category = category;
	}

	/**
	 */
	public Category getCategory() {
		return category;
	}

	/**
	 */
	public Article() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Article that) {
		setArticleId(that.getArticleId());
		setTitle(that.getTitle());
		setContent(that.getContent());
		setHits(that.getHits());
		setIsPublic(that.getIsPublic());
		setCreateTime(that.getCreateTime());
		setUser(that.getUser());
		setCategory(that.getCategory());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("articleId=[").append(articleId).append("] ");
		buffer.append("title=[").append(title).append("] ");
		buffer.append("content=[").append(content).append("] ");
		buffer.append("hits=[").append(hits).append("] ");
		buffer.append("isPublic=[").append(isPublic).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((articleId == null) ? 0 : articleId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Article))
			return false;
		Article equalCheck = (Article) obj;
		if ((articleId == null && equalCheck.articleId != null) || (articleId != null && equalCheck.articleId == null))
			return false;
		if (articleId != null && !articleId.equals(equalCheck.articleId))
			return false;
		return true;
	}
}
