package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllUsers", query = "select myUser from User myUser"),
		@NamedQuery(name = "findUserByPassword", query = "select myUser from User myUser where myUser.password = ?1"),
		@NamedQuery(name = "findUserByPasswordContaining", query = "select myUser from User myUser where myUser.password like ?1"),
		@NamedQuery(name = "findUserByPrimaryKey", query = "select myUser from User myUser where myUser.userId = ?1"),
		@NamedQuery(name = "findUserByUserId", query = "select myUser from User myUser where myUser.userId = ?1"),
		@NamedQuery(name = "findUserByUserIdContaining", query = "select myUser from User myUser where myUser.userId like ?1") })
@Table(catalog = "blog", name = "user")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "User")
@XmlRootElement(namespace = "blog/org/blog/domain")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "user_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String userId;
	/**
	 */

	@Column(name = "password", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String password;

	/**
	 */
	@OneToMany(mappedBy = "user", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Mood> moods;
	/**
	 */
	@OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	UserDetail userDetail;
	/**
	 */
	@OneToMany(mappedBy = "user", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Article> articles;
	/**
	 */
	@OneToMany(mappedBy = "userByIdolId", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Relation> relationsForFanId;
	/**
	 */
	@OneToMany(mappedBy = "userBySenderId", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Message> messagesForSenderId;
	/**
	 */
	@OneToMany(mappedBy = "userByIdolId", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Relation> relationsForIdolId;
	/**
	 */
	@OneToMany(mappedBy = "user", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.PicVideoGroup> picVideoGroups;
	/**
	 */
	@OneToMany(mappedBy = "userBySenderId", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Message> messagesForReceiverId;
	/**
	 */
	@OneToMany(mappedBy = "user", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Comment> comments;

	/**
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 */
	public void setMoods(Set<Mood> moods) {
		this.moods = moods;
	}

	/**
	 */
	public Set<Mood> getMoods() {
		if (moods == null) {
			moods = new java.util.LinkedHashSet<org.blog.domain.Mood>();
		}
		return moods;
	}

	/**
	 */
	public void setUserDetail(UserDetail userDetail) {
		this.userDetail = userDetail;
	}

	/**
	 */
	public UserDetail getUserDetail() {
		return userDetail;
	}

	/**
	 */
	public void setArticles(Set<Article> articles) {
		this.articles = articles;
	}

	/**
	 */
	public Set<Article> getArticles() {
		if (articles == null) {
			articles = new java.util.LinkedHashSet<org.blog.domain.Article>();
		}
		return articles;
	}

	/**
	 */
	public void setRelationsForFanId(Set<Relation> relationsForFanId) {
		this.relationsForFanId = relationsForFanId;
	}

	/**
	 */
	public Set<Relation> getRelationsForFanId() {
		if (relationsForFanId == null) {
			relationsForFanId = new java.util.LinkedHashSet<org.blog.domain.Relation>();
		}
		return relationsForFanId;
	}

	/**
	 */
	public void setMessagesForSenderId(Set<Message> messagesForSenderId) {
		this.messagesForSenderId = messagesForSenderId;
	}

	/**
	 */
	public Set<Message> getMessagesForSenderId() {
		if (messagesForSenderId == null) {
			messagesForSenderId = new java.util.LinkedHashSet<org.blog.domain.Message>();
		}
		return messagesForSenderId;
	}

	/**
	 */
	public void setRelationsForIdolId(Set<Relation> relationsForIdolId) {
		this.relationsForIdolId = relationsForIdolId;
	}

	/**
	 */
	public Set<Relation> getRelationsForIdolId() {
		if (relationsForIdolId == null) {
			relationsForIdolId = new java.util.LinkedHashSet<org.blog.domain.Relation>();
		}
		return relationsForIdolId;
	}

	/**
	 */
	public void setPicVideoGroups(Set<PicVideoGroup> picVideoGroups) {
		this.picVideoGroups = picVideoGroups;
	}

	/**
	 */
	public Set<PicVideoGroup> getPicVideoGroups() {
		if (picVideoGroups == null) {
			picVideoGroups = new java.util.LinkedHashSet<org.blog.domain.PicVideoGroup>();
		}
		return picVideoGroups;
	}

	/**
	 */
	public void setMessagesForReceiverId(Set<Message> messagesForReceiverId) {
		this.messagesForReceiverId = messagesForReceiverId;
	}

	/**
	 */
	public Set<Message> getMessagesForReceiverId() {
		if (messagesForReceiverId == null) {
			messagesForReceiverId = new java.util.LinkedHashSet<org.blog.domain.Message>();
		}
		return messagesForReceiverId;
	}

	/**
	 */
	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}

	/**
	 */
	public Set<Comment> getComments() {
		if (comments == null) {
			comments = new java.util.LinkedHashSet<org.blog.domain.Comment>();
		}
		return comments;
	}

	/**
	 */
	public User() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(User that) {
		setUserId(that.getUserId());
		setPassword(that.getPassword());
		setMoods(new java.util.LinkedHashSet<org.blog.domain.Mood>(that.getMoods()));
		setUserDetail(that.getUserDetail());
		setArticles(new java.util.LinkedHashSet<org.blog.domain.Article>(that.getArticles()));
		setRelationsForFanId(new java.util.LinkedHashSet<org.blog.domain.Relation>(that.getRelationsForFanId()));
		setMessagesForSenderId(new java.util.LinkedHashSet<org.blog.domain.Message>(that.getMessagesForSenderId()));
		setRelationsForIdolId(new java.util.LinkedHashSet<org.blog.domain.Relation>(that.getRelationsForIdolId()));
		setPicVideoGroups(new java.util.LinkedHashSet<org.blog.domain.PicVideoGroup>(that.getPicVideoGroups()));
		setMessagesForReceiverId(new java.util.LinkedHashSet<org.blog.domain.Message>(that.getMessagesForReceiverId()));
		setComments(new java.util.LinkedHashSet<org.blog.domain.Comment>(that.getComments()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("userId=[").append(userId).append("] ");
		buffer.append("password=[").append(password).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((userId == null) ? 0 : userId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof User))
			return false;
		User equalCheck = (User) obj;
		if ((userId == null && equalCheck.userId != null) || (userId != null && equalCheck.userId == null))
			return false;
		if (userId != null && !userId.equals(equalCheck.userId))
			return false;
		return true;
	}
}
