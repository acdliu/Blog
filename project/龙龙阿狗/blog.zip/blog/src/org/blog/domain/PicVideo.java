package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllPicVideos", query = "select myPicVideo from PicVideo myPicVideo"),
		@NamedQuery(name = "findPicVideoByBrief", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.brief = ?1"),
		@NamedQuery(name = "findPicVideoByBriefContaining", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.brief like ?1"),
		@NamedQuery(name = "findPicVideoByHits", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.hits = ?1"),
		@NamedQuery(name = "findPicVideoByIsPicture", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.isPicture = ?1"),
		@NamedQuery(name = "findPicVideoByPicVideoId", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.picVideoId = ?1"),
		@NamedQuery(name = "findPicVideoByPictureUrl", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.pictureUrl = ?1"),
		@NamedQuery(name = "findPicVideoByPictureUrlContaining", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.pictureUrl like ?1"),
		@NamedQuery(name = "findPicVideoByPrimaryKey", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.picVideoId = ?1"),
		@NamedQuery(name = "findPicVideoByUploadTime", query = "select myPicVideo from PicVideo myPicVideo where myPicVideo.uploadTime = ?1") })
@Table(catalog = "blog", name = "pic_video")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "PicVideo")
public class PicVideo implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "pic_video_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer picVideoId;
	/**
	 */

	@Column(name = "picture_url", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String pictureUrl;
	/**
	 */

	@Column(name = "brief")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brief;
	/**
	 */

	@Column(name = "hits")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer hits;
	/**
	 */

	@Column(name = "is_picture", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isPicture;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upload_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar uploadTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "pic_video_group_id", referencedColumnName = "pic_video_group_id", nullable = false) })
	@XmlTransient
	PicVideoGroup picVideoGroup;

	/**
	 */
	public void setPicVideoId(Integer picVideoId) {
		this.picVideoId = picVideoId;
	}

	/**
	 */
	public Integer getPicVideoId() {
		return this.picVideoId;
	}

	/**
	 */
	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	/**
	 */
	public String getPictureUrl() {
		return this.pictureUrl;
	}

	/**
	 */
	public void setBrief(String brief) {
		this.brief = brief;
	}

	/**
	 */
	public String getBrief() {
		return this.brief;
	}

	/**
	 */
	public void setHits(Integer hits) {
		this.hits = hits;
	}

	/**
	 */
	public Integer getHits() {
		return this.hits;
	}

	/**
	 */
	public void setIsPicture(Boolean isPicture) {
		this.isPicture = isPicture;
	}

	/**
	 */
	public Boolean getIsPicture() {
		return this.isPicture;
	}

	/**
	 */
	public void setUploadTime(Calendar uploadTime) {
		this.uploadTime = uploadTime;
	}

	/**
	 */
	public Calendar getUploadTime() {
		return this.uploadTime;
	}

	/**
	 */
	public void setPicVideoGroup(PicVideoGroup picVideoGroup) {
		this.picVideoGroup = picVideoGroup;
	}

	/**
	 */
	public PicVideoGroup getPicVideoGroup() {
		return picVideoGroup;
	}

	/**
	 */
	public PicVideo() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(PicVideo that) {
		setPicVideoId(that.getPicVideoId());
		setPictureUrl(that.getPictureUrl());
		setBrief(that.getBrief());
		setHits(that.getHits());
		setIsPicture(that.getIsPicture());
		setUploadTime(that.getUploadTime());
		setPicVideoGroup(that.getPicVideoGroup());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("picVideoId=[").append(picVideoId).append("] ");
		buffer.append("pictureUrl=[").append(pictureUrl).append("] ");
		buffer.append("brief=[").append(brief).append("] ");
		buffer.append("hits=[").append(hits).append("] ");
		buffer.append("isPicture=[").append(isPicture).append("] ");
		buffer.append("uploadTime=[").append(uploadTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((picVideoId == null) ? 0 : picVideoId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof PicVideo))
			return false;
		PicVideo equalCheck = (PicVideo) obj;
		if ((picVideoId == null && equalCheck.picVideoId != null) || (picVideoId != null && equalCheck.picVideoId == null))
			return false;
		if (picVideoId != null && !picVideoId.equals(equalCheck.picVideoId))
			return false;
		return true;
	}
}
