package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllComments", query = "select myComment from Comment myComment"),
		@NamedQuery(name = "findCommentByArticleId", query = "select myComment from Comment myComment where myComment.articleId = ?1 and myComment.comment is null"),
		@NamedQuery(name = "findCommentByCommentId", query = "select myComment from Comment myComment where myComment.commentId = ?1"),
		@NamedQuery(name = "findCommentByCommentTime", query = "select myComment from Comment myComment where myComment.commentTime = ?1"),
		@NamedQuery(name = "findCommentByContent", query = "select myComment from Comment myComment where myComment.content = ?1"),
		@NamedQuery(name = "findCommentByIsMoodComment", query = "select myComment from Comment myComment where myComment.isMoodComment = ?1"),
		@NamedQuery(name = "findCommentByIsPublic", query = "select myComment from Comment myComment where myComment.isPublic = ?1"),
		@NamedQuery(name = "findCommentByPrimaryKey", query = "select myComment from Comment myComment where myComment.commentId = ?1") })
@Table(catalog = "blog", name = "comment")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Comment")
@XmlRootElement(namespace = "blog/org/blog/domain")
public class Comment implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "comment_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer commentId;
	/**
	 */

	@Column(name = "article_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer articleId;
	/**
	 */

	@Column(name = "content", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)
	@Lob
	@XmlElement
	String content;
	/**
	 */

	@Column(name = "is_mood_comment", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isMoodComment;
	/**
	 */

	@Column(name = "is_public", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isPublic;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "comment_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar commentTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "commenter_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User user;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "replier_id", referencedColumnName = "comment_id") })
	@XmlTransient
	Comment comment;
	/**
	 */
	@OneToMany(mappedBy = "comment", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	java.util.Set<org.blog.domain.Comment> comments;

	/**
	 */
	public void setCommentId(Integer commentId) {
		this.commentId = commentId;
	}

	/**
	 */
	public Integer getCommentId() {
		return this.commentId;
	}

	/**
	 */
	public void setArticleId(Integer articleId) {
		this.articleId = articleId;
	}

	/**
	 */
	public Integer getArticleId() {
		return this.articleId;
	}

	/**
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 */
	public String getContent() {
		return this.content;
	}

	/**
	 */
	public void setIsMoodComment(Boolean isMoodComment) {
		this.isMoodComment = isMoodComment;
	}

	/**
	 */
	public Boolean getIsMoodComment() {
		return this.isMoodComment;
	}

	/**
	 */
	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}

	/**
	 */
	public Boolean getIsPublic() {
		return this.isPublic;
	}

	/**
	 */
	public void setCommentTime(Calendar commentTime) {
		this.commentTime = commentTime;
	}

	/**
	 */
	public Calendar getCommentTime() {
		return this.commentTime;
	}

	/**
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 */
	public User getUser() {
		return user;
	}

	/**
	 */
	public void setComment(Comment comment) {
		this.comment = comment;
	}

	/**
	 */
	public Comment getComment() {
		return comment;
	}

	/**
	 */
	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}

	/**
	 */
	public Set<Comment> getComments() {
		if (comments == null) {
			comments = new java.util.LinkedHashSet<org.blog.domain.Comment>();
		}
		return comments;
	}

	/**
	 */
	public Comment() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Comment that) {
		setCommentId(that.getCommentId());
		setArticleId(that.getArticleId());
		setContent(that.getContent());
		setIsMoodComment(that.getIsMoodComment());
		setIsPublic(that.getIsPublic());
		setCommentTime(that.getCommentTime());
		setUser(that.getUser());
		setComment(that.getComment());
		setComments(new java.util.LinkedHashSet<org.blog.domain.Comment>(that.getComments()));
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("commentId=[").append(commentId).append("] ");
		buffer.append("articleId=[").append(articleId).append("] ");
		buffer.append("content=[").append(content).append("] ");
		buffer.append("isMoodComment=[").append(isMoodComment).append("] ");
		buffer.append("isPublic=[").append(isPublic).append("] ");
		buffer.append("commentTime=[").append(commentTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((commentId == null) ? 0 : commentId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Comment))
			return false;
		Comment equalCheck = (Comment) obj;
		if ((commentId == null && equalCheck.commentId != null) || (commentId != null && equalCheck.commentId == null))
			return false;
		if (commentId != null && !commentId.equals(equalCheck.commentId))
			return false;
		return true;
	}
}
