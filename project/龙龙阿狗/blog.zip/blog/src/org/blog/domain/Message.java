package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllMessages", query = "select myMessage from Message myMessage"),
		@NamedQuery(name = "findMessageByContent", query = "select myMessage from Message myMessage where myMessage.content = ?1"),
		@NamedQuery(name = "findMessageByContentContaining", query = "select myMessage from Message myMessage where myMessage.content like ?1"),
		@NamedQuery(name = "findMessageByCreateTime", query = "select myMessage from Message myMessage where myMessage.createTime = ?1"),
		@NamedQuery(name = "findMessageByIsRead", query = "select myMessage from Message myMessage where myMessage.isRead = ?1"),
		@NamedQuery(name = "findMessageByIsSystemMessage", query = "select myMessage from Message myMessage where myMessage.isSystemMessage = ?1"),
		@NamedQuery(name = "findMessageByMessageId", query = "select myMessage from Message myMessage where myMessage.messageId = ?1"),
		@NamedQuery(name = "findMessageByPrimaryKey", query = "select myMessage from Message myMessage where myMessage.messageId = ?1") })
@Table(catalog = "blog", name = "message")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "Message")
public class Message implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "message_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	Integer messageId;
	/**
	 */

	@Column(name = "content", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String content;
	/**
	 */

	@Column(name = "is_read", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isRead;
	/**
	 */

	@Column(name = "is_system_message", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Boolean isSystemMessage;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar createTime;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "sender_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User userBySenderId;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "sender_id", referencedColumnName = "administrator_id", nullable = false, insertable = false, updatable = false) })
	@XmlTransient
	Administrator administrator;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "receiver_id", referencedColumnName = "user_id", nullable = false) })
	@XmlTransient
	User userByReceiverId;

	/**
	 */
	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	/**
	 */
	public Integer getMessageId() {
		return this.messageId;
	}

	/**
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 */
	public String getContent() {
		return this.content;
	}

	/**
	 */
	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	/**
	 */
	public Boolean getIsRead() {
		return this.isRead;
	}

	/**
	 */
	public void setIsSystemMessage(Boolean isSystemMessage) {
		this.isSystemMessage = isSystemMessage;
	}

	/**
	 */
	public Boolean getIsSystemMessage() {
		return this.isSystemMessage;
	}

	/**
	 */
	public void setCreateTime(Calendar createTime) {
		this.createTime = createTime;
	}

	/**
	 */
	public Calendar getCreateTime() {
		return this.createTime;
	}

	/**
	 */
	public void setUserBySenderId(User userBySenderId) {
		this.userBySenderId = userBySenderId;
	}

	/**
	 */
	public User getUserBySenderId() {
		return userBySenderId;
	}

	/**
	 */
	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}

	/**
	 */
	public Administrator getAdministrator() {
		return administrator;
	}

	/**
	 */
	public void setUserByReceiverId(User userByReceiverId) {
		this.userByReceiverId = userByReceiverId;
	}

	/**
	 */
	public User getUserByReceiverId() {
		return userByReceiverId;
	}

	/**
	 */
	public Message() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(Message that) {
		setMessageId(that.getMessageId());
		setContent(that.getContent());
		setIsRead(that.getIsRead());
		setIsSystemMessage(that.getIsSystemMessage());
		setCreateTime(that.getCreateTime());
		setUserBySenderId(that.getUserBySenderId());
		setAdministrator(that.getAdministrator());
		setUserByReceiverId(that.getUserByReceiverId());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("messageId=[").append(messageId).append("] ");
		buffer.append("content=[").append(content).append("] ");
		buffer.append("isRead=[").append(isRead).append("] ");
		buffer.append("isSystemMessage=[").append(isSystemMessage).append("] ");
		buffer.append("createTime=[").append(createTime).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((messageId == null) ? 0 : messageId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof Message))
			return false;
		Message equalCheck = (Message) obj;
		if ((messageId == null && equalCheck.messageId != null) || (messageId != null && equalCheck.messageId == null))
			return false;
		if (messageId != null && !messageId.equals(equalCheck.messageId))
			return false;
		return true;
	}
}
