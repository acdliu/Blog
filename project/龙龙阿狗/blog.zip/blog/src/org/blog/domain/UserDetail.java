package org.blog.domain;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.xml.bind.annotation.*;

import javax.persistence.*;

/**
 */

@Entity
@NamedQueries({
		@NamedQuery(name = "findAllUserDetails", query = "select myUserDetail from UserDetail myUserDetail"),
		@NamedQuery(name = "findUserDetailByAddress", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.address = ?1"),
		@NamedQuery(name = "findUserDetailByAddressContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.address like ?1"),
		@NamedQuery(name = "findUserDetailByBirthday", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.birthday = ?1"),
		@NamedQuery(name = "findUserDetailByBirthdayAfter", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.birthday > ?1"),
		@NamedQuery(name = "findUserDetailByBirthdayBefore", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.birthday < ?1"),
		@NamedQuery(name = "findUserDetailByBrief", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.brief = ?1"),
		@NamedQuery(name = "findUserDetailByBriefContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.brief like ?1"),
		@NamedQuery(name = "findUserDetailByEmail", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.email = ?1"),
		@NamedQuery(name = "findUserDetailByEmailContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.email like ?1"),
		@NamedQuery(name = "findUserDetailByFaceUrl", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.faceUrl = ?1"),
		@NamedQuery(name = "findUserDetailByFaceUrlContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.faceUrl like ?1"),
		@NamedQuery(name = "findUserDetailByGender", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.gender = ?1"),
		@NamedQuery(name = "findUserDetailByGenderContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.gender like ?1"),
		@NamedQuery(name = "findUserDetailByHits", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.hits = ?1"),
		@NamedQuery(name = "findUserDetailByJoinTime", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.joinTime = ?1"),
		@NamedQuery(name = "findUserDetailByLastestLoginIp", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.lastestLoginIp = ?1"),
		@NamedQuery(name = "findUserDetailByLastestLoginIpContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.lastestLoginIp like ?1"),
		@NamedQuery(name = "findUserDetailByLoginTimes", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.loginTimes = ?1"),
		@NamedQuery(name = "findUserDetailByMobilePhone", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.mobilePhone = ?1"),
		@NamedQuery(name = "findUserDetailByMobilePhoneContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.mobilePhone like ?1"),
		@NamedQuery(name = "findUserDetailByName", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.name = ?1"),
		@NamedQuery(name = "findUserDetailByNameContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.name like ?1"),
		@NamedQuery(name = "findUserDetailByPrimaryKey", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.userId = ?1"),
		@NamedQuery(name = "findUserDetailByQq", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.qq = ?1"),
		@NamedQuery(name = "findUserDetailByQqContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.qq like ?1"),
		@NamedQuery(name = "findUserDetailByScore", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.score = ?1"),
		@NamedQuery(name = "findUserDetailByUserId", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.userId = ?1"),
		@NamedQuery(name = "findUserDetailByUserIdContaining", query = "select myUserDetail from UserDetail myUserDetail where myUserDetail.userId like ?1") })
@Table(catalog = "blog", name = "user_detail")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "blog/org/blog/domain", name = "UserDetail")
public class UserDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "user_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@XmlElement
	String userId;
	/**
	 */

	@Column(name = "name")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String name;
	/**
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "birthday")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar birthday;
	/**
	 */

	@Column(name = "gender")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String gender;
	/**
	 */

	@Column(name = "qq")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String qq;
	/**
	 */

	@Column(name = "email")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String email;
	/**
	 */

	@Column(name = "mobile_phone")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String mobilePhone;
	/**
	 */

	@Column(name = "address")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String address;
	/**
	 */

	@Column(name = "brief")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String brief;
	/**
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "join_time")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Calendar joinTime;
	/**
	 */

	@Column(name = "lastest_login_ip")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String lastestLoginIp;
	/**
	 */

	@Column(name = "login_times")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer loginTimes;
	/**
	 */

	@Column(name = "face_url")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	String faceUrl;
	/**
	 */

	@Column(name = "score")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer score;
	/**
	 */

	@Column(name = "hits")
	@Basic(fetch = FetchType.EAGER)
	@XmlElement
	Integer hits;

	/**
	 */
	@PrimaryKeyJoinColumn
	@OneToOne(fetch = FetchType.LAZY)
	@XmlElement(name = "", namespace = "")
	User user;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "rank_id", referencedColumnName = "rank_id", nullable = false) })
	@XmlTransient
	Rank rank;

	/**
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 */
	public String getUserId() {
		return this.userId;
	}

	/**
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 */
	public String getName() {
		return this.name;
	}

	/**
	 */
	public void setBirthday(Calendar birthday) {
		this.birthday = birthday;
	}

	/**
	 */
	public Calendar getBirthday() {
		return this.birthday;
	}

	/**
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 */
	public String getGender() {
		return this.gender;
	}

	/**
	 */
	public void setQq(String qq) {
		this.qq = qq;
	}

	/**
	 */
	public String getQq() {
		return this.qq;
	}

	/**
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 */
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	/**
	 */
	public String getMobilePhone() {
		return this.mobilePhone;
	}

	/**
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 */
	public void setBrief(String brief) {
		this.brief = brief;
	}

	/**
	 */
	public String getBrief() {
		return this.brief;
	}

	/**
	 */
	public void setJoinTime(Calendar joinTime) {
		this.joinTime = joinTime;
	}

	/**
	 */
	public Calendar getJoinTime() {
		return this.joinTime;
	}

	/**
	 */
	public void setLastestLoginIp(String lastestLoginIp) {
		this.lastestLoginIp = lastestLoginIp;
	}

	/**
	 */
	public String getLastestLoginIp() {
		return this.lastestLoginIp;
	}

	/**
	 */
	public void setLoginTimes(Integer loginTimes) {
		this.loginTimes = loginTimes;
	}

	/**
	 */
	public Integer getLoginTimes() {
		return this.loginTimes;
	}

	/**
	 */
	public void setFaceUrl(String faceUrl) {
		this.faceUrl = faceUrl;
	}

	/**
	 */
	public String getFaceUrl() {
		return this.faceUrl;
	}

	/**
	 */
	public void setScore(Integer score) {
		this.score = score;
	}

	/**
	 */
	public Integer getScore() {
		return this.score;
	}

	/**
	 */
	public void setHits(Integer hits) {
		this.hits = hits;
	}

	/**
	 */
	public Integer getHits() {
		return this.hits;
	}

	/**
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 */
	public User getUser() {
		return user;
	}

	/**
	 */
	public void setRank(Rank rank) {
		this.rank = rank;
	}

	/**
	 */
	public Rank getRank() {
		return rank;
	}

	/**
	 */
	public UserDetail() {
	}

	/**
	 * Copies the contents of the specified bean into this bean.
	 *
	 */
	public void copy(UserDetail that) {
		setUserId(that.getUserId());
		setName(that.getName());
		setBirthday(that.getBirthday());
		setGender(that.getGender());
		setQq(that.getQq());
		setEmail(that.getEmail());
		setMobilePhone(that.getMobilePhone());
		setAddress(that.getAddress());
		setBrief(that.getBrief());
		setJoinTime(that.getJoinTime());
		setLastestLoginIp(that.getLastestLoginIp());
		setLoginTimes(that.getLoginTimes());
		setFaceUrl(that.getFaceUrl());
		setScore(that.getScore());
		setHits(that.getHits());
		setUser(that.getUser());
		setRank(that.getRank());
	}

	/**
	 * Returns a textual representation of a bean.
	 *
	 */
	public String toString() {

		StringBuilder buffer = new StringBuilder();

		buffer.append("userId=[").append(userId).append("] ");
		buffer.append("name=[").append(name).append("] ");
		buffer.append("birthday=[").append(birthday).append("] ");
		buffer.append("gender=[").append(gender).append("] ");
		buffer.append("qq=[").append(qq).append("] ");
		buffer.append("email=[").append(email).append("] ");
		buffer.append("mobilePhone=[").append(mobilePhone).append("] ");
		buffer.append("address=[").append(address).append("] ");
		buffer.append("brief=[").append(brief).append("] ");
		buffer.append("joinTime=[").append(joinTime).append("] ");
		buffer.append("lastestLoginIp=[").append(lastestLoginIp).append("] ");
		buffer.append("loginTimes=[").append(loginTimes).append("] ");
		buffer.append("faceUrl=[").append(faceUrl).append("] ");
		buffer.append("score=[").append(score).append("] ");
		buffer.append("hits=[").append(hits).append("] ");

		return buffer.toString();
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((userId == null) ? 0 : userId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof UserDetail))
			return false;
		UserDetail equalCheck = (UserDetail) obj;
		if ((userId == null && equalCheck.userId != null) || (userId != null && equalCheck.userId == null))
			return false;
		if (userId != null && !userId.equals(equalCheck.userId))
			return false;
		return true;
	}
}
