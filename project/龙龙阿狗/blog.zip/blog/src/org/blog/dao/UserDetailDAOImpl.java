package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.UserDetail;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage UserDetail entities.
 * 
 */
@Repository("UserDetailDAO")
@Transactional
public class UserDetailDAOImpl extends AbstractJpaDao<UserDetail> implements
		UserDetailDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { UserDetail.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new UserDetailDAOImpl
	 *
	 */
	public UserDetailDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findUserDetailByMobilePhoneContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByMobilePhoneContaining(String mobilePhone) throws DataAccessException {

		return findUserDetailByMobilePhoneContaining(mobilePhone, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByMobilePhoneContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByMobilePhoneContaining(String mobilePhone, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByMobilePhoneContaining", startResult, maxRows, mobilePhone);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByBirthdayBefore
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByBirthdayBefore(java.util.Calendar birthday) throws DataAccessException {

		return findUserDetailByBirthdayBefore(birthday, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByBirthdayBefore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByBirthdayBefore(java.util.Calendar birthday, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByBirthdayBefore", startResult, maxRows, birthday);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByGender
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByGender(String gender) throws DataAccessException {

		return findUserDetailByGender(gender, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByGender
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByGender(String gender, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByGender", startResult, maxRows, gender);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByMobilePhone
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByMobilePhone(String mobilePhone) throws DataAccessException {

		return findUserDetailByMobilePhone(mobilePhone, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByMobilePhone
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByMobilePhone(String mobilePhone, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByMobilePhone", startResult, maxRows, mobilePhone);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByAddressContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByAddressContaining(String address) throws DataAccessException {

		return findUserDetailByAddressContaining(address, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByAddressContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByAddressContaining(String address, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByAddressContaining", startResult, maxRows, address);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByUserId
	 *
	 */
	@Transactional
	public UserDetail findUserDetailByUserId(String userId) throws DataAccessException {

		return findUserDetailByUserId(userId, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByUserId
	 *
	 */

	@Transactional
	public UserDetail findUserDetailByUserId(String userId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findUserDetailByUserId", userId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findUserDetailByGenderContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByGenderContaining(String gender) throws DataAccessException {

		return findUserDetailByGenderContaining(gender, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByGenderContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByGenderContaining(String gender, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByGenderContaining", startResult, maxRows, gender);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByName
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByName(String name) throws DataAccessException {

		return findUserDetailByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByName", startResult, maxRows, name);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByNameContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByNameContaining(String name) throws DataAccessException {

		return findUserDetailByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByEmail
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByEmail(String email) throws DataAccessException {

		return findUserDetailByEmail(email, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByEmail
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByEmail(String email, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByEmail", startResult, maxRows, email);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByFaceUrl
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByFaceUrl(String faceUrl) throws DataAccessException {

		return findUserDetailByFaceUrl(faceUrl, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByFaceUrl
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByFaceUrl(String faceUrl, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByFaceUrl", startResult, maxRows, faceUrl);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByLastestLoginIpContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByLastestLoginIpContaining(String lastestLoginIp) throws DataAccessException {

		return findUserDetailByLastestLoginIpContaining(lastestLoginIp, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByLastestLoginIpContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByLastestLoginIpContaining(String lastestLoginIp, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByLastestLoginIpContaining", startResult, maxRows, lastestLoginIp);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByEmailContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByEmailContaining(String email) throws DataAccessException {

		return findUserDetailByEmailContaining(email, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByEmailContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByEmailContaining(String email, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByEmailContaining", startResult, maxRows, email);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByBrief
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByBrief(String brief) throws DataAccessException {

		return findUserDetailByBrief(brief, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByBrief
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByBrief(String brief, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByBrief", startResult, maxRows, brief);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByAddress
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByAddress(String address) throws DataAccessException {

		return findUserDetailByAddress(address, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByAddress
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByAddress(String address, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByAddress", startResult, maxRows, address);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByQqContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByQqContaining(String qq) throws DataAccessException {

		return findUserDetailByQqContaining(qq, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByQqContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByQqContaining(String qq, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByQqContaining", startResult, maxRows, qq);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByBriefContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByBriefContaining(String brief) throws DataAccessException {

		return findUserDetailByBriefContaining(brief, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByBriefContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByBriefContaining(String brief, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByBriefContaining", startResult, maxRows, brief);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByBirthday
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByBirthday(java.util.Calendar birthday) throws DataAccessException {

		return findUserDetailByBirthday(birthday, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByBirthday
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByBirthday(java.util.Calendar birthday, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByBirthday", startResult, maxRows, birthday);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByJoinTime
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByJoinTime(java.util.Calendar joinTime) throws DataAccessException {

		return findUserDetailByJoinTime(joinTime, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByJoinTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByJoinTime(java.util.Calendar joinTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByJoinTime", startResult, maxRows, joinTime);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByLoginTimes
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByLoginTimes(Integer loginTimes) throws DataAccessException {

		return findUserDetailByLoginTimes(loginTimes, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByLoginTimes
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByLoginTimes(Integer loginTimes, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByLoginTimes", startResult, maxRows, loginTimes);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllUserDetails
	 *
	 */
	@Transactional
	public Set<UserDetail> findAllUserDetails() throws DataAccessException {

		return findAllUserDetails(-1, -1);
	}

	/**
	 * JPQL Query - findAllUserDetails
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findAllUserDetails(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllUserDetails", startResult, maxRows);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByUserIdContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByUserIdContaining(String userId) throws DataAccessException {

		return findUserDetailByUserIdContaining(userId, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByUserIdContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByUserIdContaining(String userId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByUserIdContaining", startResult, maxRows, userId);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByQq
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByQq(String qq) throws DataAccessException {

		return findUserDetailByQq(qq, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByQq
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByQq(String qq, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByQq", startResult, maxRows, qq);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByLastestLoginIp
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByLastestLoginIp(String lastestLoginIp) throws DataAccessException {

		return findUserDetailByLastestLoginIp(lastestLoginIp, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByLastestLoginIp
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByLastestLoginIp(String lastestLoginIp, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByLastestLoginIp", startResult, maxRows, lastestLoginIp);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByScore
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByScore(Integer score) throws DataAccessException {

		return findUserDetailByScore(score, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByScore
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByScore(Integer score, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByScore", startResult, maxRows, score);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByBirthdayAfter
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByBirthdayAfter(java.util.Calendar birthday) throws DataAccessException {

		return findUserDetailByBirthdayAfter(birthday, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByBirthdayAfter
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByBirthdayAfter(java.util.Calendar birthday, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByBirthdayAfter", startResult, maxRows, birthday);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByFaceUrlContaining
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByFaceUrlContaining(String faceUrl) throws DataAccessException {

		return findUserDetailByFaceUrlContaining(faceUrl, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByFaceUrlContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByFaceUrlContaining(String faceUrl, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByFaceUrlContaining", startResult, maxRows, faceUrl);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByHits
	 *
	 */
	@Transactional
	public Set<UserDetail> findUserDetailByHits(Integer hits) throws DataAccessException {

		return findUserDetailByHits(hits, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByHits
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<UserDetail> findUserDetailByHits(Integer hits, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findUserDetailByHits", startResult, maxRows, hits);
		return new LinkedHashSet<UserDetail>(query.getResultList());
	}

	/**
	 * JPQL Query - findUserDetailByPrimaryKey
	 *
	 */
	@Transactional
	public UserDetail findUserDetailByPrimaryKey(String userId) throws DataAccessException {

		return findUserDetailByPrimaryKey(userId, -1, -1);
	}

	/**
	 * JPQL Query - findUserDetailByPrimaryKey
	 *
	 */

	@Transactional
	public UserDetail findUserDetailByPrimaryKey(String userId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findUserDetailByPrimaryKey", userId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(UserDetail entity) {
		return false;
	}
}
