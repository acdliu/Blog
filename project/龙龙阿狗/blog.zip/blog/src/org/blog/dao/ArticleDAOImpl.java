package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Article;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Article entities.
 * 
 */
@Repository("ArticleDAO")
@Transactional
public class ArticleDAOImpl extends AbstractJpaDao<Article> implements
		ArticleDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Article.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ArticleDAOImpl
	 *
	 */
	public ArticleDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findArticleByTitle
	 *
	 */
	@Transactional
	public Set<Article> findArticleByTitle(String title) throws DataAccessException {

		return findArticleByTitle(title, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByTitle
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findArticleByTitle(String title, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findArticleByTitle", startResult, maxRows, title);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByArticleId
	 *
	 */
	@Transactional
	public Article findArticleByArticleId(Integer articleId) throws DataAccessException {

		return findArticleByArticleId(articleId, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByArticleId
	 *
	 */

	@Transactional
	public Article findArticleByArticleId(Integer articleId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findArticleByArticleId", articleId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllArticles
	 *
	 */
	@Transactional
	public Set<Article> findAllArticles() throws DataAccessException {

		return findAllArticles(-1, -1);
	}

	/**
	 * JPQL Query - findAllArticles
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findAllArticles(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllArticles", startResult, maxRows);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByHits
	 *
	 */
	@Transactional
	public Set<Article> findArticleByHits(Integer hits) throws DataAccessException {

		return findArticleByHits(hits, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByHits
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findArticleByHits(Integer hits, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findArticleByHits", startResult, maxRows, hits);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByIsPublic
	 *
	 */
	@Transactional
	public Set<Article> findArticleByIsPublic(Boolean isPublic) throws DataAccessException {

		return findArticleByIsPublic(isPublic, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByIsPublic
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findArticleByIsPublic(Boolean isPublic, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findArticleByIsPublic", startResult, maxRows, isPublic);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByTitleContaining
	 *
	 */
	@Transactional
	public Set<Article> findArticleByTitleContaining(String title) throws DataAccessException {

		return findArticleByTitleContaining(title, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByTitleContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findArticleByTitleContaining(String title, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findArticleByTitleContaining", startResult, maxRows, title);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByContent
	 *
	 */
	@Transactional
	public Set<Article> findArticleByContent(String content) throws DataAccessException {

		return findArticleByContent(content, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByContent
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findArticleByContent(String content, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findArticleByContent", startResult, maxRows, content);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByCreateTime
	 *
	 */
	@Transactional
	public Set<Article> findArticleByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findArticleByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Article> findArticleByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findArticleByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<Article>(query.getResultList());
	}

	/**
	 * JPQL Query - findArticleByPrimaryKey
	 *
	 */
	@Transactional
	public Article findArticleByPrimaryKey(Integer articleId) throws DataAccessException {

		return findArticleByPrimaryKey(articleId, -1, -1);
	}

	/**
	 * JPQL Query - findArticleByPrimaryKey
	 *
	 */

	@Transactional
	public Article findArticleByPrimaryKey(Integer articleId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findArticleByPrimaryKey", articleId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Article entity) {
		return false;
	}
}
