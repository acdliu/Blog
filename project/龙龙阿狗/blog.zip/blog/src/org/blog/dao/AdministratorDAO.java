package org.blog.dao;

import java.util.Set;

import org.blog.domain.Administrator;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Administrator entities.
 * 
 */
public interface AdministratorDAO extends JpaDao<Administrator> {

	/**
	 * JPQL Query - findAdministratorByName
	 *
	 */
	public Set<Administrator> findAdministratorByName(String name) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByName
	 *
	 */
	public Set<Administrator> findAdministratorByName(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByNameContaining
	 *
	 */
	public Set<Administrator> findAdministratorByNameContaining(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByNameContaining
	 *
	 */
	public Set<Administrator> findAdministratorByNameContaining(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllAdministrators
	 *
	 */
	public Set<Administrator> findAllAdministrators() throws DataAccessException;

	/**
	 * JPQL Query - findAllAdministrators
	 *
	 */
	public Set<Administrator> findAllAdministrators(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByPrimaryKey
	 *
	 */
	public Administrator findAdministratorByPrimaryKey(String administratorId) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByPrimaryKey
	 *
	 */
	public Administrator findAdministratorByPrimaryKey(String administratorId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByAdministratorIdContaining
	 *
	 */
	public Set<Administrator> findAdministratorByAdministratorIdContaining(String administratorId_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByAdministratorIdContaining
	 *
	 */
	public Set<Administrator> findAdministratorByAdministratorIdContaining(String administratorId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByPasswordContaining
	 *
	 */
	public Set<Administrator> findAdministratorByPasswordContaining(String password) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByPasswordContaining
	 *
	 */
	public Set<Administrator> findAdministratorByPasswordContaining(String password, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByAdministratorId
	 *
	 */
	public Administrator findAdministratorByAdministratorId(String administratorId_2) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByAdministratorId
	 *
	 */
	public Administrator findAdministratorByAdministratorId(String administratorId_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByPassword
	 *
	 */
	public Set<Administrator> findAdministratorByPassword(String password_1) throws DataAccessException;

	/**
	 * JPQL Query - findAdministratorByPassword
	 *
	 */
	public Set<Administrator> findAdministratorByPassword(String password_1, int startResult, int maxRows) throws DataAccessException;

}