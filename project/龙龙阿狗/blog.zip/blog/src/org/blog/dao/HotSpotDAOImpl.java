package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.HotSpot;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage HotSpot entities.
 * 
 */
@Repository("HotSpotDAO")
@Transactional
public class HotSpotDAOImpl extends AbstractJpaDao<HotSpot> implements
		HotSpotDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { HotSpot.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new HotSpotDAOImpl
	 *
	 */
	public HotSpotDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findHotSpotByIsArticle
	 *
	 */
	@Transactional
	public Set<HotSpot> findHotSpotByIsArticle(Boolean isArticle) throws DataAccessException {

		return findHotSpotByIsArticle(isArticle, -1, -1);
	}

	/**
	 * JPQL Query - findHotSpotByIsArticle
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<HotSpot> findHotSpotByIsArticle(Boolean isArticle, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findHotSpotByIsArticle", startResult, maxRows, isArticle);
		return new LinkedHashSet<HotSpot>(query.getResultList());
	}

	/**
	 * JPQL Query - findHotSpotByPrimaryKey
	 *
	 */
	@Transactional
	public HotSpot findHotSpotByPrimaryKey(Integer hotSpotId) throws DataAccessException {

		return findHotSpotByPrimaryKey(hotSpotId, -1, -1);
	}

	/**
	 * JPQL Query - findHotSpotByPrimaryKey
	 *
	 */

	@Transactional
	public HotSpot findHotSpotByPrimaryKey(Integer hotSpotId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findHotSpotByPrimaryKey", hotSpotId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findHotSpotByHotSpotId
	 *
	 */
	@Transactional
	public HotSpot findHotSpotByHotSpotId(Integer hotSpotId) throws DataAccessException {

		return findHotSpotByHotSpotId(hotSpotId, -1, -1);
	}

	/**
	 * JPQL Query - findHotSpotByHotSpotId
	 *
	 */

	@Transactional
	public HotSpot findHotSpotByHotSpotId(Integer hotSpotId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findHotSpotByHotSpotId", hotSpotId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findHotSpotByCreateTime
	 *
	 */
	@Transactional
	public Set<HotSpot> findHotSpotByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findHotSpotByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findHotSpotByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<HotSpot> findHotSpotByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findHotSpotByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<HotSpot>(query.getResultList());
	}

	/**
	 * JPQL Query - findHotSpotByArticleId
	 *
	 */
	@Transactional
	public Set<HotSpot> findHotSpotByArticleId(Integer articleId) throws DataAccessException {

		return findHotSpotByArticleId(articleId, -1, -1);
	}

	/**
	 * JPQL Query - findHotSpotByArticleId
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<HotSpot> findHotSpotByArticleId(Integer articleId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findHotSpotByArticleId", startResult, maxRows, articleId);
		return new LinkedHashSet<HotSpot>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllHotSpots
	 *
	 */
	@Transactional
	public Set<HotSpot> findAllHotSpots() throws DataAccessException {

		return findAllHotSpots(-1, -1);
	}

	/**
	 * JPQL Query - findAllHotSpots
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<HotSpot> findAllHotSpots(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllHotSpots", startResult, maxRows);
		return new LinkedHashSet<HotSpot>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(HotSpot entity) {
		return true;
	}
}
