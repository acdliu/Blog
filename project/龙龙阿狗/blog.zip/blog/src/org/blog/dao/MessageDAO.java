package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.Message;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Message entities.
 * 
 */
public interface MessageDAO extends JpaDao<Message> {

	/**
	 * JPQL Query - findMessageByIsSystemMessage
	 *
	 */
	public Set<Message> findMessageByIsSystemMessage(Boolean isSystemMessage) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByIsSystemMessage
	 *
	 */
	public Set<Message> findMessageByIsSystemMessage(Boolean isSystemMessage, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByContent
	 *
	 */
	public Set<Message> findMessageByContent(String content) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByContent
	 *
	 */
	public Set<Message> findMessageByContent(String content, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByMessageId
	 *
	 */
	public Message findMessageByMessageId(Integer messageId) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByMessageId
	 *
	 */
	public Message findMessageByMessageId(Integer messageId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByContentContaining
	 *
	 */
	public Set<Message> findMessageByContentContaining(String content_1) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByContentContaining
	 *
	 */
	public Set<Message> findMessageByContentContaining(String content_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByIsRead
	 *
	 */
	public Set<Message> findMessageByIsRead(Boolean isRead) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByIsRead
	 *
	 */
	public Set<Message> findMessageByIsRead(Boolean isRead, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllMessages
	 *
	 */
	public Set<Message> findAllMessages() throws DataAccessException;

	/**
	 * JPQL Query - findAllMessages
	 *
	 */
	public Set<Message> findAllMessages(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByCreateTime
	 *
	 */
	public Set<Message> findMessageByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByCreateTime
	 *
	 */
	public Set<Message> findMessageByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByPrimaryKey
	 *
	 */
	public Message findMessageByPrimaryKey(Integer messageId_1) throws DataAccessException;

	/**
	 * JPQL Query - findMessageByPrimaryKey
	 *
	 */
	public Message findMessageByPrimaryKey(Integer messageId_1, int startResult, int maxRows) throws DataAccessException;

}