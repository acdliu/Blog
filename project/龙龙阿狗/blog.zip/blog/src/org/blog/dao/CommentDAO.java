package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.Comment;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Comment entities.
 * 
 */
public interface CommentDAO extends JpaDao<Comment> {

	/**
	 * JPQL Query - findCommentByPrimaryKey
	 *
	 */
	public Comment findCommentByPrimaryKey(Integer commentId) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByPrimaryKey
	 *
	 */
	public Comment findCommentByPrimaryKey(Integer commentId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByCommentTime
	 *
	 */
	public Set<Comment> findCommentByCommentTime(java.util.Calendar commentTime) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByCommentTime
	 *
	 */
	public Set<Comment> findCommentByCommentTime(Calendar commentTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByIsMoodComment
	 *
	 */
	public Set<Comment> findCommentByIsMoodComment(Boolean isMoodComment) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByIsMoodComment
	 *
	 */
	public Set<Comment> findCommentByIsMoodComment(Boolean isMoodComment, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllComments
	 *
	 */
	public Set<Comment> findAllComments() throws DataAccessException;

	/**
	 * JPQL Query - findAllComments
	 *
	 */
	public Set<Comment> findAllComments(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByIsPublic
	 *
	 */
	public Set<Comment> findCommentByIsPublic(Boolean isPublic) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByIsPublic
	 *
	 */
	public Set<Comment> findCommentByIsPublic(Boolean isPublic, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByCommentId
	 *
	 */
	public Comment findCommentByCommentId(Integer commentId_1) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByCommentId
	 *
	 */
	public Comment findCommentByCommentId(Integer commentId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByContent
	 *
	 */
	public Set<Comment> findCommentByContent(String content) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByContent
	 *
	 */
	public Set<Comment> findCommentByContent(String content, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByArticleId
	 *
	 */
	public Set<Comment> findCommentByArticleId(Integer articleId) throws DataAccessException;

	/**
	 * JPQL Query - findCommentByArticleId
	 *
	 */
	public Set<Comment> findCommentByArticleId(Integer articleId, int startResult, int maxRows) throws DataAccessException;

}