package org.blog.dao;

import java.util.Set;

import org.blog.domain.Rank;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Rank entities.
 * 
 */
public interface RankDAO extends JpaDao<Rank> {

	/**
	 * JPQL Query - findRankByPrimaryKey
	 *
	 */
	public Rank findRankByPrimaryKey(Integer rankId) throws DataAccessException;

	/**
	 * JPQL Query - findRankByPrimaryKey
	 *
	 */
	public Rank findRankByPrimaryKey(Integer rankId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRankByNameContaining
	 *
	 */
	public Set<Rank> findRankByNameContaining(String name) throws DataAccessException;

	/**
	 * JPQL Query - findRankByNameContaining
	 *
	 */
	public Set<Rank> findRankByNameContaining(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllRanks
	 *
	 */
	public Set<Rank> findAllRanks() throws DataAccessException;

	/**
	 * JPQL Query - findAllRanks
	 *
	 */
	public Set<Rank> findAllRanks(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRankByName
	 *
	 */
	public Set<Rank> findRankByName(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findRankByName
	 *
	 */
	public Set<Rank> findRankByName(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRankByRankId
	 *
	 */
	public Rank findRankByRankId(Integer rankId_1) throws DataAccessException;

	/**
	 * JPQL Query - findRankByRankId
	 *
	 */
	public Rank findRankByRankId(Integer rankId_1, int startResult, int maxRows) throws DataAccessException;

}