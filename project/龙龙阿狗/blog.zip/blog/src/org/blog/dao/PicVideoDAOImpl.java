package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.PicVideo;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage PicVideo entities.
 * 
 */
@Repository("PicVideoDAO")
@Transactional
public class PicVideoDAOImpl extends AbstractJpaDao<PicVideo> implements
		PicVideoDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { PicVideo.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new PicVideoDAOImpl
	 *
	 */
	public PicVideoDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findPicVideoByIsPicture
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByIsPicture(Boolean isPicture) throws DataAccessException {

		return findPicVideoByIsPicture(isPicture, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByIsPicture
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByIsPicture(Boolean isPicture, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByIsPicture", startResult, maxRows, isPicture);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByUploadTime
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByUploadTime(java.util.Calendar uploadTime) throws DataAccessException {

		return findPicVideoByUploadTime(uploadTime, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByUploadTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByUploadTime(java.util.Calendar uploadTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByUploadTime", startResult, maxRows, uploadTime);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByHits
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByHits(Integer hits) throws DataAccessException {

		return findPicVideoByHits(hits, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByHits
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByHits(Integer hits, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByHits", startResult, maxRows, hits);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByPicVideoId
	 *
	 */
	@Transactional
	public PicVideo findPicVideoByPicVideoId(Integer picVideoId) throws DataAccessException {

		return findPicVideoByPicVideoId(picVideoId, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByPicVideoId
	 *
	 */

	@Transactional
	public PicVideo findPicVideoByPicVideoId(Integer picVideoId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findPicVideoByPicVideoId", picVideoId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findPicVideoByPictureUrl
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByPictureUrl(String pictureUrl) throws DataAccessException {

		return findPicVideoByPictureUrl(pictureUrl, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByPictureUrl
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByPictureUrl(String pictureUrl, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByPictureUrl", startResult, maxRows, pictureUrl);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByPrimaryKey
	 *
	 */
	@Transactional
	public PicVideo findPicVideoByPrimaryKey(Integer picVideoId) throws DataAccessException {

		return findPicVideoByPrimaryKey(picVideoId, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByPrimaryKey
	 *
	 */

	@Transactional
	public PicVideo findPicVideoByPrimaryKey(Integer picVideoId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findPicVideoByPrimaryKey", picVideoId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllPicVideos
	 *
	 */
	@Transactional
	public Set<PicVideo> findAllPicVideos() throws DataAccessException {

		return findAllPicVideos(-1, -1);
	}

	/**
	 * JPQL Query - findAllPicVideos
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findAllPicVideos(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllPicVideos", startResult, maxRows);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByBriefContaining
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByBriefContaining(String brief) throws DataAccessException {

		return findPicVideoByBriefContaining(brief, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByBriefContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByBriefContaining(String brief, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByBriefContaining", startResult, maxRows, brief);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByBrief
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByBrief(String brief) throws DataAccessException {

		return findPicVideoByBrief(brief, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByBrief
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByBrief(String brief, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByBrief", startResult, maxRows, brief);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoByPictureUrlContaining
	 *
	 */
	@Transactional
	public Set<PicVideo> findPicVideoByPictureUrlContaining(String pictureUrl) throws DataAccessException {

		return findPicVideoByPictureUrlContaining(pictureUrl, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoByPictureUrlContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideo> findPicVideoByPictureUrlContaining(String pictureUrl, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoByPictureUrlContaining", startResult, maxRows, pictureUrl);
		return new LinkedHashSet<PicVideo>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(PicVideo entity) {
		return true;
	}
}
