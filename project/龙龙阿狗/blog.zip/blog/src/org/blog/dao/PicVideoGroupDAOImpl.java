package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.PicVideoGroup;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage PicVideoGroup entities.
 * 
 */
@Repository("PicVideoGroupDAO")
@Transactional
public class PicVideoGroupDAOImpl extends AbstractJpaDao<PicVideoGroup>
		implements PicVideoGroupDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { PicVideoGroup.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new PicVideoGroupDAOImpl
	 *
	 */
	public PicVideoGroupDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findPicVideoGroupByHits
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByHits(Integer hits) throws DataAccessException {

		return findPicVideoGroupByHits(hits, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByHits
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByHits(Integer hits, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoGroupByHits", startResult, maxRows, hits);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoGroupByTitleContaining
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByTitleContaining(String title) throws DataAccessException {

		return findPicVideoGroupByTitleContaining(title, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByTitleContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByTitleContaining(String title, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoGroupByTitleContaining", startResult, maxRows, title);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoGroupByPrimaryKey
	 *
	 */
	@Transactional
	public PicVideoGroup findPicVideoGroupByPrimaryKey(Integer picVideoGroupId) throws DataAccessException {

		return findPicVideoGroupByPrimaryKey(picVideoGroupId, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByPrimaryKey
	 *
	 */

	@Transactional
	public PicVideoGroup findPicVideoGroupByPrimaryKey(Integer picVideoGroupId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findPicVideoGroupByPrimaryKey", picVideoGroupId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findPicVideoGroupByCreateTime
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findPicVideoGroupByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoGroupByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoGroupByIsPicGroup
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByIsPicGroup(Boolean isPicGroup) throws DataAccessException {

		return findPicVideoGroupByIsPicGroup(isPicGroup, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByIsPicGroup
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByIsPicGroup(Boolean isPicGroup, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoGroupByIsPicGroup", startResult, maxRows, isPicGroup);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllPicVideoGroups
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findAllPicVideoGroups() throws DataAccessException {

		return findAllPicVideoGroups(-1, -1);
	}

	/**
	 * JPQL Query - findAllPicVideoGroups
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findAllPicVideoGroups(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllPicVideoGroups", startResult, maxRows);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoGroupByPicVideoGroupId
	 *
	 */
	@Transactional
	public PicVideoGroup findPicVideoGroupByPicVideoGroupId(Integer picVideoGroupId) throws DataAccessException {

		return findPicVideoGroupByPicVideoGroupId(picVideoGroupId, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByPicVideoGroupId
	 *
	 */

	@Transactional
	public PicVideoGroup findPicVideoGroupByPicVideoGroupId(Integer picVideoGroupId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findPicVideoGroupByPicVideoGroupId", picVideoGroupId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findPicVideoGroupByIsPublic
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByIsPublic(Boolean isPublic) throws DataAccessException {

		return findPicVideoGroupByIsPublic(isPublic, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByIsPublic
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByIsPublic(Boolean isPublic, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoGroupByIsPublic", startResult, maxRows, isPublic);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * JPQL Query - findPicVideoGroupByTitle
	 *
	 */
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByTitle(String title) throws DataAccessException {

		return findPicVideoGroupByTitle(title, -1, -1);
	}

	/**
	 * JPQL Query - findPicVideoGroupByTitle
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PicVideoGroup> findPicVideoGroupByTitle(String title, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findPicVideoGroupByTitle", startResult, maxRows, title);
		return new LinkedHashSet<PicVideoGroup>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(PicVideoGroup entity) {
		return true;
	}
}
