package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.HotSpot;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage HotSpot entities.
 * 
 */
public interface HotSpotDAO extends JpaDao<HotSpot> {

	/**
	 * JPQL Query - findHotSpotByIsArticle
	 *
	 */
	public Set<HotSpot> findHotSpotByIsArticle(Boolean isArticle) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByIsArticle
	 *
	 */
	public Set<HotSpot> findHotSpotByIsArticle(Boolean isArticle, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByPrimaryKey
	 *
	 */
	public HotSpot findHotSpotByPrimaryKey(Integer hotSpotId) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByPrimaryKey
	 *
	 */
	public HotSpot findHotSpotByPrimaryKey(Integer hotSpotId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByHotSpotId
	 *
	 */
	public HotSpot findHotSpotByHotSpotId(Integer hotSpotId_1) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByHotSpotId
	 *
	 */
	public HotSpot findHotSpotByHotSpotId(Integer hotSpotId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByCreateTime
	 *
	 */
	public Set<HotSpot> findHotSpotByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByCreateTime
	 *
	 */
	public Set<HotSpot> findHotSpotByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByArticleId
	 *
	 */
	public Set<HotSpot> findHotSpotByArticleId(Integer articleId) throws DataAccessException;

	/**
	 * JPQL Query - findHotSpotByArticleId
	 *
	 */
	public Set<HotSpot> findHotSpotByArticleId(Integer articleId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllHotSpots
	 *
	 */
	public Set<HotSpot> findAllHotSpots() throws DataAccessException;

	/**
	 * JPQL Query - findAllHotSpots
	 *
	 */
	public Set<HotSpot> findAllHotSpots(int startResult, int maxRows) throws DataAccessException;

}