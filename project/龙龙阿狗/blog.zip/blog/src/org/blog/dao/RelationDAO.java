package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.Relation;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Relation entities.
 * 
 */
public interface RelationDAO extends JpaDao<Relation> {

	
	public Set<Relation> findRelationById(String Id);
	
	
	
	
	/**
	 * JPQL Query - findRelationByIsBlacker
	 *
	 */
	public Set<Relation> findRelationByIsBlacker(Boolean isBlacker) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByIsBlacker
	 *
	 */
	public Set<Relation> findRelationByIsBlacker(Boolean isBlacker, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByPrimaryKey
	 *
	 */
	public Relation findRelationByPrimaryKey(Integer relationId) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByPrimaryKey
	 *
	 */
	public Relation findRelationByPrimaryKey(Integer relationId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllRelations
	 *
	 */
	public Set<Relation> findAllRelations() throws DataAccessException;

	/**
	 * JPQL Query - findAllRelations
	 *
	 */
	public Set<Relation> findAllRelations(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByRelationId
	 *
	 */
	public Relation findRelationByRelationId(Integer relationId_1) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByRelationId
	 *
	 */
	public Relation findRelationByRelationId(Integer relationId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByCreateTime
	 *
	 */
	public Set<Relation> findRelationByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findRelationByCreateTime
	 *
	 */
	public Set<Relation> findRelationByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

}