package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Relation;
import org.skyway.spring.util.dao.AbstractJpaDao;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Relation entities.
 * 
 */
@Repository("RelationDAO")
@Transactional
public class RelationDAOImpl extends AbstractJpaDao<Relation> implements
		RelationDAO {

	@Transactional
	public Set<Relation> findRelationById(String Id){
		Set<Relation> relation = this.findAllRelations(); 
		Set<Relation> relation1 = new HashSet<Relation>();
		Iterator<Relation> it = relation.iterator();  
		while (it.hasNext()) {  
		  Relation r = it.next();
		  if(r.getUserByFanId().getUserId()==Id){
			  relation1.add(r);
		  }
		}  
		return relation1;
	}
	
	
	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Relation.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new RelationDAOImpl
	 *
	 */
	public RelationDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findRelationByIsBlacker
	 *
	 */
	@Transactional
	public Set<Relation> findRelationByIsBlacker(Boolean isBlacker) throws DataAccessException {

		return findRelationByIsBlacker(isBlacker, -1, -1);
	}

	/**
	 * JPQL Query - findRelationByIsBlacker
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Relation> findRelationByIsBlacker(Boolean isBlacker, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRelationByIsBlacker", startResult, maxRows, isBlacker);
		return new LinkedHashSet<Relation>(query.getResultList());
	}

	/**
	 * JPQL Query - findRelationByPrimaryKey
	 *
	 */
	@Transactional
	public Relation findRelationByPrimaryKey(Integer relationId) throws DataAccessException {

		return findRelationByPrimaryKey(relationId, -1, -1);
	}

	/**
	 * JPQL Query - findRelationByPrimaryKey
	 *
	 */

	@Transactional
	public Relation findRelationByPrimaryKey(Integer relationId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findRelationByPrimaryKey", relationId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAllRelations
	 *
	 */
	@Transactional
	public Set<Relation> findAllRelations() throws DataAccessException {

		return findAllRelations(-1, -1);
	}

	/**
	 * JPQL Query - findAllRelations
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Relation> findAllRelations(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllRelations", startResult, maxRows);
		return new LinkedHashSet<Relation>(query.getResultList());
	}

	/**
	 * JPQL Query - findRelationByRelationId
	 *
	 */
	@Transactional
	public Relation findRelationByRelationId(Integer relationId) throws DataAccessException {

		return findRelationByRelationId(relationId, -1, -1);
	}

	/**
	 * JPQL Query - findRelationByRelationId
	 *
	 */

	@Transactional
	public Relation findRelationByRelationId(Integer relationId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findRelationByRelationId", relationId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findRelationByCreateTime
	 *
	 */
	@Transactional
	public Set<Relation> findRelationByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findRelationByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findRelationByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Relation> findRelationByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRelationByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<Relation>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Relation entity) {
		if(entity==null){
			return true;
			}
		else{
			return false;
			}
	}
}
