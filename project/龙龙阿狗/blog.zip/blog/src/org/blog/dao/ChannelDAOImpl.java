package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Channel;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Channel entities.
 * 
 */
@Repository("ChannelDAO")
@Transactional
public class ChannelDAOImpl extends AbstractJpaDao<Channel> implements
		ChannelDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Channel.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new ChannelDAOImpl
	 *
	 */
	public ChannelDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findChannelByPrimaryKey
	 *
	 */
	@Transactional
	public Channel findChannelByPrimaryKey(Integer channelId) throws DataAccessException {

		return findChannelByPrimaryKey(channelId, -1, -1);
	}

	/**
	 * JPQL Query - findChannelByPrimaryKey
	 *
	 */

	@Transactional
	public Channel findChannelByPrimaryKey(Integer channelId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findChannelByPrimaryKey", channelId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findChannelByName
	 *
	 */
	@Transactional
	public Set<Channel> findChannelByName(String name) throws DataAccessException {

		return findChannelByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findChannelByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Channel> findChannelByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findChannelByName", startResult, maxRows, name);
		return new LinkedHashSet<Channel>(query.getResultList());
	}

	/**
	 * JPQL Query - findChannelByNameContaining
	 *
	 */
	@Transactional
	public Set<Channel> findChannelByNameContaining(String name) throws DataAccessException {

		return findChannelByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findChannelByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Channel> findChannelByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findChannelByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<Channel>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllChannels
	 *
	 */
	@Transactional
	public Set<Channel> findAllChannels() throws DataAccessException {

		return findAllChannels(-1, -1);
	}

	/**
	 * JPQL Query - findAllChannels
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Channel> findAllChannels(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllChannels", startResult, maxRows);
		return new LinkedHashSet<Channel>(query.getResultList());
	}

	/**
	 * JPQL Query - findChannelByChannelId
	 *
	 */
	@Transactional
	public Channel findChannelByChannelId(Integer channelId) throws DataAccessException {

		return findChannelByChannelId(channelId, -1, -1);
	}

	/**
	 * JPQL Query - findChannelByChannelId
	 *
	 */

	@Transactional
	public Channel findChannelByChannelId(Integer channelId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findChannelByChannelId", channelId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findChannelByCreateTime
	 *
	 */
	@Transactional
	public Set<Channel> findChannelByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findChannelByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findChannelByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Channel> findChannelByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findChannelByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<Channel>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Channel entity) {
		return true;
	}
}
