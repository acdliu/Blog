package org.blog.dao;

import java.util.Set;

import org.blog.domain.Category;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Category entities.
 * 
 */
public interface CategoryDAO extends JpaDao<Category> {

	/**
	 * JPQL Query - findCategoryByNameContaining
	 *
	 */
	public Set<Category> findCategoryByNameContaining(String name) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByNameContaining
	 *
	 */
	public Set<Category> findCategoryByNameContaining(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */
	public Category findCategoryByPrimaryKey(Integer categoryId) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */
	public Category findCategoryByPrimaryKey(Integer categoryId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByName
	 *
	 */
	public Set<Category> findCategoryByName(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByName
	 *
	 */
	public Set<Category> findCategoryByName(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */
	public Set<Category> findAllCategorys() throws DataAccessException;

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */
	public Set<Category> findAllCategorys(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */
	public Category findCategoryByCategoryId(Integer categoryId_1) throws DataAccessException;

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */
	public Category findCategoryByCategoryId(Integer categoryId_1, int startResult, int maxRows) throws DataAccessException;

}