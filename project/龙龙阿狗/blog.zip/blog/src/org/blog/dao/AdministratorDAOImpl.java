package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Administrator;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Administrator entities.
 * 
 */
@Repository("AdministratorDAO")
@Transactional
public class AdministratorDAOImpl extends AbstractJpaDao<Administrator>
		implements AdministratorDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Administrator.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new AdministratorDAOImpl
	 *
	 */
	public AdministratorDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findAdministratorByName
	 *
	 */
	@Transactional
	public Set<Administrator> findAdministratorByName(String name) throws DataAccessException {

		return findAdministratorByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Administrator> findAdministratorByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdministratorByName", startResult, maxRows, name);
		return new LinkedHashSet<Administrator>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdministratorByNameContaining
	 *
	 */
	@Transactional
	public Set<Administrator> findAdministratorByNameContaining(String name) throws DataAccessException {

		return findAdministratorByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Administrator> findAdministratorByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdministratorByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<Administrator>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllAdministrators
	 *
	 */
	@Transactional
	public Set<Administrator> findAllAdministrators() throws DataAccessException {

		return findAllAdministrators(-1, -1);
	}

	/**
	 * JPQL Query - findAllAdministrators
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Administrator> findAllAdministrators(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllAdministrators", startResult, maxRows);
		return new LinkedHashSet<Administrator>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdministratorByPrimaryKey
	 *
	 */
	@Transactional
	public Administrator findAdministratorByPrimaryKey(String administratorId) throws DataAccessException {

		return findAdministratorByPrimaryKey(administratorId, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByPrimaryKey
	 *
	 */

	@Transactional
	public Administrator findAdministratorByPrimaryKey(String administratorId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findAdministratorByPrimaryKey", administratorId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAdministratorByAdministratorIdContaining
	 *
	 */
	@Transactional
	public Set<Administrator> findAdministratorByAdministratorIdContaining(String administratorId) throws DataAccessException {

		return findAdministratorByAdministratorIdContaining(administratorId, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByAdministratorIdContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Administrator> findAdministratorByAdministratorIdContaining(String administratorId, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdministratorByAdministratorIdContaining", startResult, maxRows, administratorId);
		return new LinkedHashSet<Administrator>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdministratorByPasswordContaining
	 *
	 */
	@Transactional
	public Set<Administrator> findAdministratorByPasswordContaining(String password) throws DataAccessException {

		return findAdministratorByPasswordContaining(password, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByPasswordContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Administrator> findAdministratorByPasswordContaining(String password, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdministratorByPasswordContaining", startResult, maxRows, password);
		return new LinkedHashSet<Administrator>(query.getResultList());
	}

	/**
	 * JPQL Query - findAdministratorByAdministratorId
	 *
	 */
	@Transactional
	public Administrator findAdministratorByAdministratorId(String administratorId) throws DataAccessException {

		return findAdministratorByAdministratorId(administratorId, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByAdministratorId
	 *
	 */

	@Transactional
	public Administrator findAdministratorByAdministratorId(String administratorId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findAdministratorByAdministratorId", administratorId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findAdministratorByPassword
	 *
	 */
	@Transactional
	public Set<Administrator> findAdministratorByPassword(String password) throws DataAccessException {

		return findAdministratorByPassword(password, -1, -1);
	}

	/**
	 * JPQL Query - findAdministratorByPassword
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Administrator> findAdministratorByPassword(String password, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAdministratorByPassword", startResult, maxRows, password);
		return new LinkedHashSet<Administrator>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Administrator entity) {
		return true;
	}
}
