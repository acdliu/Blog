package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.UserDetail;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage UserDetail entities.
 * 
 */
public interface UserDetailDAO extends JpaDao<UserDetail> {

	/**
	 * JPQL Query - findUserDetailByMobilePhoneContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByMobilePhoneContaining(String mobilePhone) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByMobilePhoneContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByMobilePhoneContaining(String mobilePhone, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBirthdayBefore
	 *
	 */
	public Set<UserDetail> findUserDetailByBirthdayBefore(java.util.Calendar birthday) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBirthdayBefore
	 *
	 */
	public Set<UserDetail> findUserDetailByBirthdayBefore(Calendar birthday, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByGender
	 *
	 */
	public Set<UserDetail> findUserDetailByGender(String gender) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByGender
	 *
	 */
	public Set<UserDetail> findUserDetailByGender(String gender, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByMobilePhone
	 *
	 */
	public Set<UserDetail> findUserDetailByMobilePhone(String mobilePhone_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByMobilePhone
	 *
	 */
	public Set<UserDetail> findUserDetailByMobilePhone(String mobilePhone_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByAddressContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByAddressContaining(String address) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByAddressContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByAddressContaining(String address, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByUserId
	 *
	 */
	public UserDetail findUserDetailByUserId(String userId) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByUserId
	 *
	 */
	public UserDetail findUserDetailByUserId(String userId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByGenderContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByGenderContaining(String gender_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByGenderContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByGenderContaining(String gender_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByName
	 *
	 */
	public Set<UserDetail> findUserDetailByName(String name) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByName
	 *
	 */
	public Set<UserDetail> findUserDetailByName(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByNameContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByNameContaining(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByNameContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByNameContaining(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByEmail
	 *
	 */
	public Set<UserDetail> findUserDetailByEmail(String email) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByEmail
	 *
	 */
	public Set<UserDetail> findUserDetailByEmail(String email, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByFaceUrl
	 *
	 */
	public Set<UserDetail> findUserDetailByFaceUrl(String faceUrl) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByFaceUrl
	 *
	 */
	public Set<UserDetail> findUserDetailByFaceUrl(String faceUrl, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByLastestLoginIpContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByLastestLoginIpContaining(String lastestLoginIp) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByLastestLoginIpContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByLastestLoginIpContaining(String lastestLoginIp, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByEmailContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByEmailContaining(String email_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByEmailContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByEmailContaining(String email_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBrief
	 *
	 */
	public Set<UserDetail> findUserDetailByBrief(String brief) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBrief
	 *
	 */
	public Set<UserDetail> findUserDetailByBrief(String brief, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByAddress
	 *
	 */
	public Set<UserDetail> findUserDetailByAddress(String address_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByAddress
	 *
	 */
	public Set<UserDetail> findUserDetailByAddress(String address_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByQqContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByQqContaining(String qq) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByQqContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByQqContaining(String qq, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBriefContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByBriefContaining(String brief_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBriefContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByBriefContaining(String brief_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBirthday
	 *
	 */
	public Set<UserDetail> findUserDetailByBirthday(java.util.Calendar birthday_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBirthday
	 *
	 */
	public Set<UserDetail> findUserDetailByBirthday(Calendar birthday_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByJoinTime
	 *
	 */
	public Set<UserDetail> findUserDetailByJoinTime(java.util.Calendar joinTime) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByJoinTime
	 *
	 */
	public Set<UserDetail> findUserDetailByJoinTime(Calendar joinTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByLoginTimes
	 *
	 */
	public Set<UserDetail> findUserDetailByLoginTimes(Integer loginTimes) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByLoginTimes
	 *
	 */
	public Set<UserDetail> findUserDetailByLoginTimes(Integer loginTimes, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllUserDetails
	 *
	 */
	public Set<UserDetail> findAllUserDetails() throws DataAccessException;

	/**
	 * JPQL Query - findAllUserDetails
	 *
	 */
	public Set<UserDetail> findAllUserDetails(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByUserIdContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByUserIdContaining(String userId_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByUserIdContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByUserIdContaining(String userId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByQq
	 *
	 */
	public Set<UserDetail> findUserDetailByQq(String qq_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByQq
	 *
	 */
	public Set<UserDetail> findUserDetailByQq(String qq_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByLastestLoginIp
	 *
	 */
	public Set<UserDetail> findUserDetailByLastestLoginIp(String lastestLoginIp_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByLastestLoginIp
	 *
	 */
	public Set<UserDetail> findUserDetailByLastestLoginIp(String lastestLoginIp_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByScore
	 *
	 */
	public Set<UserDetail> findUserDetailByScore(Integer score) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByScore
	 *
	 */
	public Set<UserDetail> findUserDetailByScore(Integer score, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBirthdayAfter
	 *
	 */
	public Set<UserDetail> findUserDetailByBirthdayAfter(java.util.Calendar birthday_2) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByBirthdayAfter
	 *
	 */
	public Set<UserDetail> findUserDetailByBirthdayAfter(Calendar birthday_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByFaceUrlContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByFaceUrlContaining(String faceUrl_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByFaceUrlContaining
	 *
	 */
	public Set<UserDetail> findUserDetailByFaceUrlContaining(String faceUrl_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByHits
	 *
	 */
	public Set<UserDetail> findUserDetailByHits(Integer hits) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByHits
	 *
	 */
	public Set<UserDetail> findUserDetailByHits(Integer hits, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByPrimaryKey
	 *
	 */
	public UserDetail findUserDetailByPrimaryKey(String userId_2) throws DataAccessException;

	/**
	 * JPQL Query - findUserDetailByPrimaryKey
	 *
	 */
	public UserDetail findUserDetailByPrimaryKey(String userId_2, int startResult, int maxRows) throws DataAccessException;

}