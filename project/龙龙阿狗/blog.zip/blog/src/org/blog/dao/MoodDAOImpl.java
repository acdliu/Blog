package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Mood;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Mood entities.
 * 
 */
@Repository("MoodDAO")
@Transactional
public class MoodDAOImpl extends AbstractJpaDao<Mood> implements MoodDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Mood.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new MoodDAOImpl
	 *
	 */
	public MoodDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findMoodByContentContaining
	 *
	 */
	@Transactional
	public Set<Mood> findMoodByContentContaining(String content) throws DataAccessException {

		return findMoodByContentContaining(content, -1, -1);
	}

	/**
	 * JPQL Query - findMoodByContentContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Mood> findMoodByContentContaining(String content, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMoodByContentContaining", startResult, maxRows, content);
		return new LinkedHashSet<Mood>(query.getResultList());
	}

	/**
	 * JPQL Query - findMoodByMoodId
	 *
	 */
	@Transactional
	public Mood findMoodByMoodId(Integer moodId) throws DataAccessException {

		return findMoodByMoodId(moodId, -1, -1);
	}

	/**
	 * JPQL Query - findMoodByMoodId
	 *
	 */

	@Transactional
	public Mood findMoodByMoodId(Integer moodId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findMoodByMoodId", moodId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findMoodByPrimaryKey
	 *
	 */
	@Transactional
	public Mood findMoodByPrimaryKey(Integer moodId) throws DataAccessException {

		return findMoodByPrimaryKey(moodId, -1, -1);
	}

	/**
	 * JPQL Query - findMoodByPrimaryKey
	 *
	 */

	@Transactional
	public Mood findMoodByPrimaryKey(Integer moodId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findMoodByPrimaryKey", moodId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findMoodByCreateTime
	 *
	 */
	@Transactional
	public Set<Mood> findMoodByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findMoodByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findMoodByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Mood> findMoodByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMoodByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<Mood>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllMoods
	 *
	 */
	@Transactional
	public Set<Mood> findAllMoods() throws DataAccessException {

		return findAllMoods(-1, -1);
	}

	/**
	 * JPQL Query - findAllMoods
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Mood> findAllMoods(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllMoods", startResult, maxRows);
		return new LinkedHashSet<Mood>(query.getResultList());
	}

	/**
	 * JPQL Query - findMoodByContent
	 *
	 */
	@Transactional
	public Set<Mood> findMoodByContent(String content) throws DataAccessException {

		return findMoodByContent(content, -1, -1);
	}

	/**
	 * JPQL Query - findMoodByContent
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Mood> findMoodByContent(String content, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMoodByContent", startResult, maxRows, content);
		return new LinkedHashSet<Mood>(query.getResultList());
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Mood entity) {
		return true;
	}
}
