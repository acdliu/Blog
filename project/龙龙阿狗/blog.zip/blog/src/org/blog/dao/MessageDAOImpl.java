package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Message;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Message entities.
 * 
 */
@Repository("MessageDAO")
@Transactional
public class MessageDAOImpl extends AbstractJpaDao<Message> implements
		MessageDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Message.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new MessageDAOImpl
	 *
	 */
	public MessageDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findMessageByIsSystemMessage
	 *
	 */
	@Transactional
	public Set<Message> findMessageByIsSystemMessage(Boolean isSystemMessage) throws DataAccessException {

		return findMessageByIsSystemMessage(isSystemMessage, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByIsSystemMessage
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Message> findMessageByIsSystemMessage(Boolean isSystemMessage, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMessageByIsSystemMessage", startResult, maxRows, isSystemMessage);
		return new LinkedHashSet<Message>(query.getResultList());
	}

	/**
	 * JPQL Query - findMessageByContent
	 *
	 */
	@Transactional
	public Set<Message> findMessageByContent(String content) throws DataAccessException {

		return findMessageByContent(content, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByContent
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Message> findMessageByContent(String content, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMessageByContent", startResult, maxRows, content);
		return new LinkedHashSet<Message>(query.getResultList());
	}

	/**
	 * JPQL Query - findMessageByMessageId
	 *
	 */
	@Transactional
	public Message findMessageByMessageId(Integer messageId) throws DataAccessException {

		return findMessageByMessageId(messageId, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByMessageId
	 *
	 */

	@Transactional
	public Message findMessageByMessageId(Integer messageId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findMessageByMessageId", messageId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findMessageByContentContaining
	 *
	 */
	@Transactional
	public Set<Message> findMessageByContentContaining(String content) throws DataAccessException {

		return findMessageByContentContaining(content, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByContentContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Message> findMessageByContentContaining(String content, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMessageByContentContaining", startResult, maxRows, content);
		return new LinkedHashSet<Message>(query.getResultList());
	}

	/**
	 * JPQL Query - findMessageByIsRead
	 *
	 */
	@Transactional
	public Set<Message> findMessageByIsRead(Boolean isRead) throws DataAccessException {

		return findMessageByIsRead(isRead, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByIsRead
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Message> findMessageByIsRead(Boolean isRead, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMessageByIsRead", startResult, maxRows, isRead);
		return new LinkedHashSet<Message>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllMessages
	 *
	 */
	@Transactional
	public Set<Message> findAllMessages() throws DataAccessException {

		return findAllMessages(-1, -1);
	}

	/**
	 * JPQL Query - findAllMessages
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Message> findAllMessages(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllMessages", startResult, maxRows);
		return new LinkedHashSet<Message>(query.getResultList());
	}

	/**
	 * JPQL Query - findMessageByCreateTime
	 *
	 */
	@Transactional
	public Set<Message> findMessageByCreateTime(java.util.Calendar createTime) throws DataAccessException {

		return findMessageByCreateTime(createTime, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByCreateTime
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Message> findMessageByCreateTime(java.util.Calendar createTime, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findMessageByCreateTime", startResult, maxRows, createTime);
		return new LinkedHashSet<Message>(query.getResultList());
	}

	/**
	 * JPQL Query - findMessageByPrimaryKey
	 *
	 */
	@Transactional
	public Message findMessageByPrimaryKey(Integer messageId) throws DataAccessException {

		return findMessageByPrimaryKey(messageId, -1, -1);
	}

	/**
	 * JPQL Query - findMessageByPrimaryKey
	 *
	 */

	@Transactional
	public Message findMessageByPrimaryKey(Integer messageId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findMessageByPrimaryKey", messageId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Message entity) {
		return true;
	}
}
