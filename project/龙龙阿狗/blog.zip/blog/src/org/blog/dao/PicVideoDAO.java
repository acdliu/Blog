package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.PicVideo;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage PicVideo entities.
 * 
 */
public interface PicVideoDAO extends JpaDao<PicVideo> {

	/**
	 * JPQL Query - findPicVideoByIsPicture
	 *
	 */
	public Set<PicVideo> findPicVideoByIsPicture(Boolean isPicture) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByIsPicture
	 *
	 */
	public Set<PicVideo> findPicVideoByIsPicture(Boolean isPicture, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByUploadTime
	 *
	 */
	public Set<PicVideo> findPicVideoByUploadTime(java.util.Calendar uploadTime) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByUploadTime
	 *
	 */
	public Set<PicVideo> findPicVideoByUploadTime(Calendar uploadTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByHits
	 *
	 */
	public Set<PicVideo> findPicVideoByHits(Integer hits) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByHits
	 *
	 */
	public Set<PicVideo> findPicVideoByHits(Integer hits, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPicVideoId
	 *
	 */
	public PicVideo findPicVideoByPicVideoId(Integer picVideoId) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPicVideoId
	 *
	 */
	public PicVideo findPicVideoByPicVideoId(Integer picVideoId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPictureUrl
	 *
	 */
	public Set<PicVideo> findPicVideoByPictureUrl(String pictureUrl) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPictureUrl
	 *
	 */
	public Set<PicVideo> findPicVideoByPictureUrl(String pictureUrl, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPrimaryKey
	 *
	 */
	public PicVideo findPicVideoByPrimaryKey(Integer picVideoId_1) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPrimaryKey
	 *
	 */
	public PicVideo findPicVideoByPrimaryKey(Integer picVideoId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllPicVideos
	 *
	 */
	public Set<PicVideo> findAllPicVideos() throws DataAccessException;

	/**
	 * JPQL Query - findAllPicVideos
	 *
	 */
	public Set<PicVideo> findAllPicVideos(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByBriefContaining
	 *
	 */
	public Set<PicVideo> findPicVideoByBriefContaining(String brief) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByBriefContaining
	 *
	 */
	public Set<PicVideo> findPicVideoByBriefContaining(String brief, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByBrief
	 *
	 */
	public Set<PicVideo> findPicVideoByBrief(String brief_1) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByBrief
	 *
	 */
	public Set<PicVideo> findPicVideoByBrief(String brief_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPictureUrlContaining
	 *
	 */
	public Set<PicVideo> findPicVideoByPictureUrlContaining(String pictureUrl_1) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoByPictureUrlContaining
	 *
	 */
	public Set<PicVideo> findPicVideoByPictureUrlContaining(String pictureUrl_1, int startResult, int maxRows) throws DataAccessException;

}