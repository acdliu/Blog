package org.blog.dao;

import java.util.Set;

import org.blog.domain.User;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage User entities.
 * 
 */
public interface UserDAO extends JpaDao<User> {

	/**
	 * JPQL Query - findAllUsers
	 *
	 */
	public Set<User> findAllUsers() throws DataAccessException;

	/**
	 * JPQL Query - findAllUsers
	 *
	 */
	public Set<User> findAllUsers(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPrimaryKey
	 *
	 */
	public User findUserByPrimaryKey(String userId) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPrimaryKey
	 *
	 */
	public User findUserByPrimaryKey(String userId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPasswordContaining
	 *
	 */
	public Set<User> findUserByPasswordContaining(String password) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPasswordContaining
	 *
	 */
	public Set<User> findUserByPasswordContaining(String password, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUserIdContaining
	 *
	 */
	public Set<User> findUserByUserIdContaining(String userId_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUserIdContaining
	 *
	 */
	public Set<User> findUserByUserIdContaining(String userId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUserId
	 *
	 */
	public User findUserByUserId(String userId_2) throws DataAccessException;

	/**
	 * JPQL Query - findUserByUserId
	 *
	 */
	public User findUserByUserId(String userId_2, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPassword
	 *
	 */
	public Set<User> findUserByPassword(String password_1) throws DataAccessException;

	/**
	 * JPQL Query - findUserByPassword
	 *
	 */
	public Set<User> findUserByPassword(String password_1, int startResult, int maxRows) throws DataAccessException;

}