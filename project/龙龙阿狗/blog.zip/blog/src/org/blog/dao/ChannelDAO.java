package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.Channel;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Channel entities.
 * 
 */
public interface ChannelDAO extends JpaDao<Channel> {

	/**
	 * JPQL Query - findChannelByPrimaryKey
	 *
	 */
	public Channel findChannelByPrimaryKey(Integer channelId) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByPrimaryKey
	 *
	 */
	public Channel findChannelByPrimaryKey(Integer channelId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByName
	 *
	 */
	public Set<Channel> findChannelByName(String name) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByName
	 *
	 */
	public Set<Channel> findChannelByName(String name, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByNameContaining
	 *
	 */
	public Set<Channel> findChannelByNameContaining(String name_1) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByNameContaining
	 *
	 */
	public Set<Channel> findChannelByNameContaining(String name_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllChannels
	 *
	 */
	public Set<Channel> findAllChannels() throws DataAccessException;

	/**
	 * JPQL Query - findAllChannels
	 *
	 */
	public Set<Channel> findAllChannels(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByChannelId
	 *
	 */
	public Channel findChannelByChannelId(Integer channelId_1) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByChannelId
	 *
	 */
	public Channel findChannelByChannelId(Integer channelId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByCreateTime
	 *
	 */
	public Set<Channel> findChannelByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findChannelByCreateTime
	 *
	 */
	public Set<Channel> findChannelByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

}