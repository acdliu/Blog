package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Category;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Category entities.
 * 
 */
@Repository("CategoryDAO")
@Transactional
public class CategoryDAOImpl extends AbstractJpaDao<Category> implements
		CategoryDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Category.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new CategoryDAOImpl
	 *
	 */
	public CategoryDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findCategoryByNameContaining
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByNameContaining(String name) throws DataAccessException {

		return findCategoryByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */
	@Transactional
	public Category findCategoryByPrimaryKey(Integer categoryId) throws DataAccessException {

		return findCategoryByPrimaryKey(categoryId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByPrimaryKey
	 *
	 */

	@Transactional
	public Category findCategoryByPrimaryKey(Integer categoryId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findCategoryByPrimaryKey", categoryId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findCategoryByName
	 *
	 */
	@Transactional
	public Set<Category> findCategoryByName(String name) throws DataAccessException {

		return findCategoryByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findCategoryByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findCategoryByName", startResult, maxRows, name);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */
	@Transactional
	public Set<Category> findAllCategorys() throws DataAccessException {

		return findAllCategorys(-1, -1);
	}

	/**
	 * JPQL Query - findAllCategorys
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Category> findAllCategorys(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllCategorys", startResult, maxRows);
		return new LinkedHashSet<Category>(query.getResultList());
	}

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */
	@Transactional
	public Category findCategoryByCategoryId(Integer categoryId) throws DataAccessException {

		return findCategoryByCategoryId(categoryId, -1, -1);
	}

	/**
	 * JPQL Query - findCategoryByCategoryId
	 *
	 */

	@Transactional
	public Category findCategoryByCategoryId(Integer categoryId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findCategoryByCategoryId", categoryId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Category entity) {
		return true;
	}
}
