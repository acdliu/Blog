package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.Article;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Article entities.
 * 
 */
public interface ArticleDAO extends JpaDao<Article> {

	/**
	 * JPQL Query - findArticleByTitle
	 *
	 */
	public Set<Article> findArticleByTitle(String title) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByTitle
	 *
	 */
	public Set<Article> findArticleByTitle(String title, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByArticleId
	 *
	 */
	public Article findArticleByArticleId(Integer articleId) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByArticleId
	 *
	 */
	public Article findArticleByArticleId(Integer articleId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllArticles
	 *
	 */
	public Set<Article> findAllArticles() throws DataAccessException;

	/**
	 * JPQL Query - findAllArticles
	 *
	 */
	public Set<Article> findAllArticles(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByHits
	 *
	 */
	public Set<Article> findArticleByHits(Integer hits) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByHits
	 *
	 */
	public Set<Article> findArticleByHits(Integer hits, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByIsPublic
	 *
	 */
	public Set<Article> findArticleByIsPublic(Boolean isPublic) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByIsPublic
	 *
	 */
	public Set<Article> findArticleByIsPublic(Boolean isPublic, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByTitleContaining
	 *
	 */
	public Set<Article> findArticleByTitleContaining(String title_1) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByTitleContaining
	 *
	 */
	public Set<Article> findArticleByTitleContaining(String title_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByContent
	 *
	 */
	public Set<Article> findArticleByContent(String content) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByContent
	 *
	 */
	public Set<Article> findArticleByContent(String content, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByCreateTime
	 *
	 */
	public Set<Article> findArticleByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByCreateTime
	 *
	 */
	public Set<Article> findArticleByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByPrimaryKey
	 *
	 */
	public Article findArticleByPrimaryKey(Integer articleId_1) throws DataAccessException;

	/**
	 * JPQL Query - findArticleByPrimaryKey
	 *
	 */
	public Article findArticleByPrimaryKey(Integer articleId_1, int startResult, int maxRows) throws DataAccessException;

}