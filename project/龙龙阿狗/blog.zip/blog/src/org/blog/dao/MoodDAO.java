package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.Mood;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage Mood entities.
 * 
 */
public interface MoodDAO extends JpaDao<Mood> {

	/**
	 * JPQL Query - findMoodByContentContaining
	 *
	 */
	public Set<Mood> findMoodByContentContaining(String content) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByContentContaining
	 *
	 */
	public Set<Mood> findMoodByContentContaining(String content, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByMoodId
	 *
	 */
	public Mood findMoodByMoodId(Integer moodId) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByMoodId
	 *
	 */
	public Mood findMoodByMoodId(Integer moodId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByPrimaryKey
	 *
	 */
	public Mood findMoodByPrimaryKey(Integer moodId_1) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByPrimaryKey
	 *
	 */
	public Mood findMoodByPrimaryKey(Integer moodId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByCreateTime
	 *
	 */
	public Set<Mood> findMoodByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByCreateTime
	 *
	 */
	public Set<Mood> findMoodByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllMoods
	 *
	 */
	public Set<Mood> findAllMoods() throws DataAccessException;

	/**
	 * JPQL Query - findAllMoods
	 *
	 */
	public Set<Mood> findAllMoods(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByContent
	 *
	 */
	public Set<Mood> findMoodByContent(String content_1) throws DataAccessException;

	/**
	 * JPQL Query - findMoodByContent
	 *
	 */
	public Set<Mood> findMoodByContent(String content_1, int startResult, int maxRows) throws DataAccessException;

}