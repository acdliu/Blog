package org.blog.dao;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.blog.domain.Rank;

import org.skyway.spring.util.dao.AbstractJpaDao;

import org.springframework.dao.DataAccessException;

import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

/**
 * DAO to manage Rank entities.
 * 
 */
@Repository("RankDAO")
@Transactional
public class RankDAOImpl extends AbstractJpaDao<Rank> implements RankDAO {

	/**
	 * Set of entity classes managed by this DAO.  Typically a DAO manages a single entity.
	 *
	 */
	private final static Set<Class<?>> dataTypes = new HashSet<Class<?>>(Arrays.asList(new Class<?>[] { Rank.class }));

	/**
	 * EntityManager injected by Spring for persistence unit 
	 *
	 */
	@PersistenceContext(unitName = "")
	private EntityManager entityManager;

	/**
	 * Instantiates a new RankDAOImpl
	 *
	 */
	public RankDAOImpl() {
		super();
	}

	/**
	 * Get the entity manager that manages persistence unit 
	 *
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * Returns the set of entity classes managed by this DAO.
	 *
	 */
	public Set<Class<?>> getTypes() {
		return dataTypes;
	}

	/**
	 * JPQL Query - findRankByPrimaryKey
	 *
	 */
	@Transactional
	public Rank findRankByPrimaryKey(Integer rankId) throws DataAccessException {

		return findRankByPrimaryKey(rankId, -1, -1);
	}

	/**
	 * JPQL Query - findRankByPrimaryKey
	 *
	 */

	@Transactional
	public Rank findRankByPrimaryKey(Integer rankId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findRankByPrimaryKey", rankId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * JPQL Query - findRankByNameContaining
	 *
	 */
	@Transactional
	public Set<Rank> findRankByNameContaining(String name) throws DataAccessException {

		return findRankByNameContaining(name, -1, -1);
	}

	/**
	 * JPQL Query - findRankByNameContaining
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Rank> findRankByNameContaining(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRankByNameContaining", startResult, maxRows, name);
		return new LinkedHashSet<Rank>(query.getResultList());
	}

	/**
	 * JPQL Query - findAllRanks
	 *
	 */
	@Transactional
	public Set<Rank> findAllRanks() throws DataAccessException {

		return findAllRanks(-1, -1);
	}

	/**
	 * JPQL Query - findAllRanks
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Rank> findAllRanks(int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findAllRanks", startResult, maxRows);
		return new LinkedHashSet<Rank>(query.getResultList());
	}

	/**
	 * JPQL Query - findRankByName
	 *
	 */
	@Transactional
	public Set<Rank> findRankByName(String name) throws DataAccessException {

		return findRankByName(name, -1, -1);
	}

	/**
	 * JPQL Query - findRankByName
	 *
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Rank> findRankByName(String name, int startResult, int maxRows) throws DataAccessException {
		Query query = createNamedQuery("findRankByName", startResult, maxRows, name);
		return new LinkedHashSet<Rank>(query.getResultList());
	}

	/**
	 * JPQL Query - findRankByRankId
	 *
	 */
	@Transactional
	public Rank findRankByRankId(Integer rankId) throws DataAccessException {

		return findRankByRankId(rankId, -1, -1);
	}

	/**
	 * JPQL Query - findRankByRankId
	 *
	 */

	@Transactional
	public Rank findRankByRankId(Integer rankId, int startResult, int maxRows) throws DataAccessException {
		try {
			return executeQueryByNameSingleResult("findRankByRankId", rankId);
		} catch (NoResultException nre) {
			return null;
		}
	}

	/**
	 * Used to determine whether or not to merge the entity or persist the entity when calling Store
	 * @see store
	 * 
	 *
	 */
	public boolean canBeMerged(Rank entity) {
		return true;
	}
}
