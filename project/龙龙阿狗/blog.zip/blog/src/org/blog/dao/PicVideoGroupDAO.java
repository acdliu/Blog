package org.blog.dao;

import java.util.Calendar;
import java.util.Set;

import org.blog.domain.PicVideoGroup;

import org.skyway.spring.util.dao.JpaDao;

import org.springframework.dao.DataAccessException;

/**
 * DAO to manage PicVideoGroup entities.
 * 
 */
public interface PicVideoGroupDAO extends JpaDao<PicVideoGroup> {

	/**
	 * JPQL Query - findPicVideoGroupByHits
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByHits(Integer hits) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByHits
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByHits(Integer hits, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByTitleContaining
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByTitleContaining(String title) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByTitleContaining
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByTitleContaining(String title, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByPrimaryKey
	 *
	 */
	public PicVideoGroup findPicVideoGroupByPrimaryKey(Integer picVideoGroupId) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByPrimaryKey
	 *
	 */
	public PicVideoGroup findPicVideoGroupByPrimaryKey(Integer picVideoGroupId, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByCreateTime
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByCreateTime(java.util.Calendar createTime) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByCreateTime
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByCreateTime(Calendar createTime, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByIsPicGroup
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByIsPicGroup(Boolean isPicGroup) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByIsPicGroup
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByIsPicGroup(Boolean isPicGroup, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findAllPicVideoGroups
	 *
	 */
	public Set<PicVideoGroup> findAllPicVideoGroups() throws DataAccessException;

	/**
	 * JPQL Query - findAllPicVideoGroups
	 *
	 */
	public Set<PicVideoGroup> findAllPicVideoGroups(int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByPicVideoGroupId
	 *
	 */
	public PicVideoGroup findPicVideoGroupByPicVideoGroupId(Integer picVideoGroupId_1) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByPicVideoGroupId
	 *
	 */
	public PicVideoGroup findPicVideoGroupByPicVideoGroupId(Integer picVideoGroupId_1, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByIsPublic
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByIsPublic(Boolean isPublic) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByIsPublic
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByIsPublic(Boolean isPublic, int startResult, int maxRows) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByTitle
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByTitle(String title_1) throws DataAccessException;

	/**
	 * JPQL Query - findPicVideoGroupByTitle
	 *
	 */
	public Set<PicVideoGroup> findPicVideoGroupByTitle(String title_1, int startResult, int maxRows) throws DataAccessException;

}