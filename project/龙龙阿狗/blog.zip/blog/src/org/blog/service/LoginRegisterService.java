package org.blog.service;

import java.util.Set;

import org.blog.domain.User;
import org.blog.domain.Article;

public interface LoginRegisterService {
	public Set<Article> getLeatestFiveArticles(User user);
	
}
