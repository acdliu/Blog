package org.blog.service;

public interface ResourceService {

}
