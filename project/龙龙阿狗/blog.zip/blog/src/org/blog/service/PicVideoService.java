package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.domain.PicVideo;
import org.blog.domain.PicVideoGroup;

/**
 * Spring service that handles CRUD requests for PicVideo entities
 * 
 */
public interface PicVideoService {

	/**
	 * Load an existing PicVideo entity
	 * 
	 */
	public Set<PicVideo> loadPicVideos();

	/**
	 * Save an existing PicVideoGroup entity
	 * 
	 */
	public PicVideo savePicVideoPicVideoGroup(Integer picVideoId, PicVideoGroup related_picvideogroup);

	/**
	 * Return all PicVideo entity
	 * 
	 */
	public List<PicVideo> findAllPicVideos(Integer startResult, Integer maxRows);

	/**
	 * Delete an existing PicVideo entity
	 * 
	 */
	public void deletePicVideo(PicVideo picvideo);

	/**
	 */
	public PicVideo findPicVideoByPrimaryKey(Integer picVideoId_1);

	/**
	 * Return a count of all PicVideo entity
	 * 
	 */
	public Integer countPicVideos();

	/**
	 * Save an existing PicVideo entity
	 * 
	 */
	public void savePicVideo(PicVideo picvideo_1);

	/**
	 * Delete an existing PicVideoGroup entity
	 * 
	 */
	public PicVideo deletePicVideoPicVideoGroup(Integer picvideo_picVideoId, Integer related_picvideogroup_picVideoGroupId);
}