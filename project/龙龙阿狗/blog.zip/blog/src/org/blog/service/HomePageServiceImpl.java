package org.blog.service;

public class HomePageServiceImpl implements HomePageService {

}
