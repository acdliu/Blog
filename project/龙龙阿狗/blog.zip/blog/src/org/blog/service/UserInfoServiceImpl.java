package org.blog.service;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Set;

import org.blog.dao.RankDAO;
import org.blog.dao.UserDAO;
import org.blog.dao.UserDetailDAO;
import org.blog.domain.Rank;
import org.blog.domain.User;
import org.blog.domain.UserDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for UserDetail entities
 * 
 */

@Service("UserDetailService")
@Transactional
public class UserInfoServiceImpl implements UserInfoService {

	/**
	 * DAO injected by Spring that manages Rank entities
	 * 
	 */
	@Autowired
	private RankDAO rankDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * DAO injected by Spring that manages UserDetail entities
	 * 
	 */
	@Autowired
	private UserDetailDAO userDetailDAO;

	/**
	 * Instantiates a new UserDetailServiceImpl.
	 *
	 */
	public UserInfoServiceImpl() {
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@Transactional
	public UserDetail deleteUserDetailUser(String userdetail_userId, String related_user_userId) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userdetail_userId, -1, -1);
		User related_user = userDAO.findUserByPrimaryKey(related_user_userId, -1, -1);

		userdetail.setUser(null);
		userdetail = userDetailDAO.store(userdetail);
		userDetailDAO.flush();

		related_user = userDAO.store(related_user);
		userDAO.flush();

		userDAO.remove(related_user);
		userDAO.flush();

		return userdetail;
	}

	/**
	 * Return a count of all UserDetail entity
	 * 
	 */
	@Transactional
	public Integer countUserDetails() {
		return ((Long) userDetailDAO.createQuerySingleResult("select count(o) from UserDetail o").getSingleResult()).intValue();
	}

	/**
	 * Return all UserDetail entity
	 * 
	 */
	@Transactional
	public List<UserDetail> findAllUserDetails(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<UserDetail>(userDetailDAO.findAllUserDetails(startResult, maxRows));
	}

	/**
	 * Delete an existing UserDetail entity
	 * 
	 */
	@Transactional
	public void deleteUserDetail(UserDetail userdetail) {
		userDetailDAO.remove(userdetail);
		userDetailDAO.flush();
	}

	/**
	 */
	@Transactional
	public UserDetail findUserDetailByPrimaryKey(String userId) {
		return userDetailDAO.findUserDetailByPrimaryKey(userId);
	}

	/**
	 * Delete an existing Rank entity
	 * 
	 */
	@Transactional
	public UserDetail deleteUserDetailRank(String userdetail_userId, Integer related_rank_rankId) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userdetail_userId, -1, -1);
		Rank related_rank = rankDAO.findRankByPrimaryKey(related_rank_rankId, -1, -1);

		userdetail.setRank(null);
		related_rank.getUserDetails().remove(userdetail);
		userdetail = userDetailDAO.store(userdetail);
		userDetailDAO.flush();

		related_rank = rankDAO.store(related_rank);
		rankDAO.flush();

		rankDAO.remove(related_rank);
		rankDAO.flush();

		return userdetail;
	}

	/**
	 * Save an existing UserDetail entity
	 * 
	 */
	@Transactional
	public void saveUserDetail(UserDetail userdetail) {
		UserDetail existingUserDetail = userDetailDAO.findUserDetailByPrimaryKey(userdetail.getUserId());
		if (existingUserDetail != null) {
			if (existingUserDetail != userdetail) {
				existingUserDetail.setUserId(userdetail.getUserId());
				existingUserDetail.setBirthday(userdetail.getBirthday());
				/*try {
					existingUserDetail.setName(new String((userdetail.getName()).getBytes("iso-8859-1"), "UTF-8"));
					existingUserDetail.setAddress(new String((userdetail.getAddress()).getBytes("iso-8859-1"), "UTF-8"));
					existingUserDetail.setGender(new String((userdetail.getGender()).getBytes("iso-8859-1"), "UTF-8"));
					existingUserDetail.setBrief(new String((userdetail.getBrief()).getBytes("iso-8859-1"), "UTF-8"));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}*/
				existingUserDetail.setName(userdetail.getName());
				existingUserDetail.setAddress(userdetail.getAddress());
				existingUserDetail.setGender(userdetail.getGender());
				existingUserDetail.setBrief(userdetail.getBrief());
				existingUserDetail.setQq(userdetail.getQq());
				existingUserDetail.setEmail(userdetail.getEmail());
				existingUserDetail.setMobilePhone(userdetail.getMobilePhone());
			}
			userdetail = userDetailDAO.store(existingUserDetail);
		} else {
			userdetail = userDetailDAO.store(userdetail);
		}
		userDetailDAO.flush();
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@Transactional
	public UserDetail saveUserDetailUser(String userId, User related_user) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userId, -1, -1);
		User existinguser = userDAO.findUserByPrimaryKey(related_user.getUserId());

		// copy into the existing record to preserve existing relationships
		if (existinguser != null) {
			existinguser.setUserId(related_user.getUserId());
			existinguser.setPassword(related_user.getPassword());
			related_user = existinguser;
		} else {
			related_user = userDAO.store(related_user);
			userDAO.flush();
		}

		userdetail.setUser(related_user);
		userdetail = userDetailDAO.store(userdetail);
		userDetailDAO.flush();

		related_user = userDAO.store(related_user);
		userDAO.flush();

		return userdetail;
	}

	/**
	 * Load an existing UserDetail entity
	 * 
	 */
	@Transactional
	public Set<UserDetail> loadUserDetails() {
		return userDetailDAO.findAllUserDetails();
	}

	/**
	 * Save an existing Rank entity
	 * 
	 */
	@Transactional
	public UserDetail saveUserDetailRank(String userId, Rank related_rank) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userId, -1, -1);
		Rank existingrank = rankDAO.findRankByPrimaryKey(related_rank.getRankId());

		// copy into the existing record to preserve existing relationships
		if (existingrank != null) {
			existingrank.setRankId(related_rank.getRankId());
			existingrank.setName(related_rank.getName());
			related_rank = existingrank;
		}

		userdetail.setRank(related_rank);
		related_rank.getUserDetails().add(userdetail);
		userdetail = userDetailDAO.store(userdetail);
		userDetailDAO.flush();

		related_rank = rankDAO.store(related_rank);
		rankDAO.flush();

		return userdetail;
	}
}
