package org.blog.service;

public class ResourceServiceImpl implements ResourceService {

}
