package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.dao.PicVideoDAO;
import org.blog.dao.PicVideoGroupDAO;

import org.blog.domain.PicVideo;
import org.blog.domain.PicVideoGroup;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for PicVideo entities
 * 
 */

@Service("PicVideoService")
@Transactional
public class PicVideoServiceImpl implements PicVideoService {

	/**
	 * DAO injected by Spring that manages PicVideo entities
	 * 
	 */
	@Autowired
	private PicVideoDAO picVideoDAO;

	/**
	 * DAO injected by Spring that manages PicVideoGroup entities
	 * 
	 */
	@Autowired
	private PicVideoGroupDAO picVideoGroupDAO;

	/**
	 * Instantiates a new PicVideoServiceImpl.
	 *
	 */
	public PicVideoServiceImpl() {
	}

	/**
	 * Load an existing PicVideo entity
	 * 
	 */
	@Transactional
	public Set<PicVideo> loadPicVideos() {
		return picVideoDAO.findAllPicVideos();
	}

	/**
	 * Save an existing PicVideoGroup entity
	 * 
	 */
	@Transactional
	public PicVideo savePicVideoPicVideoGroup(Integer picVideoId, PicVideoGroup related_picvideogroup) {
		PicVideo picvideo = picVideoDAO.findPicVideoByPrimaryKey(picVideoId, -1, -1);
		PicVideoGroup existingpicVideoGroup = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(related_picvideogroup.getPicVideoGroupId());

		// copy into the existing record to preserve existing relationships
		if (existingpicVideoGroup != null) {
			existingpicVideoGroup.setPicVideoGroupId(related_picvideogroup.getPicVideoGroupId());
			existingpicVideoGroup.setTitle(related_picvideogroup.getTitle());
			existingpicVideoGroup.setIsPublic(related_picvideogroup.getIsPublic());
			existingpicVideoGroup.setIsPicGroup(related_picvideogroup.getIsPicGroup());
			existingpicVideoGroup.setHits(related_picvideogroup.getHits());
			existingpicVideoGroup.setCreateTime(related_picvideogroup.getCreateTime());
			related_picvideogroup = existingpicVideoGroup;
		}

		picvideo.setPicVideoGroup(related_picvideogroup);
		related_picvideogroup.getPicVideos().add(picvideo);
		picvideo = picVideoDAO.store(picvideo);
		picVideoDAO.flush();

		related_picvideogroup = picVideoGroupDAO.store(related_picvideogroup);
		picVideoGroupDAO.flush();

		return picvideo;
	}

	/**
	 * Return all PicVideo entity
	 * 
	 */
	@Transactional
	public List<PicVideo> findAllPicVideos(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<PicVideo>(picVideoDAO.findAllPicVideos(startResult, maxRows));
	}

	/**
	 * Delete an existing PicVideo entity
	 * 
	 */
	@Transactional
	public void deletePicVideo(PicVideo picvideo) {
		picVideoDAO.remove(picvideo);
		picVideoDAO.flush();
	}

	/**
	 */
	@Transactional
	public PicVideo findPicVideoByPrimaryKey(Integer picVideoId) {
		return picVideoDAO.findPicVideoByPrimaryKey(picVideoId);
	}

	/**
	 * Return a count of all PicVideo entity
	 * 
	 */
	@Transactional
	public Integer countPicVideos() {
		return ((Long) picVideoDAO.createQuerySingleResult("select count(o) from PicVideo o").getSingleResult()).intValue();
	}

	/**
	 * Save an existing PicVideo entity
	 * 
	 */
	@Transactional
	public void savePicVideo(PicVideo picvideo) {
		PicVideo existingPicVideo = picVideoDAO.findPicVideoByPrimaryKey(picvideo.getPicVideoId());

		if (existingPicVideo != null) {
			if (existingPicVideo != picvideo) {
				existingPicVideo.setPicVideoId(picvideo.getPicVideoId());
				existingPicVideo.setPictureUrl(picvideo.getPictureUrl());
				existingPicVideo.setBrief(picvideo.getBrief());
				existingPicVideo.setHits(picvideo.getHits());
				existingPicVideo.setIsPicture(picvideo.getIsPicture());
				existingPicVideo.setUploadTime(picvideo.getUploadTime());
			}
			picvideo = picVideoDAO.store(existingPicVideo);
		} else {
			picvideo = picVideoDAO.store(picvideo);
		}
		picVideoDAO.flush();
	}

	/**
	 * Delete an existing PicVideoGroup entity
	 * 
	 */
	@Transactional
	public PicVideo deletePicVideoPicVideoGroup(Integer picvideo_picVideoId, Integer related_picvideogroup_picVideoGroupId) {
		PicVideo picvideo = picVideoDAO.findPicVideoByPrimaryKey(picvideo_picVideoId, -1, -1);
		PicVideoGroup related_picvideogroup = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(related_picvideogroup_picVideoGroupId, -1, -1);

		picvideo.setPicVideoGroup(null);
		related_picvideogroup.getPicVideos().remove(picvideo);
		picvideo = picVideoDAO.store(picvideo);
		picVideoDAO.flush();

		related_picvideogroup = picVideoGroupDAO.store(related_picvideogroup);
		picVideoGroupDAO.flush();

		picVideoGroupDAO.remove(related_picvideogroup);
		picVideoGroupDAO.flush();

		return picvideo;
	}
}
