package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.dao.ArticleDAO;
import org.blog.dao.CommentDAO;
import org.blog.dao.MessageDAO;
import org.blog.dao.MoodDAO;
import org.blog.dao.PicVideoGroupDAO;
import org.blog.dao.RelationDAO;
import org.blog.dao.UserDAO;
import org.blog.dao.UserDetailDAO;

import org.blog.domain.Article;
import org.blog.domain.Comment;
import org.blog.domain.Message;
import org.blog.domain.Mood;
import org.blog.domain.PicVideoGroup;
import org.blog.domain.Relation;
import org.blog.domain.User;
import org.blog.domain.UserDetail;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for User entities
 * 
 */

@Service("UserService")
@Transactional
public class AccountServiceImpl implements AccountService {

	/**
	 * DAO injected by Spring that manages Article entities
	 * 
	 */
	@Autowired
	private ArticleDAO articleDAO;

	/**
	 * DAO injected by Spring that manages Comment entities
	 * 
	 */
	@Autowired
	private CommentDAO commentDAO;

	/**
	 * DAO injected by Spring that manages Message entities
	 * 
	 */
	@Autowired
	private MessageDAO messageDAO;

	/**
	 * DAO injected by Spring that manages Mood entities
	 * 
	 */
	@Autowired
	private MoodDAO moodDAO;

	/**
	 * DAO injected by Spring that manages PicVideoGroup entities
	 * 
	 */
	@Autowired
	private PicVideoGroupDAO picVideoGroupDAO;

	/**
	 * DAO injected by Spring that manages Relation entities
	 * 
	 */
	@Autowired
	private RelationDAO relationDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * DAO injected by Spring that manages UserDetail entities
	 * 
	 */
	@Autowired
	private UserDetailDAO userDetailDAO;

	/**
	 * Instantiates a new UserServiceImpl.
	 *
	 */
	public AccountServiceImpl() {
	}

	/**
	 * Return a count of all User entity
	 * 
	 */
	@Transactional
	public Integer countUsers() {
		return ((Long) userDAO.createQuerySingleResult("select count(o) from User o").getSingleResult()).intValue();
	}

	/**
	 * Save an existing Article entity
	 * 
	 */
	@Transactional
	public User saveUserArticles(String userId, Article related_articles) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Article existingarticles = articleDAO.findArticleByPrimaryKey(related_articles.getArticleId());

		// copy into the existing record to preserve existing relationships
		if (existingarticles != null) {
			existingarticles.setArticleId(related_articles.getArticleId());
			existingarticles.setTitle(related_articles.getTitle());
			existingarticles.setContent(related_articles.getContent());
			existingarticles.setHits(related_articles.getHits());
			existingarticles.setIsPublic(related_articles.getIsPublic());
			existingarticles.setCreateTime(related_articles.getCreateTime());
			related_articles = existingarticles;
		} else {
			related_articles = articleDAO.store(related_articles);
			articleDAO.flush();
		}

		related_articles.setUser(user);
		user.getArticles().add(related_articles);
		related_articles = articleDAO.store(related_articles);
		articleDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Article entity
	 * 
	 */
	@Transactional
	public User deleteUserArticles(String user_userId, Integer related_articles_articleId) {
		Article related_articles = articleDAO.findArticleByPrimaryKey(related_articles_articleId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_articles.setUser(null);
		user.getArticles().remove(related_articles);

		articleDAO.remove(related_articles);
		articleDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	@Transactional
	public User deleteUserRelationsForFanId(String user_userId, Integer related_relationsforfanid_relationId) {
		Relation related_relationsforfanid = relationDAO.findRelationByPrimaryKey(related_relationsforfanid_relationId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_relationsforfanid.setUserByIdolId(null);
		user.getRelationsForIdolId().remove(related_relationsforfanid);

		relationDAO.remove(related_relationsforfanid);
		relationDAO.flush();

		return user;
	}

	/**
	 * Load an existing User entity
	 * 
	 */
	@Transactional
	public Set<User> loadUsers() {
		return userDAO.findAllUsers();
	}

	/**
	 * Save an existing Mood entity
	 * 
	 */
	@Transactional
	public User saveUserMoods(String userId, Mood related_moods) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Mood existingmoods = moodDAO.findMoodByPrimaryKey(related_moods.getMoodId());

		// copy into the existing record to preserve existing relationships
		if (existingmoods != null) {
			existingmoods.setMoodId(related_moods.getMoodId());
			existingmoods.setContent(related_moods.getContent());
			existingmoods.setCreateTime(related_moods.getCreateTime());
			related_moods = existingmoods;
		}

		related_moods.setUser(user);
		user.getMoods().add(related_moods);
		related_moods = moodDAO.store(related_moods);
		moodDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Delete an existing PicVideoGroup entity
	 * 
	 */
	@Transactional
	public User deleteUserPicVideoGroups(String user_userId, Integer related_picvideogroups_picVideoGroupId) {
		PicVideoGroup related_picvideogroups = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(related_picvideogroups_picVideoGroupId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_picvideogroups.setUser(null);
		user.getPicVideoGroups().remove(related_picvideogroups);

		picVideoGroupDAO.remove(related_picvideogroups);
		picVideoGroupDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Message entity
	 * 
	 */
	@Transactional
	public User deleteUserMessagesForSenderId(String user_userId, Integer related_messagesforsenderid_messageId) {
		Message related_messagesforsenderid = messageDAO.findMessageByPrimaryKey(related_messagesforsenderid_messageId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_messagesforsenderid.setUserBySenderId(null);
		user.getMessagesForSenderId().remove(related_messagesforsenderid);

		messageDAO.remove(related_messagesforsenderid);
		messageDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Mood entity
	 * 
	 */
	@Transactional
	public User deleteUserMoods(String user_userId, Integer related_moods_moodId) {
		Mood related_moods = moodDAO.findMoodByPrimaryKey(related_moods_moodId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_moods.setUser(null);
		user.getMoods().remove(related_moods);

		moodDAO.remove(related_moods);
		moodDAO.flush();

		return user;
	}

	/**
	 * Save an existing Comment entity
	 * 
	 */
	@Transactional
	public User saveUserComments(String userId, Comment related_comments) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Comment existingcomments = commentDAO.findCommentByPrimaryKey(related_comments.getCommentId());

		// copy into the existing record to preserve existing relationships
		if (existingcomments != null) {
			existingcomments.setCommentId(related_comments.getCommentId());
			existingcomments.setArticleId(related_comments.getArticleId());
			existingcomments.setContent(related_comments.getContent());
			existingcomments.setIsMoodComment(related_comments.getIsMoodComment());
			existingcomments.setIsPublic(related_comments.getIsPublic());
			existingcomments.setCommentTime(related_comments.getCommentTime());
			related_comments = existingcomments;
		}

		related_comments.setUser(user);
		user.getComments().add(related_comments);
		related_comments = commentDAO.store(related_comments);
		commentDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Message entity
	 * 
	 */
	@Transactional
	public User deleteUserMessagesForReceiverId(String user_userId, Integer related_messagesforreceiverid_messageId) {
		Message related_messagesforreceiverid = messageDAO.findMessageByPrimaryKey(related_messagesforreceiverid_messageId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_messagesforreceiverid.setUserBySenderId(null);
		user.getMessagesForSenderId().remove(related_messagesforreceiverid);

		messageDAO.remove(related_messagesforreceiverid);
		messageDAO.flush();

		return user;
	}

	/**
	 * Save an existing Relation entity
	 * 
	 */
	@Transactional
	public User saveUserRelationsForIdolId(String userId, Relation related_relationsforidolid) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Relation existingrelationsForIdolId = relationDAO.findRelationByPrimaryKey(related_relationsforidolid.getRelationId());

		// copy into the existing record to preserve existing relationships
		if (existingrelationsForIdolId != null) {
			existingrelationsForIdolId.setRelationId(related_relationsforidolid.getRelationId());
			existingrelationsForIdolId.setIsBlacker(related_relationsforidolid.getIsBlacker());
			existingrelationsForIdolId.setCreateTime(related_relationsforidolid.getCreateTime());
			related_relationsforidolid = existingrelationsForIdolId;
		}

		related_relationsforidolid.setUserByIdolId(user);
		user.getRelationsForIdolId().add(related_relationsforidolid);
		related_relationsforidolid = relationDAO.store(related_relationsforidolid);
		relationDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Save an existing Relation entity
	 * 
	 */
	@Transactional
	public User saveUserRelationsForFanId(String userId, Relation related_relationsforfanid) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Relation existingrelationsForFanId = relationDAO.findRelationByPrimaryKey(related_relationsforfanid.getRelationId());

		// copy into the existing record to preserve existing relationships
		if (existingrelationsForFanId != null) {
			existingrelationsForFanId.setRelationId(related_relationsforfanid.getRelationId());
			existingrelationsForFanId.setIsBlacker(related_relationsforfanid.getIsBlacker());
			existingrelationsForFanId.setCreateTime(related_relationsforfanid.getCreateTime());
			related_relationsforfanid = existingrelationsForFanId;
		}

		related_relationsforfanid.setUserByIdolId(user);
		user.getRelationsForIdolId().add(related_relationsforfanid);
		related_relationsforfanid = relationDAO.store(related_relationsforfanid);
		relationDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 */
	@Transactional
	public User findUserByPrimaryKey(String userId) {
		return userDAO.findUserByPrimaryKey(userId);
	}

	/**
	 * Save an existing Message entity
	 * 
	 */
	@Transactional
	public User saveUserMessagesForReceiverId(String userId, Message related_messagesforreceiverid) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Message existingmessagesForReceiverId = messageDAO.findMessageByPrimaryKey(related_messagesforreceiverid.getMessageId());

		// copy into the existing record to preserve existing relationships
		if (existingmessagesForReceiverId != null) {
			existingmessagesForReceiverId.setMessageId(related_messagesforreceiverid.getMessageId());
			existingmessagesForReceiverId.setContent(related_messagesforreceiverid.getContent());
			existingmessagesForReceiverId.setIsRead(related_messagesforreceiverid.getIsRead());
			existingmessagesForReceiverId.setIsSystemMessage(related_messagesforreceiverid.getIsSystemMessage());
			existingmessagesForReceiverId.setCreateTime(related_messagesforreceiverid.getCreateTime());
			related_messagesforreceiverid = existingmessagesForReceiverId;
		}

		related_messagesforreceiverid.setUserBySenderId(user);
		user.getMessagesForSenderId().add(related_messagesforreceiverid);
		related_messagesforreceiverid = messageDAO.store(related_messagesforreceiverid);
		messageDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@Transactional
	public void deleteUser(User user) {
		userDAO.remove(user);
		userDAO.flush();
	}

	/**
	 * Return all User entity
	 * 
	 */
	@Transactional
	public List<User> findAllUsers(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<User>(userDAO.findAllUsers(startResult, maxRows));
	}

	/**
	 * Save an existing PicVideoGroup entity
	 * 
	 */
	@Transactional
	public User saveUserPicVideoGroups(String userId, PicVideoGroup related_picvideogroups) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		PicVideoGroup existingpicVideoGroups = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(related_picvideogroups.getPicVideoGroupId());

		// copy into the existing record to preserve existing relationships
		if (existingpicVideoGroups != null) {
			existingpicVideoGroups.setPicVideoGroupId(related_picvideogroups.getPicVideoGroupId());
			existingpicVideoGroups.setTitle(related_picvideogroups.getTitle());
			existingpicVideoGroups.setIsPublic(related_picvideogroups.getIsPublic());
			existingpicVideoGroups.setIsPicGroup(related_picvideogroups.getIsPicGroup());
			existingpicVideoGroups.setHits(related_picvideogroups.getHits());
			existingpicVideoGroups.setCreateTime(related_picvideogroups.getCreateTime());
			related_picvideogroups = existingpicVideoGroups;
		}

		related_picvideogroups.setUser(user);
		user.getPicVideoGroups().add(related_picvideogroups);
		related_picvideogroups = picVideoGroupDAO.store(related_picvideogroups);
		picVideoGroupDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Save an existing UserDetail entity
	 * 
	 */
	@Transactional
	public User saveUserUserDetail(String userId, UserDetail related_userdetail) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		UserDetail existinguserDetail = userDetailDAO.findUserDetailByPrimaryKey(related_userdetail.getUserId());

		// copy into the existing record to preserve existing relationships
		if (existinguserDetail != null) {
			existinguserDetail.setUserId(related_userdetail.getUserId());
			existinguserDetail.setName(related_userdetail.getName());
			existinguserDetail.setBirthday(related_userdetail.getBirthday());
			existinguserDetail.setGender(related_userdetail.getGender());
			existinguserDetail.setQq(related_userdetail.getQq());
			existinguserDetail.setEmail(related_userdetail.getEmail());
			existinguserDetail.setMobilePhone(related_userdetail.getMobilePhone());
			existinguserDetail.setAddress(related_userdetail.getAddress());
			existinguserDetail.setBrief(related_userdetail.getBrief());
			existinguserDetail.setJoinTime(related_userdetail.getJoinTime());
			existinguserDetail.setLastestLoginIp(related_userdetail.getLastestLoginIp());
			existinguserDetail.setLoginTimes(related_userdetail.getLoginTimes());
			existinguserDetail.setFaceUrl(related_userdetail.getFaceUrl());
			existinguserDetail.setScore(related_userdetail.getScore());
			existinguserDetail.setHits(related_userdetail.getHits());
			related_userdetail = existinguserDetail;
		} else {
			related_userdetail = userDetailDAO.store(related_userdetail);
			userDetailDAO.flush();
		}

		user.setUserDetail(related_userdetail);
		user = userDAO.store(user);
		userDAO.flush();

		related_userdetail = userDetailDAO.store(related_userdetail);
		userDetailDAO.flush();

		return user;
	}

	/**
	 * Delete an existing Comment entity
	 * 
	 */
	@Transactional
	public User deleteUserComments(String user_userId, Integer related_comments_commentId) {
		Comment related_comments = commentDAO.findCommentByPrimaryKey(related_comments_commentId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_comments.setUser(null);
		user.getComments().remove(related_comments);

		commentDAO.remove(related_comments);
		commentDAO.flush();

		return user;
	}

	/**
	 * Save an existing Message entity
	 * 
	 */
	@Transactional
	public User saveUserMessagesForSenderId(String userId, Message related_messagesforsenderid) {
		User user = userDAO.findUserByPrimaryKey(userId, -1, -1);
		Message existingmessagesForSenderId = messageDAO.findMessageByPrimaryKey(related_messagesforsenderid.getMessageId());

		// copy into the existing record to preserve existing relationships
		if (existingmessagesForSenderId != null) {
			existingmessagesForSenderId.setMessageId(related_messagesforsenderid.getMessageId());
			existingmessagesForSenderId.setContent(related_messagesforsenderid.getContent());
			existingmessagesForSenderId.setIsRead(related_messagesforsenderid.getIsRead());
			existingmessagesForSenderId.setIsSystemMessage(related_messagesforsenderid.getIsSystemMessage());
			existingmessagesForSenderId.setCreateTime(related_messagesforsenderid.getCreateTime());
			related_messagesforsenderid = existingmessagesForSenderId;
		}

		related_messagesforsenderid.setUserBySenderId(user);
		user.getMessagesForSenderId().add(related_messagesforsenderid);
		related_messagesforsenderid = messageDAO.store(related_messagesforsenderid);
		messageDAO.flush();

		user = userDAO.store(user);
		userDAO.flush();

		return user;
	}

	/**
	 * Delete an existing UserDetail entity
	 * 
	 */
	@Transactional
	public User deleteUserUserDetail(String user_userId, String related_userdetail_userId) {
		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);
		UserDetail related_userdetail = userDetailDAO.findUserDetailByPrimaryKey(related_userdetail_userId, -1, -1);

		user.setUserDetail(null);
		user = userDAO.store(user);
		userDAO.flush();

		related_userdetail = userDetailDAO.store(related_userdetail);
		userDetailDAO.flush();

		userDetailDAO.remove(related_userdetail);
		userDetailDAO.flush();

		return user;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@Transactional
	public void saveUser(User user) {
		User existingUser = userDAO.findUserByPrimaryKey(user.getUserId());

		if (existingUser != null) {
			if (existingUser != user) {
				existingUser.setUserId(user.getUserId());
				existingUser.setPassword(user.getPassword());
			}
			user = userDAO.store(existingUser);
		} else {
			user = userDAO.store(user);
		}
		userDAO.flush();
	}

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	@Transactional
	public User deleteUserRelationsForIdolId(String user_userId, Integer related_relationsforidolid_relationId) {
		Relation related_relationsforidolid = relationDAO.findRelationByPrimaryKey(related_relationsforidolid_relationId, -1, -1);

		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		related_relationsforidolid.setUserByIdolId(null);
		user.getRelationsForIdolId().remove(related_relationsforidolid);

		relationDAO.remove(related_relationsforidolid);
		relationDAO.flush();

		return user;
	}
}
