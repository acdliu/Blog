package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.dao.ArticleDAO;
import org.blog.dao.CategoryDAO;
import org.blog.dao.UserDAO;

import org.blog.domain.Article;
import org.blog.domain.Category;
import org.blog.domain.User;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Article entities
 * 
 */

@Service("ArticleService")
@Transactional
public class ArticleServiceImpl implements ArticleService {

	/**
	 * DAO injected by Spring that manages Article entities
	 * 
	 */
	@Autowired
	private ArticleDAO articleDAO;

	/**
	 * DAO injected by Spring that manages Category entities
	 * 
	 */
	@Autowired
	private CategoryDAO categoryDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * Instantiates a new ArticleServiceImpl.
	 *
	 */
	public ArticleServiceImpl() {
	}

	/**
	 * Return a count of all Article entity
	 * 
	 */
	@Transactional
	public Integer countArticles() {
		return ((Long) articleDAO.createQuerySingleResult("select count(o) from Article o").getSingleResult()).intValue();
	}

	/**
	 * Return all Article entity
	 * 
	 */
	@Transactional
	public List<Article> findAllArticles(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Article>(articleDAO.findAllArticles(startResult, maxRows));
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@Transactional
	public Article deleteArticleUser(Integer article_articleId, String related_user_userId) {
		Article article = articleDAO.findArticleByPrimaryKey(article_articleId, -1, -1);
		User related_user = userDAO.findUserByPrimaryKey(related_user_userId, -1, -1);

		article.setUser(null);
		related_user.getArticles().remove(article);
		article = articleDAO.store(article);
		articleDAO.flush();

		related_user = userDAO.store(related_user);
		userDAO.flush();

		userDAO.remove(related_user);
		userDAO.flush();

		return article;
	}

	/**
	 * Delete an existing Category entity
	 * 
	 */
	@Transactional
	public Article deleteArticleCategory(Integer article_articleId, Integer related_category_categoryId) {
		Article article = articleDAO.findArticleByPrimaryKey(article_articleId, -1, -1);
		Category related_category = categoryDAO.findCategoryByPrimaryKey(related_category_categoryId, -1, -1);

		article.setCategory(null);
		related_category.getArticles().remove(article);
		article = articleDAO.store(article);
		articleDAO.flush();

		related_category = categoryDAO.store(related_category);
		categoryDAO.flush();

		categoryDAO.remove(related_category);
		categoryDAO.flush();

		return article;
	}

	/**
	 * Save an existing Article entity
	 * 
	 */
	@Transactional
	public void saveArticle(Article article) {
		Article existingArticle = articleDAO.findArticleByPrimaryKey(article.getArticleId());

		if (existingArticle != null) {
			if (existingArticle != article) {
				existingArticle.setArticleId(article.getArticleId());
				existingArticle.setTitle(article.getTitle());
				existingArticle.setContent(article.getContent());
				existingArticle.setHits(article.getHits());
				existingArticle.setIsPublic(article.getIsPublic());
				existingArticle.setCreateTime(article.getCreateTime());
			}
			article = articleDAO.store(existingArticle);
		} else {
			article = articleDAO.store(article);
		}
		articleDAO.flush();
	}

	/**
	 * Delete an existing Article entity
	 * 
	 */
	@Transactional
	public void deleteArticle(Article article) {
		articleDAO.remove(article);
		articleDAO.flush();
	}

	/**
	 */
	@Transactional
	public Article findArticleByPrimaryKey(Integer articleId) {
		return articleDAO.findArticleByPrimaryKey(articleId);
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@Transactional
	public Article saveArticleUser(Integer articleId, User related_user) {
		Article article = articleDAO.findArticleByPrimaryKey(articleId, -1, -1);
		User existinguser = userDAO.findUserByPrimaryKey(related_user.getUserId());

		// copy into the existing record to preserve existing relationships
		if (existinguser != null) {
			existinguser.setUserId(related_user.getUserId());
			existinguser.setPassword(related_user.getPassword());
			related_user = existinguser;
		} else {
			related_user = userDAO.store(related_user);
			userDAO.flush();
		}

		article.setUser(related_user);
		related_user.getArticles().add(article);
		article = articleDAO.store(article);
		articleDAO.flush();

		related_user = userDAO.store(related_user);
		userDAO.flush();

		return article;
	}

	/**
	 * Save an existing Category entity
	 * 
	 */
	@Transactional
	public Article saveArticleCategory(Integer articleId, Category related_category) {
		Article article = articleDAO.findArticleByPrimaryKey(articleId, -1, -1);
		Category existingcategory = categoryDAO.findCategoryByPrimaryKey(related_category.getCategoryId());

		// copy into the existing record to preserve existing relationships
		if (existingcategory != null) {
			existingcategory.setCategoryId(related_category.getCategoryId());
			existingcategory.setName(related_category.getName());
			related_category = existingcategory;
		}

		article.setCategory(related_category);
		related_category.getArticles().add(article);
		article = articleDAO.store(article);
		articleDAO.flush();

		related_category = categoryDAO.store(related_category);
		categoryDAO.flush();

		return article;
	}

	/**
	 * Load an existing Article entity
	 * 
	 */
	@Transactional
	public Set<Article> loadArticles() {
		return articleDAO.findAllArticles();
	}
}
