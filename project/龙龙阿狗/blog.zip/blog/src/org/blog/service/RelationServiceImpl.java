package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.dao.RelationDAO;
import org.blog.dao.UserDAO;

import org.blog.domain.Relation;
import org.blog.domain.User;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * Spring service that handles CRUD requests for Relation entities
 * 
 */

@Service("RelationService")
@Transactional
public class RelationServiceImpl implements RelationService {

	/**
	 * DAO injected by Spring that manages Relation entities
	 * 
	 */
	@Autowired
	private RelationDAO relationDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * Instantiates a new RelationServiceImpl.
	 *
	 */
	public RelationServiceImpl() {
	}

	/**
	 * Save an existing Relation entity
	 * 
	 */
	@Transactional
	public void saveRelation(Relation relation) {
		Relation existingRelation = relationDAO.findRelationByPrimaryKey(relation.getRelationId());

		if (existingRelation != null) {
			if (existingRelation != relation) {
				existingRelation.setRelationId(relation.getRelationId());
				existingRelation.setIsBlacker(relation.getIsBlacker());
				existingRelation.setCreateTime(relation.getCreateTime());
			}
			relation = relationDAO.store(existingRelation);
		} else {
			relation = relationDAO.store(relation);
		}
		relationDAO.flush();
	}

	/**
	 * Return all Relation entity
	 * 
	 */
	@Transactional
	public List<Relation> findAllRelations(Integer startResult, Integer maxRows) {
		return new java.util.ArrayList<Relation>(relationDAO.findAllRelations(startResult, maxRows));
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@Transactional
	public Relation deleteRelationUserByIdolId(Integer relation_relationId, String related_userbyidolid_userId) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relation_relationId, -1, -1);
		User related_userbyidolid = userDAO.findUserByPrimaryKey(related_userbyidolid_userId, -1, -1);

		relation.setUserByIdolId(null);
		related_userbyidolid.getRelationsForIdolId().remove(relation);
		relation = relationDAO.store(relation);
		relationDAO.flush();

		related_userbyidolid = userDAO.store(related_userbyidolid);
		userDAO.flush();

		userDAO.remove(related_userbyidolid);
		userDAO.flush();

		return relation;
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@Transactional
	public Relation deleteRelationUserByFanId(Integer relation_relationId, String related_userbyfanid_userId) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relation_relationId, -1, -1);
		User related_userbyfanid = userDAO.findUserByPrimaryKey(related_userbyfanid_userId, -1, -1);

		relation.setUserByFanId(null);
		related_userbyfanid.getRelationsForFanId().remove(relation);
		relation = relationDAO.store(relation);
		relationDAO.flush();

		related_userbyfanid = userDAO.store(related_userbyfanid);
		userDAO.flush();

		userDAO.remove(related_userbyfanid);
		userDAO.flush();

		return relation;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@Transactional
	public Relation saveRelationUserByFanId(Integer relationId, User related_userbyfanid) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationId, -1, -1);
		User existinguserByFanId = userDAO.findUserByPrimaryKey(related_userbyfanid.getUserId());

		// copy into the existing record to preserve existing relationships
		if (existinguserByFanId != null) {
			existinguserByFanId.setUserId(related_userbyfanid.getUserId());
			existinguserByFanId.setPassword(related_userbyfanid.getPassword());
			related_userbyfanid = existinguserByFanId;
		}

		relation.setUserByFanId(related_userbyfanid);
		related_userbyfanid.getRelationsForFanId().add(relation);
		relation = relationDAO.store(relation);
		relationDAO.flush();

		related_userbyfanid = userDAO.store(related_userbyfanid);
		userDAO.flush();

		return relation;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@Transactional
	public Relation saveRelationUserByIdolId(Integer relationId, User related_userbyidolid) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationId, -1, -1);
		User existinguserByIdolId = userDAO.findUserByPrimaryKey(related_userbyidolid.getUserId());

		// copy into the existing record to preserve existing relationships
		if (existinguserByIdolId != null) {
			existinguserByIdolId.setUserId(related_userbyidolid.getUserId());
			existinguserByIdolId.setPassword(related_userbyidolid.getPassword());
			related_userbyidolid = existinguserByIdolId;
		}

		relation.setUserByIdolId(related_userbyidolid);
		related_userbyidolid.getRelationsForIdolId().add(relation);
		relation = relationDAO.store(relation);
		relationDAO.flush();

		related_userbyidolid = userDAO.store(related_userbyidolid);
		userDAO.flush();

		return relation;
	}

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	@Transactional
	public void deleteRelation(Relation relation) {
		relationDAO.remove(relation);
		relationDAO.flush();
	}

	/**
	 */
	@Transactional
	public Relation findRelationByPrimaryKey(Integer relationId) {
		return relationDAO.findRelationByPrimaryKey(relationId);
	}

	/**
	 * Load an existing Relation entity
	 * 
	 */
	@Transactional
	public Set<Relation> loadRelations() {
		return relationDAO.findAllRelations();
	}

	/**
	 * Return a count of all Relation entity
	 * 
	 */
	@Transactional
	public Integer countRelations() {
		return ((Long) relationDAO.createQuerySingleResult("select count(o) from Relation o").getSingleResult()).intValue();
	}
}
