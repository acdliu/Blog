package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.domain.Article;
import org.blog.domain.Comment;
import org.blog.domain.Message;
import org.blog.domain.Mood;
import org.blog.domain.PicVideoGroup;
import org.blog.domain.Relation;
import org.blog.domain.User;
import org.blog.domain.UserDetail;

/**
 * Spring service that handles CRUD requests for User entities
 * 
 */
public interface AccountService {

	/**
	 * Return a count of all User entity
	 * 
	 */
	public Integer countUsers();

	/**
	 * Save an existing Article entity
	 * 
	 */
	public User saveUserArticles(String userId, Article related_articles);

	/**
	 * Delete an existing Article entity
	 * 
	 */
	public User deleteUserArticles(String user_userId, Integer related_articles_articleId);

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	public User deleteUserRelationsForFanId(String user_userId_1, Integer related_relationsforfanid_relationId);

	/**
	 * Load an existing User entity
	 * 
	 */
	public Set<User> loadUsers();

	/**
	 * Save an existing Mood entity
	 * 
	 */
	public User saveUserMoods(String userId_1, Mood related_moods);

	/**
	 * Delete an existing PicVideoGroup entity
	 * 
	 */
	public User deleteUserPicVideoGroups(String user_userId_2, Integer related_picvideogroups_picVideoGroupId);

	/**
	 * Delete an existing Message entity
	 * 
	 */
	public User deleteUserMessagesForSenderId(String user_userId_3, Integer related_messagesforsenderid_messageId);

	/**
	 * Delete an existing Mood entity
	 * 
	 */
	public User deleteUserMoods(String user_userId_4, Integer related_moods_moodId);

	/**
	 * Save an existing Comment entity
	 * 
	 */
	public User saveUserComments(String userId_2, Comment related_comments);

	/**
	 * Delete an existing Message entity
	 * 
	 */
	public User deleteUserMessagesForReceiverId(String user_userId_5, Integer related_messagesforreceiverid_messageId);

	/**
	 * Save an existing Relation entity
	 * 
	 */
	public User saveUserRelationsForIdolId(String userId_3, Relation related_relationsforidolid);

	/**
	 * Save an existing Relation entity
	 * 
	 */
	public User saveUserRelationsForFanId(String userId_4, Relation related_relationsforfanid);

	/**
	 */
	public User findUserByPrimaryKey(String userId_5);

	/**
	 * Save an existing Message entity
	 * 
	 */
	public User saveUserMessagesForReceiverId(String userId_6, Message related_messagesforreceiverid);

	/**
	 * Delete an existing User entity
	 * 
	 */
	public void deleteUser(User user);

	/**
	 * Return all User entity
	 * 
	 */
	public List<User> findAllUsers(Integer startResult, Integer maxRows);

	/**
	 * Save an existing PicVideoGroup entity
	 * 
	 */
	public User saveUserPicVideoGroups(String userId_7, PicVideoGroup related_picvideogroups);

	/**
	 * Save an existing UserDetail entity
	 * 
	 */
	public User saveUserUserDetail(String userId_8, UserDetail related_userdetail);

	/**
	 * Delete an existing Comment entity
	 * 
	 */
	public User deleteUserComments(String user_userId_6, Integer related_comments_commentId);

	/**
	 * Save an existing Message entity
	 * 
	 */
	public User saveUserMessagesForSenderId(String userId_9, Message related_messagesforsenderid);

	/**
	 * Delete an existing UserDetail entity
	 * 
	 */
	public User deleteUserUserDetail(String user_userId_7, String related_userdetail_userId);

	/**
	 * Save an existing User entity
	 * 
	 */
	public void saveUser(User user_1);

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	public User deleteUserRelationsForIdolId(String user_userId_8, Integer related_relationsforidolid_relationId);
}