package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.domain.Rank;
import org.blog.domain.User;
import org.blog.domain.UserDetail;

/**
 * Spring service that handles CRUD requests for UserDetail entities
 * 
 */
public interface UserInfoService {

	/**
	 * Delete an existing User entity
	 * 
	 */
	public UserDetail deleteUserDetailUser(String userdetail_userId, String related_user_userId);

	/**
	 * Return a count of all UserDetail entity
	 * 
	 */
	public Integer countUserDetails();

	/**
	 * Return all UserDetail entity
	 * 
	 */
	public List<UserDetail> findAllUserDetails(Integer startResult, Integer maxRows);

	/**
	 * Delete an existing UserDetail entity
	 * 
	 */
	public void deleteUserDetail(UserDetail userdetail);

	/**
	 */
	public UserDetail findUserDetailByPrimaryKey(String userId);

	/**
	 * Delete an existing Rank entity
	 * 
	 */
	public UserDetail deleteUserDetailRank(String userdetail_userId_1, Integer related_rank_rankId);

	/**
	 * Save an existing UserDetail entity
	 * 
	 */
	public void saveUserDetail(UserDetail userdetail_1);

	/**
	 * Save an existing User entity
	 * 
	 */
	public UserDetail saveUserDetailUser(String userId_1, User related_user);

	/**
	 * Load an existing UserDetail entity
	 * 
	 */
	public Set<UserDetail> loadUserDetails();

	/**
	 * Save an existing Rank entity
	 * 
	 */
	public UserDetail saveUserDetailRank(String userId_2, Rank related_rank);
}