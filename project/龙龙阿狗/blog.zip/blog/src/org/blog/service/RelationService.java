package org.blog.service;

import java.util.List;
import java.util.Set;

import org.blog.domain.Relation;
import org.blog.domain.User;

/**
 * Spring service that handles CRUD requests for Relation entities
 * 
 */
public interface RelationService {

	/**
	 * Save an existing Relation entity
	 * 
	 */
	public void saveRelation(Relation relation);

	/**
	 * Return all Relation entity
	 * 
	 */
	public List<Relation> findAllRelations(Integer startResult, Integer maxRows);

	/**
	 * Delete an existing User entity
	 * 
	 */
	public Relation deleteRelationUserByIdolId(Integer relation_relationId, String related_userbyidolid_userId);

	/**
	 * Delete an existing User entity
	 * 
	 */
	public Relation deleteRelationUserByFanId(Integer relation_relationId_1, String related_userbyfanid_userId);

	/**
	 * Save an existing User entity
	 * 
	 */
	public Relation saveRelationUserByFanId(Integer relationId, User related_userbyfanid);

	/**
	 * Save an existing User entity
	 * 
	 */
	public Relation saveRelationUserByIdolId(Integer relationId_1, User related_userbyidolid);

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	public void deleteRelation(Relation relation_1);

	/**
	 */
	public Relation findRelationByPrimaryKey(Integer relationId_2);

	/**
	 * Load an existing Relation entity
	 * 
	 */
	public Set<Relation> loadRelations();

	/**
	 * Return a count of all Relation entity
	 * 
	 */
	public Integer countRelations();
}