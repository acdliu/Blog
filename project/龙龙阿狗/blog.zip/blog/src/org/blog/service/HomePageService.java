package org.blog.service;

public interface HomePageService {

}
