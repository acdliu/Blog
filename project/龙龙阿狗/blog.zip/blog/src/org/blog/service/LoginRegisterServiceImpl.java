package org.blog.service;

import java.util.Set;

import org.blog.dao.ArticleDAO;
import org.blog.dao.CategoryDAO;
import org.blog.dao.UserDAO;
import org.blog.domain.Article;
import org.blog.domain.User;
import org.springframework.beans.factory.annotation.Autowired;

public class LoginRegisterServiceImpl implements LoginRegisterService {

	/**
	 * DAO injected by Spring that manages Article entities
	 * 
	 */
	@Autowired
	private ArticleDAO articleDAO;

	/**
	 * DAO injected by Spring that manages Category entities
	 * 
	 */
	@Autowired
	private CategoryDAO categoryDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;
	@Override
	public Set<Article> getLeatestFiveArticles(User user) {
//		articleDAO.find
		return null;
	}

}










