package org.blog.web;

import java.util.GregorianCalendar;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.blog.dao.UserDAO;
import org.blog.domain.Article;
import org.blog.domain.Rank;
import org.blog.domain.User;
import org.blog.domain.UserDetail;
import org.blog.service.AccountService;
import org.blog.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller("LoginRegisterController")
public class LoginRegisterController {
	/**
	 * Service injected by Spring that provides CRUD operations for User entities
	 * 
	 */
	@Autowired
	private AccountService userService;

	/**
	 * Service injected by Spring that provides CRUD operations for UserDetail entities
	 * 
	 */
	@Autowired
	private UserInfoService userDetailService;
	
	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;
	
	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute User user,HttpSession httpSession) {
		ModelAndView mav = new ModelAndView();
		User tmpUser=userDAO.findUserByUserId(user.getUserId());
		
		if(null!=tmpUser){
			System.out.println("test tmpUser:"+tmpUser.toString());
			if(user.getPassword().equals(tmpUser.getPassword())){
				Set<Article> userArticles = tmpUser.getArticles();
				httpSession.setAttribute("user", tmpUser);
				httpSession.setAttribute("visitedUserId", null);
				httpSession.setAttribute("islogin", true);
				mav.addObject("user", tmpUser);
				mav.addObject("userDetail", tmpUser.getUserDetail());
				mav.addObject("articles", userArticles);
				mav.setViewName("userSpace/userhome.jsp");
				return mav;
			}else{
				mav.addObject("failure","�������");
				mav.setViewName("forward:/loginRegister.jsp");
				return mav;
			}
		}else{
			mav.addObject("failure","�޴��˺�");
			mav.setViewName("forward:/loginRegister.jsp");
			return mav;
		}
		
	}
	
	@RequestMapping("/register")
	public ModelAndView register(@RequestParam String name,@RequestParam String password_confirm,@ModelAttribute User user) {
		ModelAndView mav = new ModelAndView();
		if(user.getPassword().equals(password_confirm)){
			if(userService.findUserByPrimaryKey(user.getUserId())==null){
				userService.saveUser(user);	
				UserDetail userdetail=new UserDetail();
				userdetail.setUser(user);
				userdetail.setUserId(user.getUserId());
				userdetail.setName(name);
				userdetail.setEmail(user.getUserId());
				userdetail.setJoinTime(GregorianCalendar.getInstance());
				Rank newRank=new Rank();	
				newRank.setRankId(1);		
				userdetail.setRank(newRank);
				userdetail.setScore(0);
				userdetail.setHits(0);
				userDetailService.saveUserDetail(userdetail);
				mav.setViewName("forward:/loginRegister.jsp");
				
			}else{
				mav.addObject("failure", "�˺��Ѵ���");
				mav.setViewName("forward:/loginRegister.jsp");
			}
		}else {
			mav.addObject("failure", "���벻һ��");
			mav.setViewName("forward:/loginRegister.jsp");
		}
		return mav;
	}
	
}
