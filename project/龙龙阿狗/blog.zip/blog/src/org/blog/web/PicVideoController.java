package org.blog.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.blog.dao.PicVideoDAO;
import org.blog.dao.PicVideoGroupDAO;

import org.blog.domain.PicVideo;
import org.blog.domain.PicVideoGroup;

import org.blog.service.PicVideoService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for PicVideo entities
 * 
 */

@Controller("PicVideoController")
public class PicVideoController {

	/**
	 * DAO injected by Spring that manages PicVideo entities
	 * 
	 */
	@Autowired
	private PicVideoDAO picVideoDAO;

	/**
	 * DAO injected by Spring that manages PicVideoGroup entities
	 * 
	 */
	@Autowired
	private PicVideoGroupDAO picVideoGroupDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for PicVideo entities
	 * 
	 */
	@Autowired
	private PicVideoService picVideoService;

	/**
	 * Entry point to show all PicVideo entities
	 * 
	 */
	public String indexPicVideo() {
		return "redirect:/indexPicVideo";
	}

	/**
	 * Save an existing PicVideo entity
	 * 
	 */
	@RequestMapping("/savePicVideo")
	public String savePicVideo(@ModelAttribute PicVideo picvideo) {
		picVideoService.savePicVideo(picvideo);
		return "forward:/indexPicVideo";
	}

	/**
	 * Create a new PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/newPicVideoPicVideoGroup")
	public ModelAndView newPicVideoPicVideoGroup(@RequestParam Integer picvideo_picVideoId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("picvideo_picVideoId", picvideo_picVideoId);
		mav.addObject("picvideogroup", new PicVideoGroup());
		mav.addObject("newFlag", true);
		mav.setViewName("picvideo/picvideogroup/editPicVideoGroup.jsp");

		return mav;
	}

	/**
	 * Select an existing PicVideo entity
	 * 
	 */
	@RequestMapping("/selectPicVideo")
	public ModelAndView selectPicVideo(@RequestParam Integer picVideoIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideo", picVideoDAO.findPicVideoByPrimaryKey(picVideoIdKey));
		mav.setViewName("picvideo/viewPicVideo.jsp");

		return mav;
	}

	/**
	 * Show all PicVideo entities
	 * 
	 */
	@RequestMapping("/indexPicVideo")
	public ModelAndView listPicVideos() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideos", picVideoService.loadPicVideos());

		mav.setViewName("picvideo/listPicVideos.jsp");

		return mav;
	}

	/**
	 * Edit an existing PicVideo entity
	 * 
	 */
	@RequestMapping("/editPicVideo")
	public ModelAndView editPicVideo(@RequestParam Integer picVideoIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideo", picVideoDAO.findPicVideoByPrimaryKey(picVideoIdKey));
		mav.setViewName("picvideo/editPicVideo.jsp");

		return mav;
	}

	/**
	 * Show all PicVideoGroup entities by PicVideo
	 * 
	 */
	@RequestMapping("/listPicVideoPicVideoGroup")
	public ModelAndView listPicVideoPicVideoGroup(@RequestParam Integer picVideoIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideo", picVideoDAO.findPicVideoByPrimaryKey(picVideoIdKey));
		mav.setViewName("picvideo/picvideogroup/listPicVideoGroup.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/picvideoController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Select the child PicVideoGroup entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeletePicVideoPicVideoGroup")
	public ModelAndView confirmDeletePicVideoPicVideoGroup(@RequestParam Integer picvideo_picVideoId, @RequestParam Integer related_picvideogroup_picVideoGroupId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideogroup", picVideoGroupDAO.findPicVideoGroupByPrimaryKey(related_picvideogroup_picVideoGroupId));
		mav.addObject("picvideo_picVideoId", picvideo_picVideoId);
		mav.setViewName("picvideo/picvideogroup/deletePicVideoGroup.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Create a new PicVideo entity
	 * 
	 */
	@RequestMapping("/newPicVideo")
	public ModelAndView newPicVideo() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideo", new PicVideo());
		mav.addObject("newFlag", true);
		mav.setViewName("picvideo/editPicVideo.jsp");

		return mav;
	}

	/**
	 * Save an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/savePicVideoPicVideoGroup")
	public ModelAndView savePicVideoPicVideoGroup(@RequestParam Integer picvideo_picVideoId, @ModelAttribute PicVideoGroup picvideogroup) {
		PicVideo parent_picvideo = picVideoService.savePicVideoPicVideoGroup(picvideo_picVideoId, picvideogroup);

		ModelAndView mav = new ModelAndView();
		mav.addObject("picvideo_picVideoId", picvideo_picVideoId);
		mav.addObject("picvideo", parent_picvideo);
		mav.setViewName("picvideo/viewPicVideo.jsp");

		return mav;
	}

	/**
	 * View an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/selectPicVideoPicVideoGroup")
	public ModelAndView selectPicVideoPicVideoGroup(@RequestParam Integer picvideo_picVideoId, @RequestParam Integer picvideogroup_picVideoGroupId) {
		PicVideoGroup picvideogroup = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(picvideogroup_picVideoGroupId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("picvideo_picVideoId", picvideo_picVideoId);
		mav.addObject("picvideogroup", picvideogroup);
		mav.setViewName("picvideo/picvideogroup/viewPicVideoGroup.jsp");

		return mav;
	}

	/**
	 * Select the PicVideo entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeletePicVideo")
	public ModelAndView confirmDeletePicVideo(@RequestParam Integer picVideoIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideo", picVideoDAO.findPicVideoByPrimaryKey(picVideoIdKey));
		mav.setViewName("picvideo/deletePicVideo.jsp");

		return mav;
	}

	/**
	 * Edit an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/editPicVideoPicVideoGroup")
	public ModelAndView editPicVideoPicVideoGroup(@RequestParam Integer picvideo_picVideoId, @RequestParam Integer picvideogroup_picVideoGroupId) {
		PicVideoGroup picvideogroup = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(picvideogroup_picVideoGroupId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("picvideo_picVideoId", picvideo_picVideoId);
		mav.addObject("picvideogroup", picvideogroup);
		mav.setViewName("picvideo/picvideogroup/editPicVideoGroup.jsp");

		return mav;
	}

	/**
	 * Delete an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/deletePicVideoPicVideoGroup")
	public ModelAndView deletePicVideoPicVideoGroup(@RequestParam Integer picvideo_picVideoId, @RequestParam Integer related_picvideogroup_picVideoGroupId) {
		ModelAndView mav = new ModelAndView();

		PicVideo picvideo = picVideoService.deletePicVideoPicVideoGroup(picvideo_picVideoId, related_picvideogroup_picVideoGroupId);

		mav.addObject("picvideo_picVideoId", picvideo_picVideoId);
		mav.addObject("picvideo", picvideo);
		mav.setViewName("picvideo/viewPicVideo.jsp");

		return mav;
	}

	/**
	 * Delete an existing PicVideo entity
	 * 
	 */
	@RequestMapping("/deletePicVideo")
	public String deletePicVideo(@RequestParam Integer picVideoIdKey) {
		PicVideo picvideo = picVideoDAO.findPicVideoByPrimaryKey(picVideoIdKey);
		picVideoService.deletePicVideo(picvideo);
		return "forward:/indexPicVideo";
	}
}