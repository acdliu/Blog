package org.blog.web;

import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.derby.tools.sysinfo;
import org.blog.dao.ArticleDAO;
import org.blog.dao.CategoryDAO;
import org.blog.dao.CommentDAO;
import org.blog.dao.UserDAO;

import org.blog.domain.Article;
import org.blog.domain.Category;
import org.blog.domain.Comment;
import org.blog.domain.User;

import org.blog.service.ArticleService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.WebDataBinder;

import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for Article entities
 * 
 */

@Controller("ArticleController")
public class ArticleController {

	/**
	 * DAO injected by Spring that manages Article entities
	 * 
	 */
	@Autowired
	private ArticleDAO articleDAO;

	/**
	 * DAO injected by Spring that manages Category entities
	 * 
	 */
	@Autowired
	private CategoryDAO categoryDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private CommentDAO commentDAO;
	/**
	 * Service injected by Spring that provides CRUD operations for Article entities
	 * 
	 */
	@Autowired
	private ArticleService articleService;

	/**
	 * Edit an existing Category entity
	 * 
	 */
	@RequestMapping("/editArticleCategory")
	public ModelAndView editArticleCategory(@RequestParam Integer article_articleId, @RequestParam Integer category_categoryId) {
		Category category = categoryDAO.findCategoryByPrimaryKey(category_categoryId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("article_articleId", article_articleId);
		mav.addObject("category", category);
		mav.setViewName("article/category/editCategory.jsp");

		return mav;
	}

	/**
	 * Show all Article entities
	 * 
	 */
	@RequestMapping("/indexArticle")
	public ModelAndView listArticles() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("articles", articleService.loadArticles());

		mav.setViewName("userSpace/userhome.jsp");

		return mav;
	}

	@RequestMapping("/visit")
	public ModelAndView visit(@RequestParam String userId,HttpSession httpSession) {
		ModelAndView mav = new ModelAndView();
		User tmpUser=userDAO.findUserByUserId(userId);
		if(null!=tmpUser){
				Set<Article> userArticles = tmpUser.getArticles();
				mav.addObject("user", tmpUser);
				httpSession.setAttribute("visitedUserId", userId);
				httpSession.setAttribute("islogin",false);
				mav.addObject("userDetail", tmpUser.getUserDetail());
				mav.addObject("articles", userArticles);
				mav.setViewName("userSpace/userhome.jsp");
				return mav;
			
		}else{
			mav.addObject("errorInfo","�����ڸò����û�");
			mav.setViewName("userSpace/error.jsp");
			return mav;
		}

	}
	/**
	 * Create a new Article entity
	 * 
	 */
	@RequestMapping("/newArticle")
	public ModelAndView newArticle(HttpSession httpSession) {
		ModelAndView mav = new ModelAndView();
		User tmpUser = (User)httpSession.getAttribute("user");
		if (tmpUser!=null) {
			System.out.println("/newArticle------ tmpUser:"+tmpUser.toString());
			mav.addObject("categorys",categoryDAO.findAllCategorys());
			mav.setViewName("userSpace/editArticle.jsp");
			return mav;
		} else {
			mav.addObject("errorInfo","��û�е�¼����Ȩ�������ģ�");
			mav.setViewName("userSpace/error.jsp");
			return mav;
		}
	}


	/**
	 * Edit an existing User entity
	 * 
	 */
	@RequestMapping("/modifyArticle")
	public ModelAndView modifyArticle(@RequestParam Integer articleId, HttpSession httpSession) {
		ModelAndView mav = new ModelAndView();
		User tmpUser = (User)httpSession.getAttribute("user");
		
		
		if (null!=tmpUser) {
			Article article = articleDAO.findArticleByPrimaryKey(articleId);
			if (article.getUser().getUserId().equals(tmpUser.getUserId())) {
				mav.addObject("categorys",categoryDAO.findAllCategorys());
				mav.addObject("article", article);
				mav.setViewName("userSpace/modifyArticle.jsp");
			}
			
		} else {
			mav.addObject("errorInfo", "����Ȩ�޸ģ�Ҳ������Ϊ�����Ǹò��ĵĲ���");
			mav.setViewName("userSpace/eorror.jsp");
		}
		return mav;
	}

	@RequestMapping("/commentArticle")
	public String commentArticle(@ModelAttribute Comment comment, HttpSession httpSession) {
		ModelAndView mav = new ModelAndView();
		User tmpUser = (User)httpSession.getAttribute("user");
		Article tmpArticle = (Article)httpSession.getAttribute("viewedArticle");
		
		if (null!=tmpUser) {
			comment.setCommentTime(new GregorianCalendar());
			comment.setArticleId(tmpArticle.getArticleId());
			comment.setUser(tmpUser);
			comment.setIsMoodComment(false);
			comment.setIsPublic(true);
			System.out.println("---------comment:"+comment.toString());
			commentDAO.store(comment);
			System.out.println("comment save success-----------------");
			return "forward:/viewArticle��articleId="+comment.getArticleId();
		} else {
			return "forward:/error";
		}
		
	}
	/**
	 * Delete an existing Article entity
	 * 
	 */
	@RequestMapping("/deleteArticle")
	public String deleteArticle(@RequestParam Integer articleId,HttpSession httpSession) {
		User tmpUser = (User)httpSession.getAttribute("user");
		
		
		if (null!=tmpUser) {
			Article article = articleDAO.findArticleByPrimaryKey(articleId);
			if (article.getUser().getUserId().equals(tmpUser.getUserId())) {
				articleService.deleteArticle(article);
				System.out.println("------------------------delete aritcle success");
				return "forward:/indexArticle";
			}
			
			return "forward:/indexArticle";
		} else {
			return "forward:/error";
		}
	}
	@RequestMapping("/error")
	public ModelAndView errorPage(){
		ModelAndView mav = new ModelAndView();
		mav.addObject("errorInfo","�����οͣ���Ȩ������");
		mav.setViewName("userSpace/error.jsp");
		return mav;
	}


	/**
	 * Save an existing Article entity
	 * 
	 */
	@RequestMapping("/saveArticle")
	public String saveArticle(@ModelAttribute Article article,HttpSession httpSession) {
		User tmpUser=(User)httpSession.getAttribute("user");
		System.out.println("-------article:"+article.toString());
		System.out.println("###########"+article.getCategory().toString());
		article.setCreateTime(new GregorianCalendar());
		article.setUser(tmpUser);
		articleService.saveArticle(article);
		return "forward:/indexArticle";
	}

	@RequestMapping("/saveModifiedArticle")
	public String saveModifiedArticle(@ModelAttribute Article article,HttpSession httpSession) {
		User tmpUser=(User)httpSession.getAttribute("user");
		article.setCreateTime(new GregorianCalendar());
		article.setUser(tmpUser);
		articleDAO.merge(article);
//		articleService.saveArticle(article);
		return "forward:/indexArticle";
	}
	/**
	 * Select an existing Article entity
	 * 
	 */
	@RequestMapping("/viewArticle")
	public ModelAndView viewArticle(@RequestParam Integer articleId,HttpSession httpSession) {
		ModelAndView mav = new ModelAndView();
		System.out.println("----------------------"+articleDAO.findArticleByPrimaryKey(articleId).toString());
		Article tmpArticle=articleDAO.findArticleByPrimaryKey(articleId);
		mav.addObject("article",tmpArticle );
		httpSession.setAttribute("viewedArticle", tmpArticle);
		mav.addObject("comments",commentDAO.findCommentByArticleId(articleId));
		mav.setViewName("userSpace/viewArticle.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Entry point to show all Article entities
	 * 
	 */
	public String indexArticle() {
		return "forward:/XXX";
	}
}