package org.blog.web;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.blog.dao.ArticleDAO;
import org.blog.dao.CommentDAO;
import org.blog.dao.MessageDAO;
import org.blog.dao.MoodDAO;
import org.blog.dao.PicVideoGroupDAO;
import org.blog.dao.RelationDAO;
import org.blog.dao.UserDAO;
import org.blog.dao.UserDetailDAO;
import org.blog.domain.Article;
import org.blog.domain.Comment;
import org.blog.domain.Message;
import org.blog.domain.Mood;
import org.blog.domain.PicVideoGroup;
import org.blog.domain.Relation;
import org.blog.domain.User;
import org.blog.domain.UserDetail;
import org.blog.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for User entities
 * 
 */

@Controller("UserController")
public class UserController {

	/**
	 * DAO injected by Spring that manages Article entities
	 * 
	 */
	@Autowired
	private ArticleDAO articleDAO;

	/**
	 * DAO injected by Spring that manages Comment entities
	 * 
	 */
	@Autowired
	private CommentDAO commentDAO;

	/**
	 * DAO injected by Spring that manages Message entities
	 * 
	 */
	@Autowired
	private MessageDAO messageDAO;

	/**
	 * DAO injected by Spring that manages Mood entities
	 * 
	 */
	@Autowired
	private MoodDAO moodDAO;

	/**
	 * DAO injected by Spring that manages PicVideoGroup entities
	 * 
	 */
	@Autowired
	private PicVideoGroupDAO picVideoGroupDAO;

	/**
	 * DAO injected by Spring that manages Relation entities
	 * 
	 */
	@Autowired
	private RelationDAO relationDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * DAO injected by Spring that manages UserDetail entities
	 * 
	 */
	@Autowired
	private UserDetailDAO userDetailDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for User entities
	 * 
	 */
	@Autowired
	private AccountService userService;

	/**
	 * View an existing Relation entity
	 * 
	 */
	@RequestMapping("/selectUserRelationsForIdolId")
	public ModelAndView selectUserRelationsForIdolId(@RequestParam String user_userId, @RequestParam Integer relationsforidolid_relationId) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationsforidolid_relationId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("relation", relation);
		mav.setViewName("user/relationsforidolid/viewRelationsForIdolId.jsp");

		return mav;
	}

	/**
	 * Show all Article entities by User
	 * 
	 */
	@RequestMapping("/listUserArticles")
	public ModelAndView listUserArticles(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/articles/listArticles.jsp");

		return mav;
	}

	/**
	 * Create a new Mood entity
	 * 
	 */
	@RequestMapping("/newUserMoods")
	public ModelAndView newUserMoods(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("mood", new Mood());
		mav.addObject("newFlag", true);
		mav.setViewName("user/moods/editMoods.jsp");

		return mav;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@RequestMapping("/saveUser")
	public String saveUser(@ModelAttribute User user) {
		userService.saveUser(user);
		return "forward:/indexUser";
	}

	/**
	 * Show all PicVideoGroup entities by User
	 * 
	 */
	@RequestMapping("/listUserPicVideoGroups")
	public ModelAndView listUserPicVideoGroups(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/picvideogroups/listPicVideoGroups.jsp");

		return mav;
	}

	/**
	 * Create a new User entity
	 * 
	 */
	@RequestMapping("/newUser")
	public ModelAndView newUser() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", new User());
		mav.addObject("newFlag", true);
		mav.setViewName("user/editUser.jsp");

		return mav;
	}

	/**
	 * Save an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/saveUserUserDetail")
	public ModelAndView saveUserUserDetail(@RequestParam String user_userId, @ModelAttribute UserDetail userdetail) {
		User parent_user = userService.saveUserUserDetail(user_userId, userdetail);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * View an existing Comment entity
	 * 
	 */
	@RequestMapping("/selectUserComments")
	public ModelAndView selectUserComments(@RequestParam String user_userId, @RequestParam Integer comments_commentId) {
		Comment comment = commentDAO.findCommentByPrimaryKey(comments_commentId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("comment", comment);
		mav.setViewName("user/comments/viewComments.jsp");

		return mav;
	}

	/**
	 * Create a new Article entity
	 * 
	 */
	@RequestMapping("/newUserArticles")
	public ModelAndView newUserArticles(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("article", new Article());
		mav.addObject("newFlag", true);
		mav.setViewName("user/articles/editArticles.jsp");

		return mav;
	}

	/**
	 * Create a new Message entity
	 * 
	 */
	@RequestMapping("/newUserMessagesForSenderId")
	public ModelAndView newUserMessagesForSenderId(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("message", new Message());
		mav.addObject("newFlag", true);
		mav.setViewName("user/messagesforsenderid/editMessagesForSenderId.jsp");

		return mav;
	}

	/**
	 * Delete an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/deleteUserPicVideoGroups")
	public ModelAndView deleteUserPicVideoGroups(@RequestParam String user_userId, @RequestParam Integer related_picvideogroups_picVideoGroupId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserPicVideoGroups(user_userId, related_picvideogroups_picVideoGroupId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * View an existing Relation entity
	 * 
	 */
	@RequestMapping("/selectUserRelationsForFanId")
	public ModelAndView selectUserRelationsForFanId(@RequestParam String user_userId, @RequestParam Integer relationsforfanid_relationId) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationsforfanid_relationId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("relation", relation);
		mav.setViewName("user/relationsforfanid/viewRelationsForFanId.jsp");

		return mav;
	}

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	@RequestMapping("/deleteUserRelationsForIdolId")
	public ModelAndView deleteUserRelationsForIdolId(@RequestParam String user_userId, @RequestParam Integer related_relationsforidolid_relationId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserRelationsForIdolId(user_userId, related_relationsforidolid_relationId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Show all Comment entities by User
	 * 
	 */
	@RequestMapping("/listUserComments")
	public ModelAndView listUserComments(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/comments/listComments.jsp");

		return mav;
	}

	/**
	 * Select the child Comment entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserComments")
	public ModelAndView confirmDeleteUserComments(@RequestParam String user_userId, @RequestParam Integer related_comments_commentId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("comment", commentDAO.findCommentByPrimaryKey(related_comments_commentId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/comments/deleteComments.jsp");

		return mav;
	}

	/**
	 * Save an existing Message entity
	 * 
	 */
	@RequestMapping("/saveUserMessagesForReceiverId")
	public ModelAndView saveUserMessagesForReceiverId(@RequestParam String user_userId, @ModelAttribute Message messagesforreceiverid) {
		User parent_user = userService.saveUserMessagesForReceiverId(user_userId, messagesforreceiverid);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Delete an existing Message entity
	 * 
	 */
	@RequestMapping("/deleteUserMessagesForReceiverId")
	public ModelAndView deleteUserMessagesForReceiverId(@RequestParam String user_userId, @RequestParam Integer related_messagesforreceiverid_messageId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserMessagesForReceiverId(user_userId, related_messagesforreceiverid_messageId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Show all Message entities by User
	 * 
	 */
	@RequestMapping("/listUserMessagesForSenderId")
	public ModelAndView listUserMessagesForSenderId(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/messagesforsenderid/listMessagesForSenderId.jsp");

		return mav;
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@RequestMapping("/deleteUser")
	public String deleteUser(@RequestParam String userIdKey) {
		User user = userDAO.findUserByPrimaryKey(userIdKey);
		userService.deleteUser(user);
		return "forward:/indexUser";
	}

	/**
	 * Select the child Relation entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserRelationsForFanId")
	public ModelAndView confirmDeleteUserRelationsForFanId(@RequestParam String user_userId, @RequestParam Integer related_relationsforfanid_relationId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(related_relationsforfanid_relationId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/relationsforfanid/deleteRelationsForFanId.jsp");

		return mav;
	}

	/**
	 * Edit an existing User entity
	 * 
	 */
	@RequestMapping("/editUser")
	public ModelAndView editUser(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/editUser.jsp");

		return mav;
	}

	/**
	 * View an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/selectUserUserDetail")
	public ModelAndView selectUserUserDetail(@RequestParam String user_userId, @RequestParam String userdetail_userId) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userdetail_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("userdetail", userdetail);
		mav.setViewName("user/userdetail/viewUserDetail.jsp");

		return mav;
	}

	/**
	 * Entry point to show all User entities
	 * 
	 */
	public String indexUser() {
		return "redirect:/indexUser";
	}

	/**
	 * Delete an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/deleteUserUserDetail")
	public ModelAndView deleteUserUserDetail(@RequestParam String user_userId, @RequestParam String related_userdetail_userId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserUserDetail(user_userId, related_userdetail_userId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * View an existing Mood entity
	 * 
	 */
	@RequestMapping("/selectUserMoods")
	public ModelAndView selectUserMoods(@RequestParam String user_userId, @RequestParam Integer moods_moodId) {
		Mood mood = moodDAO.findMoodByPrimaryKey(moods_moodId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("mood", mood);
		mav.setViewName("user/moods/viewMoods.jsp");

		return mav;
	}

	/**
	 * Delete an existing Comment entity
	 * 
	 */
	@RequestMapping("/deleteUserComments")
	public ModelAndView deleteUserComments(@RequestParam String user_userId, @RequestParam Integer related_comments_commentId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserComments(user_userId, related_comments_commentId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Save an existing Mood entity
	 * 
	 */
//========================================================================================
	/**
	 * Save an existing Mood entity
	 * 
	 */
	@RequestMapping("/saveUserMoods")
	public ModelAndView saveUserMoods(@RequestParam String mood, HttpSession httpsession) {
		User user = (User) httpsession.getAttribute("user");
		user = userDAO.findUserByPrimaryKey(user.getUserId());
		
		Mood newMood=new Mood();
		newMood.setMoodId(moodDAO.findAllMoods().size()+1);
		newMood.setUser(user);
		newMood.setContent(mood);
		newMood.setCreateTime(new GregorianCalendar());
		
		//System.out.println(moodDAO.findAllMoods().size()+"=========before");
		User parent_user = userService.saveUserMoods(user.getUserId(), newMood);
		//System.out.println(moodDAO.findAllMoods().size()+"=========after");
		ModelAndView mav = new ModelAndView();
		mav.addObject("user", user);
		mav.addObject("user", parent_user);
		mav.setViewName("forward:/getMood");

		return mav;
	}
//========================================================================================
	/**
	 * Edit an existing Message entity
	 * 
	 */
	@RequestMapping("/editUserMessagesForReceiverId")
	public ModelAndView editUserMessagesForReceiverId(@RequestParam String user_userId, @RequestParam Integer messagesforreceiverid_messageId) {
		Message message = messageDAO.findMessageByPrimaryKey(messagesforreceiverid_messageId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("message", message);
		mav.setViewName("user/messagesforreceiverid/editMessagesForReceiverId.jsp");

		return mav;
	}

	/**
	 * Save an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/saveUserPicVideoGroups")
	public ModelAndView saveUserPicVideoGroups(@RequestParam String user_userId, @ModelAttribute PicVideoGroup picvideogroups) {
		User parent_user = userService.saveUserPicVideoGroups(user_userId, picvideogroups);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Edit an existing Message entity
	 * 
	 */
	@RequestMapping("/editUserMessagesForSenderId")
	public ModelAndView editUserMessagesForSenderId(@RequestParam String user_userId, @RequestParam Integer messagesforsenderid_messageId) {
		Message message = messageDAO.findMessageByPrimaryKey(messagesforsenderid_messageId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("message", message);
		mav.setViewName("user/messagesforsenderid/editMessagesForSenderId.jsp");

		return mav;
	}

	/**
	 * Show all Mood entities by User
	 * 
	 */
	@RequestMapping("/listUserMoods")
	public ModelAndView listUserMoods(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/moods/listMoods.jsp");

		return mav;
	}

	/**
	 * Show all Message entities by User
	 * 
	 */
	@RequestMapping("/listUserMessagesForReceiverId")
	public ModelAndView listUserMessagesForReceiverId(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/messagesforreceiverid/listMessagesForReceiverId.jsp");

		return mav;
	}

	/**
	 * Edit an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/editUserPicVideoGroups")
	public ModelAndView editUserPicVideoGroups(@RequestParam String user_userId, @RequestParam Integer picvideogroups_picVideoGroupId) {
		PicVideoGroup picvideogroup = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(picvideogroups_picVideoGroupId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("picvideogroup", picvideogroup);
		mav.setViewName("user/picvideogroups/editPicVideoGroups.jsp");

		return mav;
	}

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	@RequestMapping("/deleteUserRelationsForFanId")
	public ModelAndView deleteUserRelationsForFanId(@RequestParam String user_userId, @RequestParam Integer related_relationsforfanid_relationId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserRelationsForFanId(user_userId, related_relationsforfanid_relationId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * View an existing Message entity
	 * 
	 */
	@RequestMapping("/selectUserMessagesForSenderId")
	public ModelAndView selectUserMessagesForSenderId(@RequestParam String user_userId, @RequestParam Integer messagesforsenderid_messageId) {
		Message message = messageDAO.findMessageByPrimaryKey(messagesforsenderid_messageId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("message", message);
		mav.setViewName("user/messagesforsenderid/viewMessagesForSenderId.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/userController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Delete an existing Article entity
	 * 
	 */
	@RequestMapping("/deleteUserArticles")
	public ModelAndView deleteUserArticles(@RequestParam String user_userId, @RequestParam Integer related_articles_articleId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserArticles(user_userId, related_articles_articleId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Select the child PicVideoGroup entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserPicVideoGroups")
	public ModelAndView confirmDeleteUserPicVideoGroups(@RequestParam String user_userId, @RequestParam Integer related_picvideogroups_picVideoGroupId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("picvideogroup", picVideoGroupDAO.findPicVideoGroupByPrimaryKey(related_picvideogroups_picVideoGroupId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/picvideogroups/deletePicVideoGroups.jsp");

		return mav;
	}

	/**
	 * Create a new Comment entity
	 * 
	 */
	@RequestMapping("/newUserComments")
	public ModelAndView newUserComments(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("comment", new Comment());
		mav.addObject("newFlag", true);
		mav.setViewName("user/comments/editComments.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Select the child Relation entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserRelationsForIdolId")
	public ModelAndView confirmDeleteUserRelationsForIdolId(@RequestParam String user_userId, @RequestParam Integer related_relationsforidolid_relationId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(related_relationsforidolid_relationId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/relationsforidolid/deleteRelationsForIdolId.jsp");

		return mav;
	}

	/**
	 * Save an existing Relation entity
	 * 
	 */
	@RequestMapping("/saveUserRelationsForIdolId")
	public ModelAndView saveUserRelationsForIdolId(@RequestParam String user_userId, @ModelAttribute Relation relationsforidolid) {
		User parent_user = userService.saveUserRelationsForIdolId(user_userId, relationsforidolid);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Select the User entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUser")
	public ModelAndView confirmDeleteUser(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/deleteUser.jsp");

		return mav;
	}

	/**
	 * Select the child Message entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserMessagesForSenderId")
	public ModelAndView confirmDeleteUserMessagesForSenderId(@RequestParam String user_userId, @RequestParam Integer related_messagesforsenderid_messageId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("message", messageDAO.findMessageByPrimaryKey(related_messagesforsenderid_messageId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/messagesforsenderid/deleteMessagesForSenderId.jsp");

		return mav;
	}

	/**
	 * Edit an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/editUserUserDetail")
	public ModelAndView editUserUserDetail(@RequestParam String user_userId, @RequestParam String userdetail_userId) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userdetail_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("userdetail", userdetail);
		mav.setViewName("user/userdetail/editUserDetail.jsp");

		return mav;
	}

	/**
	 * Edit an existing Relation entity
	 * 
	 */
	@RequestMapping("/editUserRelationsForFanId")
	public ModelAndView editUserRelationsForFanId(@RequestParam String user_userId, @RequestParam Integer relationsforfanid_relationId) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationsforfanid_relationId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("relation", relation);
		mav.setViewName("user/relationsforfanid/editRelationsForFanId.jsp");

		return mav;
	}

	/**
	 * Create a new UserDetail entity
	 * 
	 */
	@RequestMapping("/newUserUserDetail")
	public ModelAndView newUserUserDetail(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("userdetail", new UserDetail());
		mav.addObject("newFlag", true);
		mav.setViewName("user/userdetail/editUserDetail.jsp");

		return mav;
	}

	/**
	 * Show all User entities
	 * 
	 */
	@RequestMapping("/indexUser")
	public ModelAndView listUsers() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("users", userService.loadUsers());

		mav.setViewName("user/listUsers.jsp");

		return mav;
	}

	/**
	 * Create a new Message entity
	 * 
	 */
	@RequestMapping("/newUserMessagesForReceiverId")
	public ModelAndView newUserMessagesForReceiverId(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("message", new Message());
		mav.addObject("newFlag", true);
		mav.setViewName("user/messagesforreceiverid/editMessagesForReceiverId.jsp");

		return mav;
	}

	/**
	 * Save an existing Message entity
	 * 
	 */
	@RequestMapping("/saveUserMessagesForSenderId")
	public ModelAndView saveUserMessagesForSenderId(@RequestParam String user_userId, @ModelAttribute Message messagesforsenderid) {
		User parent_user = userService.saveUserMessagesForSenderId(user_userId, messagesforsenderid);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Select the child Article entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserArticles")
	public ModelAndView confirmDeleteUserArticles(@RequestParam String user_userId, @RequestParam Integer related_articles_articleId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("article", articleDAO.findArticleByPrimaryKey(related_articles_articleId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/articles/deleteArticles.jsp");

		return mav;
	}

	/**
	 * View an existing Article entity
	 * 
	 */
	@RequestMapping("/selectUserArticles")
	public ModelAndView selectUserArticles(@RequestParam String user_userId, @RequestParam Integer articles_articleId) {
		Article article = articleDAO.findArticleByPrimaryKey(articles_articleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("article", article);
		mav.setViewName("user/articles/viewArticles.jsp");

		return mav;
	}

	/**
	 * View an existing Message entity
	 * 
	 */
	@RequestMapping("/selectUserMessagesForReceiverId")
	public ModelAndView selectUserMessagesForReceiverId(@RequestParam String user_userId, @RequestParam Integer messagesforreceiverid_messageId) {
		Message message = messageDAO.findMessageByPrimaryKey(messagesforreceiverid_messageId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("message", message);
		mav.setViewName("user/messagesforreceiverid/viewMessagesForReceiverId.jsp");

		return mav;
	}

	/**
	 * Create a new Relation entity
	 * 
	 */
	@RequestMapping("/newUserRelationsForIdolId")
	public ModelAndView newUserRelationsForIdolId(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("relation", new Relation());
		mav.addObject("newFlag", true);
		mav.setViewName("user/relationsforidolid/editRelationsForIdolId.jsp");

		return mav;
	}

	/**
	 * Show all Relation entities by User
	 * 
	 */
	@RequestMapping("/listUserRelationsForIdolId")
	public ModelAndView listUserRelationsForIdolId(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/relationsforidolid/listRelationsForIdolId.jsp");

		return mav;
	}

	/**
	 * Select an existing User entity
	 * 
	 */
	@RequestMapping("/selectUser")
	public ModelAndView selectUser(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Select the child Mood entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserMoods")
	public ModelAndView confirmDeleteUserMoods(@RequestParam String user_userId, @RequestParam Integer related_moods_moodId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("mood", moodDAO.findMoodByPrimaryKey(related_moods_moodId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/moods/deleteMoods.jsp");

		return mav;
	}

	/**
	 * Show all UserDetail entities by User
	 * 
	 */
	@RequestMapping("/listUserUserDetail")
	public ModelAndView listUserUserDetail(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/userdetail/listUserDetail.jsp");

		return mav;
	}

	/**
	 * Delete an existing Message entity
	 * 
	 */
	@RequestMapping("/deleteUserMessagesForSenderId")
	public ModelAndView deleteUserMessagesForSenderId(@RequestParam String user_userId, @RequestParam Integer related_messagesforsenderid_messageId) {
		ModelAndView mav = new ModelAndView();

		User user = userService.deleteUserMessagesForSenderId(user_userId, related_messagesforsenderid_messageId);

		mav.addObject("user_userId", user_userId);
		mav.addObject("user", user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * Create a new PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/newUserPicVideoGroups")
	public ModelAndView newUserPicVideoGroups(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("picvideogroup", new PicVideoGroup());
		mav.addObject("newFlag", true);
		mav.setViewName("user/picvideogroups/editPicVideoGroups.jsp");

		return mav;
	}

	/**
	 * Edit an existing Article entity
	 * 
	 */
	@RequestMapping("/editUserArticles")
	public ModelAndView editUserArticles(@RequestParam String user_userId, @RequestParam Integer articles_articleId) {
		Article article = articleDAO.findArticleByPrimaryKey(articles_articleId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("article", article);
		mav.setViewName("user/articles/editArticles.jsp");

		return mav;
	}

	/**
	 * Edit an existing Relation entity
	 * 
	 */
	@RequestMapping("/editUserRelationsForIdolId")
	public ModelAndView editUserRelationsForIdolId(@RequestParam String user_userId, @RequestParam Integer relationsforidolid_relationId) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationsforidolid_relationId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("relation", relation);
		mav.setViewName("user/relationsforidolid/editRelationsForIdolId.jsp");

		return mav;
	}

	/**
	 * Edit an existing Comment entity
	 * 
	 */
	@RequestMapping("/editUserComments")
	public ModelAndView editUserComments(@RequestParam String user_userId, @RequestParam Integer comments_commentId) {
		Comment comment = commentDAO.findCommentByPrimaryKey(comments_commentId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("comment", comment);
		mav.setViewName("user/comments/editComments.jsp");

		return mav;
	}

	/**
	 * Edit an existing Mood entity
	 * 
	 */
	@RequestMapping("/editUserMoods")
	public ModelAndView editUserMoods(@RequestParam String user_userId, @RequestParam Integer moods_moodId) {
		Mood mood = moodDAO.findMoodByPrimaryKey(moods_moodId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("mood", mood);
		mav.setViewName("user/moods/editMoods.jsp");

		return mav;
	}

	/**
	 * Create a new Relation entity
	 * 
	 */
	@RequestMapping("/newUserRelationsForFanId")
	public ModelAndView newUserRelationsForFanId(@RequestParam String user_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("relation", new Relation());
		mav.addObject("newFlag", true);
		mav.setViewName("user/relationsforfanid/editRelationsForFanId.jsp");

		return mav;
	}

	/**
	 * Save an existing Comment entity
	 * 
	 */
	@RequestMapping("/saveUserComments")
	public ModelAndView saveUserComments(@RequestParam String user_userId, @ModelAttribute Comment comments) {
		User parent_user = userService.saveUserComments(user_userId, comments);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}

	/**
	 * View an existing PicVideoGroup entity
	 * 
	 */
	@RequestMapping("/selectUserPicVideoGroups")
	public ModelAndView selectUserPicVideoGroups(@RequestParam String user_userId, @RequestParam Integer picvideogroups_picVideoGroupId) {
		PicVideoGroup picvideogroup = picVideoGroupDAO.findPicVideoGroupByPrimaryKey(picvideogroups_picVideoGroupId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("picvideogroup", picvideogroup);
		mav.setViewName("user/picvideogroups/viewPicVideoGroups.jsp");

		return mav;
	}

	/**
	 * Select the child UserDetail entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserUserDetail")
	public ModelAndView confirmDeleteUserUserDetail(@RequestParam String user_userId, @RequestParam String related_userdetail_userId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", userDetailDAO.findUserDetailByPrimaryKey(related_userdetail_userId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/userdetail/deleteUserDetail.jsp");

		return mav;
	}

	/**
	 * Select the child Message entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserMessagesForReceiverId")
	public ModelAndView confirmDeleteUserMessagesForReceiverId(@RequestParam String user_userId, @RequestParam Integer related_messagesforreceiverid_messageId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("message", messageDAO.findMessageByPrimaryKey(related_messagesforreceiverid_messageId));
		mav.addObject("user_userId", user_userId);
		mav.setViewName("user/messagesforreceiverid/deleteMessagesForReceiverId.jsp");

		return mav;
	}

	/**
	 * Show all Relation entities by User
	 * 
	 */
	@RequestMapping("/listUserRelationsForFanId")
	public ModelAndView listUserRelationsForFanId(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(userIdKey));
		mav.setViewName("user/relationsforfanid/listRelationsForFanId.jsp");

		return mav;
	}

	/**
	 * Save an existing Article entity
	 * 
	 */
	@RequestMapping("/saveUserArticles")
	public ModelAndView saveUserArticles(@RequestParam String user_userId, @ModelAttribute Article articles) {
		User parent_user = userService.saveUserArticles(user_userId, articles);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}
//=====================================================================================
	/**
	 * Delete an existing Mood entity
	 * 
	 */
	@RequestMapping("/deleteUserMoods")
	public ModelAndView deleteUserMoods(@RequestParam Integer moodId) {
		Mood newMood=moodDAO.findMoodByPrimaryKey(moodId);
		User user=newMood.getUser();
		
		ModelAndView mav = new ModelAndView();
		user = userService.deleteUserMoods(user.getUserId(), moodId);
		mav.setViewName("forward:/getMood");

		return mav;
	}
//=====================================================================================
	/**
	 * Save an existing Relation entity
	 * 
	 */
	@RequestMapping("/saveUserRelationsForFanId")
	public ModelAndView saveUserRelationsForFanId(@RequestParam String user_userId, @ModelAttribute Relation relationsforfanid) {
		User parent_user = userService.saveUserRelationsForFanId(user_userId, relationsforfanid);

		ModelAndView mav = new ModelAndView();
		mav.addObject("user_userId", user_userId);
		mav.addObject("user", parent_user);
		mav.setViewName("user/viewUser.jsp");

		return mav;
	}
}