package org.blog.web;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.blog.dao.MoodDAO;
import org.blog.dao.RankDAO;
import org.blog.dao.UserDAO;
import org.blog.dao.UserDetailDAO;
import org.blog.domain.Mood;
import org.blog.domain.Rank;
import org.blog.domain.User;
import org.blog.domain.UserDetail;
import org.blog.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for UserDetail entities
 * 
 */

@Controller("UserDetailController")
public class UserDetailController {

	/**
	 * DAO injected by Spring that manages Rank entities
	 * 
	 */
	@Autowired
	private RankDAO rankDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * DAO injected by Spring that manages UserDetail entities
	 * 
	 */
	@Autowired
	private UserDetailDAO userDetailDAO;
	
	/**
	 * DAO injected by Spring that manages Mood entities
	 * 
	 */
	@Autowired
	private MoodDAO moodDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for UserDetail entities
	 * 
	 */
	@Autowired
	private UserInfoService userDetailService;
	
	@RequestMapping("/getUserDetail")
	public ModelAndView getUserDetail(HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		User user = (User)httpSession.getAttribute("user");
		if((Boolean) httpSession.getAttribute("islogin")){
			if(user!=null){
				UserDetail tmp = userDetailService.findUserDetailByPrimaryKey(user.getUserId());
				mav.addObject("userDetail",tmp);
				if(tmp.getBirthday()!=null){
					mav.addObject("birth_year",tmp.getBirthday().get(Calendar.YEAR));
					mav.addObject("birth_month",tmp.getBirthday().get(Calendar.MONTH)+1);
					mav.addObject("birth_day",tmp.getBirthday().get(Calendar.DAY_OF_MONTH));
				}
				mav.setViewName("userSpace/Manager.jsp");
			}
			else{
				mav.addObject("errorInfo","����û��½�����¼���ٳ���");
				mav.setViewName("userspace/error.jsp");
			}
		}
		else{
			UserDetail tmp = userDetailService.findUserDetailByPrimaryKey((String)httpSession.getAttribute("visitedUserId"));
			mav.addObject("userDetail",tmp);
			if(tmp.getBirthday()!=null){
				mav.addObject("birth_year",tmp.getBirthday().get(Calendar.YEAR));
				mav.addObject("birth_month",tmp.getBirthday().get(Calendar.MONTH)+1);
				mav.addObject("birth_day",tmp.getBirthday().get(Calendar.DAY_OF_MONTH));
			}
			mav.setViewName("userSpace/Manager.jsp");
		}
		return mav;
	}
	
	/**
	 * Save an existing UserDetail entity
	 * @throws UnsupportedEncodingException 
	 * 
	 */
	@RequestMapping("/saveUserDetail")
	public ModelAndView saveUserDetail(HttpSession httpSession,@ModelAttribute UserDetail userdetail,@RequestParam String BIRTH_Y,@RequestParam String BIRTH_M,@RequestParam String BIRTH_D){
		ModelAndView mav = new ModelAndView();
		if((String)httpSession.getAttribute("visitedUserId")==null){
			Calendar birthday = GregorianCalendar.getInstance();
			birthday.set(Integer.valueOf(BIRTH_Y),Integer.valueOf(BIRTH_M)-1,Integer.valueOf(BIRTH_D));
			userdetail.setBirthday(birthday);
			userDetailService.saveUserDetail(userdetail);
			JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
		}
		else JOptionPane.showMessageDialog(null, "���Ǹ��û������޸�");
		mav.addObject("user",userdetail.getUser());
		mav.addObject("articles",userDAO.findUserByPrimaryKey(userdetail.getUserId()).getArticles());
		mav.setViewName("userSpace/userhome.jsp");
		return mav;
	}

//================================================================
	@RequestMapping("/getMood")
	public ModelAndView getMood(HttpSession httpsession){
		User user = (User) httpsession.getAttribute("user");
		user = userDAO.findUserByPrimaryKey(user.getUserId());
		Set<Mood> moods=user.getMoods();
		String newmood;
		if(moodDAO.findMoodByMoodId(moods.size())!=null){
			if(moodDAO.findMoodByMoodId(moods.size()).getContent().length()>10){
				newmood=moodDAO.findMoodByMoodId(moods.size()).getContent().substring(0, 6)+"...";
			}else{
				newmood=moodDAO.findMoodByMoodId(moods.size()).getContent();
			}
		}else{
			newmood="";
		}
		ModelAndView mav = new ModelAndView();
		mav.addObject("username",user.getUserDetail().getName());
		mav.addObject("user", user);
		mav.addObject("newmood", newmood);
		mav.addObject("moods", moods);
		mav.setViewName("userSpace/mood.jsp");
		return mav;
	}
//======================================================================
	
	/**
	 * Save an existing Rank entity
	 * 
	 */
	@RequestMapping("/saveUserDetailRank")
	public ModelAndView saveUserDetailRank(@RequestParam String userdetail_userId, @ModelAttribute Rank rank) {
		UserDetail parent_userdetail = userDetailService.saveUserDetailRank(userdetail_userId, rank);

		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("userdetail", parent_userdetail);
		mav.setViewName("userdetail/viewUserDetail.jsp");

		return mav;
	}

	/**
	 * Create a new UserDetail entity
	 * 
	 */
	@RequestMapping("/newUserDetail")
	public ModelAndView newUserDetail() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", new UserDetail());
		mav.addObject("newFlag", true);
		mav.setViewName("userdetail/editUserDetail.jsp");

		return mav;
	}

	/**
	 * Entry point to show all UserDetail entities
	 * 
	 */
	public String indexUserDetail() {
		return "redirect:/indexUserDetail";
	}

	/**
	 * Create a new Rank entity
	 * 
	 */
	@RequestMapping("/newUserDetailRank")
	public ModelAndView newUserDetailRank(@RequestParam String userdetail_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("rank", new Rank());
		mav.addObject("newFlag", true);
		mav.setViewName("userdetail/rank/editRank.jsp");

		return mav;
	}

	/**
	 * Delete an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/deleteUserDetail")
	public String deleteUserDetail(@RequestParam String userIdKey) {
		UserDetail userdetail = userDetailDAO.findUserDetailByPrimaryKey(userIdKey);
		userDetailService.deleteUserDetail(userdetail);
		return "forward:/indexUserDetail";
	}

	/**
	 * Select the child Rank entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserDetailRank")
	public ModelAndView confirmDeleteUserDetailRank(@RequestParam String userdetail_userId, @RequestParam Integer related_rank_rankId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("rank", rankDAO.findRankByPrimaryKey(related_rank_rankId));
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.setViewName("userdetail/rank/deleteRank.jsp");

		return mav;
	}

	/**
	 * Edit an existing User entity
	 * 
	 */
	@RequestMapping("/editUserDetailUser")
	public ModelAndView editUserDetailUser(@RequestParam String userdetail_userId, @RequestParam String user_userId) {
		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("user", user);
		mav.setViewName("userdetail/user/editUser.jsp");

		return mav;
	}

	/**
	 * Select an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/selectUserDetail")
	public ModelAndView selectUserDetail(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", userDetailDAO.findUserDetailByPrimaryKey(userIdKey));
		mav.setViewName("userdetail/viewUserDetail.jsp");

		return mav;
	}

	/**
	 * Show all User entities by UserDetail
	 * 
	 */
	@RequestMapping("/listUserDetailUser")
	public ModelAndView listUserDetailUser(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", userDetailDAO.findUserDetailByPrimaryKey(userIdKey));
		mav.setViewName("userdetail/user/listUser.jsp");

		return mav;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@RequestMapping("/saveUserDetailUser")
	public ModelAndView saveUserDetailUser(@RequestParam String userdetail_userId, @ModelAttribute User user) {
		UserDetail parent_userdetail = userDetailService.saveUserDetailUser(userdetail_userId, user);

		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("userdetail", parent_userdetail);
		mav.setViewName("userdetail/viewUserDetail.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * View an existing Rank entity
	 * 
	 */
	@RequestMapping("/selectUserDetailRank")
	public ModelAndView selectUserDetailRank(@RequestParam String userdetail_userId, @RequestParam Integer rank_rankId) {
		Rank rank = rankDAO.findRankByPrimaryKey(rank_rankId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("rank", rank);
		mav.setViewName("userdetail/rank/viewRank.jsp");

		return mav;
	}

	/**
	 * Edit an existing Rank entity
	 * 
	 */
	@RequestMapping("/editUserDetailRank")
	public ModelAndView editUserDetailRank(@RequestParam String userdetail_userId, @RequestParam Integer rank_rankId) {
		Rank rank = rankDAO.findRankByPrimaryKey(rank_rankId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("rank", rank);
		mav.setViewName("userdetail/rank/editRank.jsp");

		return mav;
	}

	/**
	 * Show all Rank entities by UserDetail
	 * 
	 */
	@RequestMapping("/listUserDetailRank")
	public ModelAndView listUserDetailRank(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", userDetailDAO.findUserDetailByPrimaryKey(userIdKey));
		mav.setViewName("userdetail/rank/listRank.jsp");

		return mav;
	}

	/**
	 * Select the child User entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserDetailUser")
	public ModelAndView confirmDeleteUserDetailUser(@RequestParam String userdetail_userId, @RequestParam String related_user_userId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(related_user_userId));
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.setViewName("userdetail/user/deleteUser.jsp");

		return mav;
	}

	/**
	 * Select the UserDetail entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteUserDetail")
	public ModelAndView confirmDeleteUserDetail(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", userDetailDAO.findUserDetailByPrimaryKey(userIdKey));
		mav.setViewName("userdetail/deleteUserDetail.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/userdetailController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Edit an existing UserDetail entity
	 * 
	 */
	@RequestMapping("/editUserDetail")
	public ModelAndView editUserDetail(@RequestParam String userIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetail", userDetailDAO.findUserDetailByPrimaryKey(userIdKey));
		mav.setViewName("userdetail/editUserDetail.jsp");

		return mav;
	}

	/**
	 * View an existing User entity
	 * 
	 */
	@RequestMapping("/selectUserDetailUser")
	public ModelAndView selectUserDetailUser(@RequestParam String userdetail_userId, @RequestParam String user_userId) {
		User user = userDAO.findUserByPrimaryKey(user_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("user", user);
		mav.setViewName("userdetail/user/viewUser.jsp");

		return mav;
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@RequestMapping("/deleteUserDetailUser")
	public ModelAndView deleteUserDetailUser(@RequestParam String userdetail_userId, @RequestParam String related_user_userId) {
		ModelAndView mav = new ModelAndView();

		UserDetail userdetail = userDetailService.deleteUserDetailUser(userdetail_userId, related_user_userId);

		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("userdetail", userdetail);
		mav.setViewName("userdetail/viewUserDetail.jsp");

		return mav;
	}

	/**
	 * Show all UserDetail entities
	 * 
	 */
	@RequestMapping("/indexUserDetail")
	public ModelAndView listUserDetails() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("userdetails", userDetailService.loadUserDetails());

		mav.setViewName("userdetail/listUserDetails.jsp");

		return mav;
	}

	/**
	 * Delete an existing Rank entity
	 * 
	 */
	@RequestMapping("/deleteUserDetailRank")
	public ModelAndView deleteUserDetailRank(@RequestParam String userdetail_userId, @RequestParam Integer related_rank_rankId) {
		ModelAndView mav = new ModelAndView();

		UserDetail userdetail = userDetailService.deleteUserDetailRank(userdetail_userId, related_rank_rankId);

		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("userdetail", userdetail);
		mav.setViewName("userdetail/viewUserDetail.jsp");

		return mav;
	}

	/**
	 * Create a new User entity
	 * 
	 */
	@RequestMapping("/newUserDetailUser")
	public ModelAndView newUserDetailUser(@RequestParam String userdetail_userId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("userdetail_userId", userdetail_userId);
		mav.addObject("user", new User());
		mav.addObject("newFlag", true);
		mav.setViewName("userdetail/user/editUser.jsp");

		return mav;
	}
}