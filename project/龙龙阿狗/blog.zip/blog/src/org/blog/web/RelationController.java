package org.blog.web;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.blog.dao.RelationDAO;
import org.blog.dao.UserDAO;
import org.blog.domain.Relation;
import org.blog.domain.User;
import org.blog.service.RelationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Spring MVC controller that handles CRUD requests for Relation entities
 * 
 */

@Controller("RelationController")
public class RelationController {

	/**
	 * DAO injected by Spring that manages Relation entities
	 * 
	 */
	@Autowired
	private RelationDAO relationDAO;

	/**
	 * DAO injected by Spring that manages User entities
	 * 
	 */
	@Autowired
	private UserDAO userDAO;

	/**
	 * Service injected by Spring that provides CRUD operations for Relation entities
	 * 
	 */
	@Autowired
	private RelationService relationService;

	@RequestMapping("/takeOnfocus")
	public ModelAndView takeOnfocus(HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		User user = (User) httpSession.getAttribute("user");
		//String Id = "1";
		//String Id = null;
		String Id = (String) httpSession.getAttribute("visitedUserId");
		if(user!=null){
			if(Id!=null){
				if(!((Boolean)httpSession.getAttribute("islogin"))){
					user = userDAO.findUserByPrimaryKey(user.getUserId());
					Set<Relation> relation = relationDAO.findAllRelations();
					Iterator<Relation> it = relation.iterator();  
					User user1 = userDAO.findUserByPrimaryKey(Id);//���user1�û�������һ���˺ţ������עuser1������user1��idol��user��fan
					boolean OK = true;
					while (it.hasNext()) { 
						Relation r = it.next();
						if(r.getUserByFanId().getUserId()==user.getUserId()&&r.getUserByIdolId().getUserId()==user1.getUserId()){
							OK = false;
						}
					}
					if(OK){
						Relation r1 = new Relation();
						Calendar c = GregorianCalendar.getInstance();
						c.setTime(new Date());
						r1.setCreateTime(c);
						r1.setUserByFanId(user);
						r1.setUserByIdolId(user1);
						relationDAO.store(r1);
						JOptionPane.showMessageDialog(null, "��ע�ɹ�");
						mav.addObject("user",user1);
						mav.addObject("articles",user1.getArticles());
						mav.setViewName("userSpace/userhome.jsp");
					}
					else{
						mav.addObject("errorInfo","���Ѿ���ע���û���");
						mav.setViewName("userSpace/error.jsp");
					}
				}
				else{
					JOptionPane.showMessageDialog(null, "���ܹ�ע���Լ�");
					mav.addObject("articles",user.getArticles());
					mav.setViewName("userSpace/userhome.jsp");
				}
			}
			else{
				JOptionPane.showMessageDialog(null, "���ܹ�ע���Լ�");
				mav.addObject("articles",user.getArticles());
				mav.setViewName("userSpace/userhome.jsp");
			}
		}
		else{
			mav.addObject("errorInfo","����û��½�����¼���ٳ���");
			mav.setViewName("userSpace/error.jsp");
		}
		return mav;
	}
	
	@RequestMapping("/getUserIdols")
	public ModelAndView getUserIdols(HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		User user = (User) httpSession.getAttribute("user");
		if(httpSession.getAttribute("visitedUserId")==null || (Boolean)httpSession.getAttribute("islogin")){
			user = userDAO.findUserByPrimaryKey(user.getUserId());
		}
		else{
			user = userDAO.findUserByPrimaryKey((String)httpSession.getAttribute("visitedUserId"));
		}
		Set<Relation> idols = relationDAO.findRelationById(user.getUserId());
		user.setRelationsForIdolId(idols);
		mav.addObject("user", user);
		mav.addObject("fansOridols", idols);
		mav.setViewName("userSpace/relation.jsp");
		return mav;
	}
	
	@RequestMapping("/getUserFans")
	public ModelAndView getUserFans(HttpSession httpSession){
		
		ModelAndView mav = new ModelAndView();
		User user = (User) httpSession.getAttribute("user");
		if(((String)httpSession.getAttribute("visitedUserId"))==null || (Boolean)httpSession.getAttribute("islogin")){
			user = userDAO.findUserByPrimaryKey(user.getUserId());
		}
		else{
			user = userDAO.findUserByPrimaryKey((String)httpSession.getAttribute("visitedUserId"));
		}
		Set<Relation> fans=user.getRelationsForFanId();
		mav.addObject("user", user);
		mav.addObject("fansOridols", fans);
		mav.setViewName("userSpace/relation1.jsp");
		return mav;
	}
	
	
	/**
	 * Select an existing Relation entity
	 * 
	 */
	@RequestMapping("/selectRelation")
	public ModelAndView selectRelation(@RequestParam Integer relationIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(relationIdKey));
		mav.setViewName("relation/viewRelation.jsp");

		return mav;
	}

	/**
	 * Show all User entities by Relation
	 * 
	 */
	@RequestMapping("/listRelationUserByIdolId")
	public ModelAndView listRelationUserByIdolId(@RequestParam Integer relationIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(relationIdKey));
		mav.setViewName("relation/userbyidolid/listUserByIdolId.jsp");

		return mav;
	}

	/**
	 * Select the Relation entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteRelation")
	public ModelAndView confirmDeleteRelation(@RequestParam Integer relationIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(relationIdKey));
		mav.setViewName("relation/deleteRelation.jsp");

		return mav;
	}

	/**
	 * View an existing User entity
	 * 
	 */
	@RequestMapping("/selectRelationUserByFanId")
	public ModelAndView selectRelationUserByFanId(@RequestParam Integer relation_relationId, @RequestParam String userbyfanid_userId) {
		User user = userDAO.findUserByPrimaryKey(userbyfanid_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("user", user);
		mav.setViewName("relation/userbyfanid/viewUserByFanId.jsp");

		return mav;
	}

	/**
	 * Save an existing Relation entity
	 * 
	 */
	@RequestMapping("/saveRelation")
	public String saveRelation(@ModelAttribute Relation relation) {
		relationService.saveRelation(relation);
		return "forward:/indexRelation";
	}

	/**
	 * Create a new User entity
	 * 
	 */
	@RequestMapping("/newRelationUserByFanId")
	public ModelAndView newRelationUserByFanId(@RequestParam Integer relation_relationId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("user", new User());
		mav.addObject("newFlag", true);
		mav.setViewName("relation/userbyfanid/editUserByFanId.jsp");

		return mav;
	}

	/**
	 * Select the child User entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteRelationUserByIdolId")
	public ModelAndView confirmDeleteRelationUserByIdolId(@RequestParam Integer relation_relationId, @RequestParam String related_userbyidolid_userId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(related_userbyidolid_userId));
		mav.addObject("relation_relationId", relation_relationId);
		mav.setViewName("relation/userbyidolid/deleteUserByIdolId.jsp");

		return mav;
	}

	/**
	 * Create a new Relation entity
	 * 
	 */
	@RequestMapping("/newRelation")
	public ModelAndView newRelation() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", new Relation());
		mav.addObject("newFlag", true);
		mav.setViewName("relation/editRelation.jsp");

		return mav;
	}

	/**
	 * Edit an existing User entity
	 * 
	 */
	@RequestMapping("/editRelationUserByFanId")
	public ModelAndView editRelationUserByFanId(@RequestParam Integer relation_relationId, @RequestParam String userbyfanid_userId) {
		User user = userDAO.findUserByPrimaryKey(userbyfanid_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("user", user);
		mav.setViewName("relation/userbyfanid/editUserByFanId.jsp");

		return mav;
	}

	/**
	 * Register custom, context-specific property editors
	 * 
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder, HttpServletRequest request) { // Register static property editors.
		binder.registerCustomEditor(java.util.Calendar.class, new org.skyway.spring.util.databinding.CustomCalendarEditor());
		binder.registerCustomEditor(byte[].class, new org.springframework.web.multipart.support.ByteArrayMultipartFileEditor());
		binder.registerCustomEditor(boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(false));
		binder.registerCustomEditor(Boolean.class, new org.skyway.spring.util.databinding.EnhancedBooleanEditor(true));
		binder.registerCustomEditor(java.math.BigDecimal.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(java.math.BigDecimal.class, true));
		binder.registerCustomEditor(Integer.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Integer.class, true));
		binder.registerCustomEditor(java.util.Date.class, new org.skyway.spring.util.databinding.CustomDateEditor());
		binder.registerCustomEditor(String.class, new org.skyway.spring.util.databinding.StringEditor());
		binder.registerCustomEditor(Long.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Long.class, true));
		binder.registerCustomEditor(Double.class, new org.skyway.spring.util.databinding.NaNHandlingNumberEditor(Double.class, true));
	}

	/**
	 * Delete an existing Relation entity
	 * 
	 */
	@RequestMapping("/deleteRelation")
	public String deleteRelation(@RequestParam Integer relationIdKey) {
		Relation relation = relationDAO.findRelationByPrimaryKey(relationIdKey);
		relationService.deleteRelation(relation);
		return "forward:/indexRelation";
	}

	/**
	 * View an existing User entity
	 * 
	 */
	@RequestMapping("/selectRelationUserByIdolId")
	public ModelAndView selectRelationUserByIdolId(@RequestParam Integer relation_relationId, @RequestParam String userbyidolid_userId) {
		User user = userDAO.findUserByPrimaryKey(userbyidolid_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("user", user);
		mav.setViewName("relation/userbyidolid/viewUserByIdolId.jsp");

		return mav;
	}

	/**
	 * Show all User entities by Relation
	 * 
	 */
	@RequestMapping("/listRelationUserByFanId")
	public ModelAndView listRelationUserByFanId(@RequestParam Integer relationIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(relationIdKey));
		mav.setViewName("relation/userbyfanid/listUserByFanId.jsp");

		return mav;
	}

	/**
	 */
	@RequestMapping("/relationController/binary.action")
	public ModelAndView streamBinary(@ModelAttribute HttpServletRequest request, @ModelAttribute HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("streamedBinaryContentView");
		return mav;

	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@RequestMapping("/deleteRelationUserByFanId")
	public ModelAndView deleteRelationUserByFanId(@RequestParam Integer relation_relationId, @RequestParam String related_userbyfanid_userId) {
		ModelAndView mav = new ModelAndView();

		Relation relation = relationService.deleteRelationUserByFanId(relation_relationId, related_userbyfanid_userId);

		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("relation", relation);
		mav.setViewName("relation/viewRelation.jsp");

		return mav;
	}

	/**
	 * Create a new User entity
	 * 
	 */
	@RequestMapping("/newRelationUserByIdolId")
	public ModelAndView newRelationUserByIdolId(@RequestParam Integer relation_relationId) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("user", new User());
		mav.addObject("newFlag", true);
		mav.setViewName("relation/userbyidolid/editUserByIdolId.jsp");

		return mav;
	}

	/**
	 * Show all Relation entities
	 * 
	 */
	@RequestMapping("/indexRelation")
	public ModelAndView listRelations() {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relations", relationService.loadRelations());

		mav.setViewName("relation/listRelations.jsp");

		return mav;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@RequestMapping("/saveRelationUserByFanId")
	public ModelAndView saveRelationUserByFanId(@RequestParam Integer relation_relationId, @ModelAttribute User userbyfanid) {
		Relation parent_relation = relationService.saveRelationUserByFanId(relation_relationId, userbyfanid);

		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("relation", parent_relation);
		mav.setViewName("relation/viewRelation.jsp");

		return mav;
	}

	/**
	 * Delete an existing User entity
	 * 
	 */
	@RequestMapping("/deleteRelationUserByIdolId")
	public ModelAndView deleteRelationUserByIdolId(@RequestParam Integer relation_relationId, @RequestParam String related_userbyidolid_userId) {
		ModelAndView mav = new ModelAndView();

		Relation relation = relationService.deleteRelationUserByIdolId(relation_relationId, related_userbyidolid_userId);

		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("relation", relation);
		mav.setViewName("relation/viewRelation.jsp");

		return mav;
	}

	/**
	 * Entry point to show all Relation entities
	 * 
	 */
	public String indexRelation() {
		return "redirect:/indexRelation";
	}

	/**
	 * Edit an existing User entity
	 * 
	 */
	@RequestMapping("/editRelationUserByIdolId")
	public ModelAndView editRelationUserByIdolId(@RequestParam Integer relation_relationId, @RequestParam String userbyidolid_userId) {
		User user = userDAO.findUserByPrimaryKey(userbyidolid_userId, -1, -1);

		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("user", user);
		mav.setViewName("relation/userbyidolid/editUserByIdolId.jsp");

		return mav;
	}

	/**
	 * Save an existing User entity
	 * 
	 */
	@RequestMapping("/saveRelationUserByIdolId")
	public ModelAndView saveRelationUserByIdolId(@RequestParam Integer relation_relationId, @ModelAttribute User userbyidolid) {
		Relation parent_relation = relationService.saveRelationUserByIdolId(relation_relationId, userbyidolid);

		ModelAndView mav = new ModelAndView();
		mav.addObject("relation_relationId", relation_relationId);
		mav.addObject("relation", parent_relation);
		mav.setViewName("relation/viewRelation.jsp");

		return mav;
	}

	/**
	 * Edit an existing Relation entity
	 * 
	 */
	@RequestMapping("/editRelation")
	public ModelAndView editRelation(@RequestParam Integer relationIdKey) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("relation", relationDAO.findRelationByPrimaryKey(relationIdKey));
		mav.setViewName("relation/editRelation.jsp");

		return mav;
	}

	/**
	 * Select the child User entity for display allowing the user to confirm that they would like to delete the entity
	 * 
	 */
	@RequestMapping("/confirmDeleteRelationUserByFanId")
	public ModelAndView confirmDeleteRelationUserByFanId(@RequestParam Integer relation_relationId, @RequestParam String related_userbyfanid_userId) {
		ModelAndView mav = new ModelAndView();

		mav.addObject("user", userDAO.findUserByPrimaryKey(related_userbyfanid_userId));
		mav.addObject("relation_relationId", relation_relationId);
		mav.setViewName("relation/userbyfanid/deleteUserByFanId.jsp");

		return mav;
	}
}